# 🔐 School ERP — License Protection & Windows Installer Guide
## Vexen Labs | vexenlabs.com

---

## 📁 What's in this package

```
school-erp-protected/
├── src/main/java/com/school/
│   ├── App.java                          ← REPLACE your existing App.java
│   ├── license/
│   │   ├── MachineFingerprint.java       ← NEW — hardware ID generator
│   │   ├── LicenseStorage.java           ← NEW — encrypted local storage
│   │   ├── LicenseValidator.java         ← NEW — API validation
│   │   └── LicenseManager.java           ← NEW — main orchestrator
│   └── ui/license/
│       ├── LicenseActivationDialog.java  ← NEW — activation UI
│       └── LicenseWarningDialog.java     ← NEW — warning/expiry UI
├── src/main/resources/
│   └── license-styles.css               ← NEW — dialog styling
├── proguard/
│   └── proguard.conf                    ← NEW — obfuscation config
├── installer/
│   └── school-erp-setup.iss             ← NEW — Inno Setup script
├── pom.xml                              ← REPLACE your existing pom.xml
└── build-installer.bat                  ← NEW — one-click build script
```

---

## 🚀 Step 1 — Copy files into your existing project

Copy these into your School ERP project (at `D:\pywork\SchoolERP` or wherever yours is):

```
src/main/java/com/school/license/         → copy entire folder
src/main/java/com/school/ui/license/      → copy entire folder
src/main/resources/license-styles.css     → copy file
proguard/proguard.conf                    → copy entire folder
installer/school-erp-setup.iss            → copy file
```

**Replace these:**
- `src/main/java/com/school/App.java`     → use the new App.java
- `pom.xml`                               → use the new pom.xml (merge carefully)

---

## 🔧 Step 2 — Verify the App.java integration

Open your new `App.java`. The key line is:

```java
@Override
public void start(Stage primaryStage) throws Exception {
    
    // ← THIS IS THE ONLY NEW CODE
    boolean licenseValid = LicenseManager.checkLicense(primaryStage);
    if (!licenseValid) {
        Platform.exit();
        System.exit(0);
        return;
    }
    // ← EVERYTHING BELOW IS YOUR EXISTING CODE (unchanged)
    
    FXMLLoader loader = ...  // your existing code
```

If your existing `App.java` is different from the template, just add those 5 lines 
at the very start of your `start()` method.

---

## 🌐 Step 3 — Verify backend API is ready

Your backend at `vexenlabs.com/api/licenses/validate/` should:

1. Accept POST with: `license_key`, `machine_id`, `machine_name`, `os_info`, `product_slug`
2. Return JSON:
   ```json
   // On success:
   { "valid": true, "plan": "Professional", "user_email": "...", 
     "user_name": "...", "expires_at": null, "max_activations": 3 }
   
   // On failure:
   { "valid": false, "error": "Invalid license key." }
   ```

Test it from your Windows machine:
```bash
curl -X POST https://vexenlabs.com/api/licenses/validate/ \
  -H "Content-Type: application/json" \
  -d '{"license_key":"TEST","machine_id":"ABC","product_slug":"school-erp"}'
```

---

## 🛠️ Step 4 — Install build prerequisites

Download and install in this order:

### A. Java 21 JDK (if not already installed)
Download: https://adoptium.net/temurin/releases/?version=21
- Choose: Windows, x64, JDK, .msi installer
- Install with default settings
- Verify: open CMD → `java --version` → should show 21

### B. Maven 3.8+
Download: https://maven.apache.org/download.cgi
- Download: apache-maven-3.9.x-bin.zip
- Extract to: `C:\maven`
- Add to PATH: `C:\maven\bin`
- Verify: `mvn --version`

### C. Inno Setup 6
Download: https://jrsoftware.org/isdl.php
- Install with default settings (installs to C:\Program Files (x86)\Inno Setup 6)
- No PATH setup needed — build script finds it automatically

---

## 📦 Step 5 — Add your app icon

Place these files in `installer/`:
- `app-icon.ico` — your app icon (256x256 recommended, .ico format)
- `wizard-image.bmp` — installer left panel image (164x314 pixels)
- `wizard-small.bmp` — installer top-right image (55x58 pixels)

Free icon converter: https://convertio.co/png-ico/
Free BMP maker: use Paint and save as BMP

---

## 🏗️ Step 6 — Build the installer

```bat
REM Navigate to your project folder
cd D:\pywork\SchoolERP

REM Run the build script
build-installer.bat
```

What happens:
1. Maven compiles all Java code
2. Maven packages everything into a fat JAR
3. `jpackage` bundles JRE 21 + JAR into a Windows app
4. Inno Setup wraps it in a professional installer EXE

Output: `installer\SchoolERP-Setup-1.0.0.exe` (~80-120 MB)

---

## 🧪 Step 7 — Test the complete flow

### Test 1: First launch (no license)
```
Run SchoolERP-Setup-1.0.0.exe on a fresh VM or test PC
→ Should install to C:\Program Files\Vexen Labs\School Management ERP
→ Launch the app
→ Should see: License activation dialog
```

### Test 2: Activate with valid key
```
Enter a real license key from your vexenlabs.com dashboard
→ Should show: "✓ License activated successfully!"
→ App should open after 1.5 seconds
→ Check: %APPDATA%\VexenLabs\SchoolERP\license.dat should exist
```

### Test 3: Already activated (subsequent launches)
```
Close and reopen the app
→ Should open directly WITHOUT showing activation dialog
→ License is cached and validated silently
```

### Test 4: Offline mode (disconnect internet)
```
Disconnect WiFi/ethernet
→ Launch app
→ Should open normally (cached license)
→ Should NOT show activation dialog
→ Repeat for 30+ days to test grace period
```

### Test 5: Wrong key
```
Enter: AAAAA-BBBBB-CCCCC-DDDDD-EEEEE
→ Should show: "❌ Invalid license key"
→ App should NOT open
```

### Test 6: Max device limit
```
Activate same key on 4th device (if Starter plan = 3 devices)
→ Should show: "❌ Maximum devices reached"
→ Guide user to dashboard to deactivate old device
```

---

## 🔒 What the license protection does

### Layer 1: Machine fingerprinting
- Generates unique hardware ID from: MAC address + Computer Name + Disk Serial + CPU ID
- Changes if significant hardware is changed (protects against VM cloning)

### Layer 2: Encrypted local storage
- License stored in `%APPDATA%\VexenLabs\SchoolERP\license.dat`
- Encrypted with AES-128 using a key derived from the machine ID
- Even if copied to another machine, it won't decrypt correctly

### Layer 3: Online validation
- Validates against vexenlabs.com every 30 days
- Allows 30-day offline grace period (for areas with intermittent internet)
- Checks for revocation, expiry, and max device limits

### Layer 4: Code obfuscation (ProGuard)
- All class/method/field names are renamed to a, b, c, etc.
- License validation logic becomes very hard to read/bypass
- Run `mvn proguard:proguard` to obfuscate the JAR

---

## 📤 Step 8 — Upload installer to vexenlabs.com

After building:
1. Go to `https://vexenlabs.com/admin/upload`
2. Select product: School Management ERP
3. Upload: `installer\SchoolERP-Setup-1.0.0.exe`
4. Customers can now download it from their dashboard after purchase

---

## 🚨 Common Issues

### "jpackage not found"
Add JDK bin to PATH: `C:\Program Files\Eclipse Adoptium\jdk-21.x.x\bin`

### "Cannot find main class"
Check `App.java` package matches: `package com.school;`

### "License dialog CSS not loading"
Check `license-styles.css` is in `src/main/resources/` (not resources/css/)
Update the path in `LicenseActivationDialog.java`:
```java
getClass().getResource("/license-styles.css")
```

### "API returns 404"
Check vexenlabs.com backend has route: `/api/licenses/validate/`
Test with curl (see Step 3 above)

### ProGuard "can't find class"
Add `-dontwarn` for the missing class in `proguard.conf`

---

## 📞 Support

Vexen Labs | vexenlabs.com
Email: support@vexenlabs.com
WhatsApp: your number here
