; ══════════════════════════════════════════════════════════════════════
;  School Management ERP — Inno Setup Script
;  Vexen Labs | vexenlabs.com
;
;  Produces a professional Windows installer that:
;  - Installs app + bundled JRE 21 (no Java install needed)
;  - Creates desktop shortcut with icon
;  - Creates Start Menu folder
;  - Registers in Add/Remove Programs
;  - Includes a clean uninstaller
;  - Shows license agreement during install
; ══════════════════════════════════════════════════════════════════════

#define AppName        "School Management ERP"
#define AppVersion     "1.0.0"
#define AppPublisher   "Vexen Labs"
#define AppURL         "https://vexenlabs.com/products/school-erp"
#define AppSupportURL  "https://vexenlabs.com/contact"
#define AppExeName     "SchoolERP.exe"
#define AppID          "VexenLabs.SchoolERP"

[Setup]
AppId                    = {{com.vexenlabs.school-erp}}
AppName                  = {#AppName}
AppVersion               = {#AppVersion}
AppVerName               = {#AppName} {#AppVersion}
AppPublisher             = {#AppPublisher}
AppPublisherURL          = {#AppURL}
AppSupportURL            = {#AppSupportURL}
AppUpdatesURL            = {#AppURL}
AppCopyright             = Copyright © 2024 {#AppPublisher}

; Install location
DefaultDirName           = {autopf}\{#AppPublisher}\{#AppName}
DefaultGroupName         = {#AppPublisher}\{#AppName}
DisableProgramGroupPage  = no

; Output
OutputDir                = installer
OutputBaseFilename       = SchoolERP-Setup-{#AppVersion}

; Appearance
SetupIconFile            = installer\app-icon.ico
WizardStyle              = modern
WizardImageFile          = installer\wizard-image.bmp    ; 164x314 pixels
WizardSmallImageFile     = installer\wizard-small.bmp    ; 55x58 pixels

; Requirements
MinVersion               = 10.0          ; Windows 10+
PrivilegesRequired       = admin
ArchitecturesInstallIn64BitMode = x64

; Compression
Compression              = lzma2/ultra64
SolidCompression         = yes
LZMAUseSeparateProcess   = yes

; Uninstall
UninstallDisplayIcon     = {app}\{#AppExeName}
UninstallDisplayName     = {#AppName} {#AppVersion} (Vexen Labs)
CreateUninstallRegKey    = yes

; Misc
AllowNoIcons             = yes
DisableWelcomePage       = no
DisableReadyPage         = no
ShowLanguageDialog       = auto

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";    Description: "Create a desktop shortcut";     GroupDescription: "Additional icons:"; Flags: checked
Name: "startmenuicon";  Description: "Create a Start Menu shortcut";  GroupDescription: "Additional icons:"; Flags: checked

[Files]
; ── Application (jpackage output) ─────────────────────────────────────
; This includes the bundled JRE — no Java needed on customer PC
Source: "..\build\SchoolERP\*";     DestDir: "{app}";    Flags: ignoreversion recursesubdirs createallsubdirs

; ── License agreement ──────────────────────────────────────────────────
Source: "installer\license.rtf";    DestDir: "{tmp}";    Flags: dontcopy

[Icons]
; Desktop shortcut
Name: "{autodesktop}\{#AppName}";   Filename: "{app}\{#AppExeName}";   WorkingDir: "{app}";   IconFilename: "{app}\{#AppExeName}";   Tasks: desktopicon

; Start Menu
Name: "{group}\{#AppName}";         Filename: "{app}\{#AppExeName}";   WorkingDir: "{app}"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"

[Registry]
; Register app for Add/Remove Programs with extra info
Root: HKLM; Subkey: "Software\{#AppPublisher}\{#AppName}"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\{#AppPublisher}\{#AppName}"; ValueType: string; ValueName: "Version";     ValueData: "{#AppVersion}"
Root: HKLM; Subkey: "Software\{#AppPublisher}\{#AppName}"; ValueType: string; ValueName: "Publisher";   ValueData: "{#AppPublisher}"

[Run]
; Launch app after install (optional)
Filename: "{app}\{#AppExeName}";    Description: "Launch {#AppName} now";    Flags: nowait postinstall skipifsilent unchecked

[UninstallDelete]
; Remove license data on uninstall
Type: filesandordirs;   Name: "{localappdata}\VexenLabs\SchoolERP"
Type: filesandordirs;   Name: "{userappdata}\VexenLabs\SchoolERP"

[Code]
{ ── Custom installer pages ────────────────────────────────────────── }

var
  LicensePage: TOutputMsgWizardPage;

procedure InitializeWizard();
begin
  { Show license agreement page }
  LicensePage := CreateOutputMsgPage(
    wpWelcome,
    'License Agreement',
    'Please read the following license agreement carefully.',
    'By installing School Management ERP, you agree to the Vexen Labs End User License Agreement.'
    + #13#10 + #13#10
    + 'Key terms:'
    + #13#10 + '• This software is licensed, not sold'
    + #13#10 + '• Each license key allows activation on a limited number of devices'
    + #13#10 + '• License keys may not be shared or resold'
    + #13#10 + '• 7-day refund policy applies from purchase date'
    + #13#10 + #13#10
    + 'Full EULA at: https://vexenlabs.com/eula'
  );
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
end;

{ Show welcome message }
function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := False;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then begin
    { Create app data directory for license storage }
    CreateDir(ExpandConstant('{userappdata}\VexenLabs'));
    CreateDir(ExpandConstant('{userappdata}\VexenLabs\SchoolERP'));
  end;
end;

{ On uninstall — offer to deactivate license }
function InitializeUninstall(): Boolean;
var
  Response: Integer;
begin
  Response := MsgBox(
    'Do you want to deactivate the license on this computer?' + #13#10 +
    'This will free up an activation slot so you can activate on another PC.',
    mbConfirmation,
    MB_YESNO
  );
  { Note: actual deactivation happens via the app — this is just a prompt }
  Result := True;
end;
