@echo off
REM ══════════════════════════════════════════════════════════════════════
REM  School ERP — Windows Installer Builder
REM  Vexen Labs | vexenlabs.com
REM
REM  Produces: SchoolERP-Setup-1.0.0.exe (professional Windows installer)
REM
REM  Prerequisites:
REM    - Java 21 JDK (https://adoptium.net/temurin/releases/?version=21)
REM    - Maven 3.8+  (https://maven.apache.org/download.cgi)
REM    - Inno Setup 6 (https://jrsoftware.org/isdl.php)
REM    - WiX Toolset (optional, for MSI instead of EXE)
REM ══════════════════════════════════════════════════════════════════════

setlocal enabledelayedexpansion

set APP_NAME=SchoolERP
set APP_VERSION=1.0.0
set COMPANY=Vexen Labs
set MAIN_CLASS=com.school.App
set JAR_NAME=school-erp-1.0.0.jar

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   School ERP — Building Windows Installer ║
echo  ╚══════════════════════════════════════════╝
echo.

REM ── Check prerequisites ──────────────────────────────────────────────
echo [1/7] Checking prerequisites...

java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: Java not found. Install Java 21 JDK from adoptium.net
    pause & exit /b 1
)

mvn -version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: Maven not found. Add Maven to PATH.
    pause & exit /b 1
)

where iscc >nul 2>&1
if %errorlevel% neq 0 (
    echo  WARNING: Inno Setup not found. Looking in default location...
    if exist "C:\Program Files (x86)\Inno Setup 6\iscc.exe" (
        set ISCC="C:\Program Files (x86)\Inno Setup 6\iscc.exe"
    ) else (
        echo  ERROR: Inno Setup 6 not found. Download from: https://jrsoftware.org/isdl.php
        pause & exit /b 1
    )
) else (
    set ISCC=iscc
)

echo  ✓ All prerequisites found
echo.

REM ── Clean previous build ─────────────────────────────────────────────
echo [2/7] Cleaning previous build...
if exist build rmdir /s /q build
mkdir build\app
mkdir build\installer
echo  ✓ Cleaned
echo.

REM ── Compile and package with Maven ───────────────────────────────────
echo [3/7] Compiling and packaging with Maven...
call mvn clean package -DskipTests -q
if %errorlevel% neq 0 (
    echo  ERROR: Maven build failed. Check errors above.
    pause & exit /b 1
)
echo  ✓ Maven build complete
echo.

REM ── Copy JAR to build folder ─────────────────────────────────────────
echo [4/7] Preparing application files...
copy target\%JAR_NAME% build\app\ >nul
copy src\main\resources\images\app-icon.ico build\installer\ >nul 2>nul
echo  ✓ Files prepared
echo.

REM ── jpackage: Bundle JRE + create Windows app ─────────────────────────
echo [5/7] Bundling JRE and creating Windows application...
echo  (This takes 2-3 minutes — bundling 60MB JRE into the package)
echo.

jpackage ^
    --type app-image ^
    --name "%APP_NAME%" ^
    --app-version "%APP_VERSION%" ^
    --vendor "%COMPANY%" ^
    --description "School Management ERP by Vexen Labs" ^
    --input build\app ^
    --main-jar %JAR_NAME% ^
    --main-class %MAIN_CLASS% ^
    --dest build ^
    --icon build\installer\app-icon.ico ^
    --win-console ^
    --java-options "--enable-preview" ^
    --java-options "-Dfile.encoding=UTF-8" ^
    --java-options "-Xmx512m" ^
    --java-options "-Xms128m" ^
    --java-options "--add-opens=javafx.graphics/com.sun.javafx.application=ALL-UNNAMED" ^
    --java-options "--add-exports=javafx.base/com.sun.javafx.event=ALL-UNNAMED"

if %errorlevel% neq 0 (
    echo  ERROR: jpackage failed.
    pause & exit /b 1
)
echo  ✓ Windows application image created
echo.

REM ── Create Inno Setup installer ───────────────────────────────────────
echo [6/7] Creating Windows installer with Inno Setup...
%ISCC% installer\school-erp-setup.iss
if %errorlevel% neq 0 (
    echo  ERROR: Inno Setup failed.
    pause & exit /b 1
)
echo  ✓ Installer created
echo.

REM ── Final output ─────────────────────────────────────────────────────
echo [7/7] Build complete!
echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║  OUTPUT: installer\SchoolERP-Setup-1.0.0.exe         ║
echo  ║  Size: approx 80-120 MB (includes Java 21 runtime)   ║
echo  ║                                                       ║
echo  ║  What this installer does:                           ║
echo  ║  ✓ Installs to C:\Program Files\Vexen Labs\SchoolERP ║
echo  ║  ✓ Creates desktop shortcut                          ║
echo  ║  ✓ Creates Start Menu entry                          ║
echo  ║  ✓ Adds to Windows Add/Remove Programs               ║
echo  ║  ✓ Includes uninstaller                              ║
echo  ║  ✓ NO Java installation required on customer PC      ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

dir installer\SchoolERP-Setup-*.exe
echo.
pause
