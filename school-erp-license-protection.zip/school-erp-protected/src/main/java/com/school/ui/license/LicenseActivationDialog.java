package com.school.ui.license;

import com.school.license.LicenseStorage;
import com.school.license.LicenseValidator;
import com.school.license.LicenseValidator.ValidationResponse;
import com.school.license.LicenseValidator.ValidationResult;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.*;

import java.awt.Desktop;
import java.net.URI;
import java.util.concurrent.CompletableFuture;

/**
 * Professional license activation dialog.
 * Shows on first launch or when license is invalid.
 */
public class LicenseActivationDialog extends Stage {

    private TextField  keyField;
    private Button     activateBtn;
    private Label      statusLabel;
    private ProgressBar progressBar;
    private boolean    activated = false;

    public LicenseActivationDialog() {
        setTitle("School ERP — Activate License");
        initStyle(StageStyle.DECORATED);
        setResizable(false);
        setWidth(520);
        setHeight(480);
        centerOnScreen();

        // Close = exit app
        setOnCloseRequest(e -> { Platform.exit(); System.exit(0); });

        VBox root = buildUI();
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/license-styles.css").toExternalForm());
        setScene(scene);
    }

    private VBox buildUI() {
        VBox root = new VBox(0);
        root.getStyleClass().add("root-pane");

        // ── Header ────────────────────────────────────────────────────────────
        VBox header = new VBox(8);
        header.getStyleClass().add("header");
        header.setPadding(new Insets(32, 32, 24, 32));
        header.setAlignment(Pos.CENTER);

        Label logo = new Label("🏫");
        logo.setStyle("-fx-font-size: 48px;");

        Label title = new Label("School Management ERP");
        title.getStyleClass().add("title");

        Label subtitle = new Label("Enter your license key to activate");
        subtitle.getStyleClass().add("subtitle");

        header.getChildren().addAll(logo, title, subtitle);

        // ── Key input area ────────────────────────────────────────────────────
        VBox form = new VBox(16);
        form.setPadding(new Insets(24, 32, 0, 32));

        Label keyLabel = new Label("License Key");
        keyLabel.getStyleClass().add("field-label");

        keyField = new TextField();
        keyField.setPromptText("XXXXX-XXXXX-XXXXX-XXXXX-XXXXX");
        keyField.getStyleClass().add("key-field");
        keyField.setMaxWidth(Double.MAX_VALUE);

        // Auto-format as user types (add dashes every 5 chars)
        keyField.textProperty().addListener((obs, old, now) -> {
            if (now.length() > old.length()) {  // only on insert
                String clean = now.toUpperCase().replaceAll("[^A-Z0-9]", "");
                if (clean.length() > 25) clean = clean.substring(0, 25);
                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    if (i > 0 && i % 5 == 0) formatted.append('-');
                    formatted.append(clean.charAt(i));
                }
                String result = formatted.toString();
                if (!result.equals(now)) {
                    keyField.setText(result);
                    keyField.positionCaret(result.length());
                }
            }
        });

        // Status label
        statusLabel = new Label("");
        statusLabel.getStyleClass().add("status-label");
        statusLabel.setWrapText(true);
        statusLabel.setMaxWidth(Double.MAX_VALUE);

        // Progress bar (hidden until activation)
        progressBar = new ProgressBar(-1);
        progressBar.getStyleClass().add("progress-bar");
        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setVisible(false);

        // Activate button
        activateBtn = new Button("Activate License");
        activateBtn.getStyleClass().add("activate-btn");
        activateBtn.setMaxWidth(Double.MAX_VALUE);
        activateBtn.setDefaultButton(true);
        activateBtn.setOnAction(e -> doActivate());

        form.getChildren().addAll(keyLabel, keyField, progressBar, statusLabel, activateBtn);

        // ── Footer links ──────────────────────────────────────────────────────
        VBox footer = new VBox(8);
        footer.setPadding(new Insets(20, 32, 24, 32));
        footer.setAlignment(Pos.CENTER);

        Hyperlink buyLink = new Hyperlink("Don't have a license? Buy at vexenlabs.com");
        buyLink.getStyleClass().add("footer-link");
        buyLink.setOnAction(e -> openUrl("https://vexenlabs.com/products/school-erp"));

        Hyperlink dashboardLink = new Hyperlink("Find your license key in your dashboard");
        dashboardLink.getStyleClass().add("footer-link");
        dashboardLink.setOnAction(e -> openUrl("https://vexenlabs.com/dashboard"));

        Hyperlink supportLink = new Hyperlink("Having trouble? Contact support");
        supportLink.getStyleClass().add("footer-link-small");
        supportLink.setOnAction(e -> openUrl("https://vexenlabs.com/contact"));

        footer.getChildren().addAll(buyLink, dashboardLink, supportLink);

        // Spacer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        root.getChildren().addAll(header, form, spacer, footer);
        return root;
    }

    private void doActivate() {
        String key = keyField.getText().trim();
        if (key.length() < 29) {
            setStatus("Please enter a complete license key (XXXXX-XXXXX-XXXXX-XXXXX-XXXXX)", "error");
            return;
        }

        setLoading(true);
        setStatus("Connecting to license server…", "info");

        CompletableFuture.supplyAsync(() -> LicenseValidator.activate(key))
            .thenAccept(response -> Platform.runLater(() -> handleResponse(response)));
    }

    private void handleResponse(ValidationResponse response) {
        setLoading(false);

        switch (response.result) {
            case ACTIVATED:
                setStatus("✓ " + response.message, "success");
                activated = true;
                // Close after 1.5 seconds
                new Thread(() -> {
                    try { Thread.sleep(1500); } catch (InterruptedException ignored) {}
                    Platform.runLater(this::close);
                }).start();
                break;

            case MAX_DEVICES:
                setStatus("❌ Maximum devices reached.\nDeactivate an old device at vexenlabs.com/dashboard to free a slot.", "error");
                break;

            case EXPIRED:
                setStatus("❌ This license has expired. Please renew at vexenlabs.com", "error");
                break;

            case REVOKED:
                setStatus("❌ This license has been revoked. Contact support@vexenlabs.com", "error");
                break;

            case SERVER_ERROR:
                setStatus("⚠ " + response.message, "warning");
                break;

            default:
                setStatus("❌ " + response.message, "error");
        }
    }

    private void setLoading(boolean loading) {
        progressBar.setVisible(loading);
        activateBtn.setDisable(loading);
        keyField.setDisable(loading);
        activateBtn.setText(loading ? "Activating…" : "Activate License");
    }

    private void setStatus(String msg, String type) {
        statusLabel.setText(msg);
        statusLabel.getStyleClass().removeAll("status-error", "status-success", "status-warning", "status-info");
        statusLabel.getStyleClass().add("status-" + type);
    }

    private void openUrl(String url) {
        try { Desktop.getDesktop().browse(new URI(url)); } catch (Exception ignored) {}
    }

    public boolean isActivated() { return activated; }
}
