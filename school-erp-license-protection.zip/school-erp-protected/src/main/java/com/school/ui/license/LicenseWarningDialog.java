package com.school.ui.license;

import com.school.license.LicenseStorage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

import java.awt.Desktop;
import java.net.URI;

/**
 * Warning dialogs for license status:
 * - Expiring soon warning
 * - Offline grace period warning
 * - License expired / blocked dialog
 */
public class LicenseWarningDialog extends Stage {

    public enum WarningType { EXPIRING_SOON, OFFLINE_GRACE, EXPIRED, OFFLINE_BLOCKED }

    public LicenseWarningDialog(WarningType type, LicenseStorage license, String message) {
        setTitle("License Status — School ERP");
        initStyle(StageStyle.DECORATED);
        setResizable(false);
        setWidth(440);
        setAlwaysOnTop(true);
        centerOnScreen();

        VBox root = new VBox(20);
        root.setPadding(new Insets(32));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #0e0f1e;");

        // Icon + title
        String icon = switch (type) {
            case EXPIRING_SOON  -> "⏰";
            case OFFLINE_GRACE  -> "📡";
            case EXPIRED        -> "🔒";
            case OFFLINE_BLOCKED -> "🚫";
        };

        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 48px;");

        String titleText = switch (type) {
            case EXPIRING_SOON   -> "License Expiring Soon";
            case OFFLINE_GRACE   -> "Running in Offline Mode";
            case EXPIRED         -> "License Expired";
            case OFFLINE_BLOCKED -> "License Verification Required";
        };

        Label titleLabel = new Label(titleText);
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: white; -fx-font-family: 'Segoe UI';");

        Label msgLabel = new Label(message);
        msgLabel.setStyle("-fx-text-fill: #9e9ec8; -fx-font-size: 13px; -fx-font-family: 'Segoe UI';");
        msgLabel.setWrapText(true);
        msgLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        msgLabel.setMaxWidth(380);

        // License info card
        if (license != null) {
            VBox card = new VBox(6);
            card.setStyle("-fx-background-color: #1a1b3c; -fx-border-color: #2e22b5; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 12;");
            if (license.getUserName() != null && !license.getUserName().isEmpty())
                card.getChildren().add(infoRow("Licensee", license.getUserName()));
            card.getChildren().add(infoRow("Plan",     license.getPlanName()));
            if (license.getExpiresAt() != null)
                card.getChildren().add(infoRow("Expires", license.getExpiresAt().toString()));
            else
                card.getChildren().add(infoRow("Validity", "Lifetime"));
            root.getChildren().add(card);
        }

        // Buttons
        HBox buttons = new HBox(12);
        buttons.setAlignment(Pos.CENTER);

        if (type == WarningType.EXPIRING_SOON || type == WarningType.EXPIRED) {
            Button renewBtn = new Button("Renew License");
            renewBtn.setStyle("-fx-background-color: #f6c84b; -fx-text-fill: #080916; -fx-font-weight: bold; -fx-font-size: 13px; -fx-padding: 10 20; -fx-background-radius: 8; -fx-cursor: hand;");
            renewBtn.setOnAction(e -> { openUrl("https://vexenlabs.com/dashboard"); close(); });
            buttons.getChildren().add(renewBtn);
        }

        if (type == WarningType.EXPIRING_SOON || type == WarningType.OFFLINE_GRACE) {
            Button continueBtn = new Button("Continue Using");
            continueBtn.setStyle("-fx-background-color: #1a1b3c; -fx-text-fill: #9e9ec8; -fx-font-size: 13px; -fx-padding: 10 20; -fx-border-color: #2e22b5; -fx-border-radius: 8; -fx-background-radius: 8; -fx-cursor: hand;");
            continueBtn.setOnAction(e -> close());
            buttons.getChildren().add(continueBtn);
        }

        if (type == WarningType.EXPIRED || type == WarningType.OFFLINE_BLOCKED) {
            Button exitBtn = new Button("Exit Application");
            exitBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #666; -fx-font-size: 12px; -fx-cursor: hand;");
            exitBtn.setOnAction(e -> { javafx.application.Platform.exit(); System.exit(0); });
            buttons.getChildren().add(exitBtn);
        }

        root.getChildren().addAll(iconLabel, titleLabel, msgLabel, buttons);
        setScene(new Scene(root));
    }

    private Label infoRow(String label, String value) {
        Label l = new Label(label + ": " + value);
        l.setStyle("-fx-text-fill: #9e9ec8; -fx-font-size: 12px; -fx-font-family: 'Segoe UI Mono';");
        return l;
    }

    private void openUrl(String url) {
        try { Desktop.getDesktop().browse(new URI(url)); } catch (Exception ignored) {}
    }
}
