package com.school.license;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.logging.Logger;

/**
 * Stores and retrieves the license activation data from disk.
 * Data is AES-128 encrypted so users can't manually edit it.
 *
 * Storage location: %APPDATA%\VexenLabs\SchoolERP\license.dat
 */
public class LicenseStorage {

    private static final Logger log = Logger.getLogger(LicenseStorage.class.getName());

    // AES key derived from machine ID + app secret — unique per machine
    private static final String APP_SECRET = "VEXENLABS_SCHOOL_ERP_2024";

    private String licenseKey;
    private String planName;
    private String productName;
    private String userEmail;
    private String userName;
    private LocalDate activatedAt;
    private LocalDate expiresAt;         // null = lifetime
    private LocalDate lastValidated;
    private int maxDevices;
    private boolean isActive;

    // ── Serialisation ────────────────────────────────────────────────────────
    public void save() throws Exception {
        String data = serialize();
        String encrypted = encrypt(data);
        Files.writeString(getStoragePath(), encrypted);
        log.info("License saved to " + getStoragePath());
    }

    public static LicenseStorage load() {
        try {
            Path path = getStoragePath();
            if (!Files.exists(path)) return null;
            String encrypted = Files.readString(path);
            String data = decrypt(encrypted);
            return deserialize(data);
        } catch (Exception e) {
            log.warning("Could not load license: " + e.getMessage());
            return null;
        }
    }

    public static void delete() {
        try { Files.deleteIfExists(getStoragePath()); } catch (Exception ignored) {}
    }

    // ── Path ─────────────────────────────────────────────────────────────────
    public static Path getStoragePath() throws Exception {
        String appData = System.getenv("APPDATA");
        if (appData == null) appData = System.getProperty("user.home");
        Path dir = Paths.get(appData, "VexenLabs", "SchoolERP");
        Files.createDirectories(dir);
        return dir.resolve("license.dat");
    }

    // ── Crypto ───────────────────────────────────────────────────────────────
    private static byte[] deriveKey() throws Exception {
        String raw = APP_SECRET + MachineFingerprint.getMachineId().substring(0, 8);
        byte[] hash = MachineFingerprint.sha256(raw).getBytes("UTF-8");
        byte[] key = new byte[16];
        System.arraycopy(hash, 0, key, 0, 16);
        return key;
    }

    private static String encrypt(String plain) throws Exception {
        SecretKeySpec key = new SecretKeySpec(deriveKey(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return Base64.getEncoder().encodeToString(cipher.doFinal(plain.getBytes("UTF-8")));
    }

    private static String decrypt(String encrypted) throws Exception {
        SecretKeySpec key = new SecretKeySpec(deriveKey(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key);
        return new String(cipher.doFinal(Base64.getDecoder().decode(encrypted)), "UTF-8");
    }

    // ── Serialisation ────────────────────────────────────────────────────────
    private String serialize() {
        DateTimeFormatter fmt = DateTimeFormatter.ISO_LOCAL_DATE;
        return String.join("|",
            licenseKey    == null ? "" : licenseKey,
            planName      == null ? "" : planName,
            productName   == null ? "" : productName,
            userEmail     == null ? "" : userEmail,
            userName      == null ? "" : userName,
            activatedAt   == null ? "" : activatedAt.format(fmt),
            expiresAt     == null ? "LIFETIME" : expiresAt.format(fmt),
            lastValidated == null ? "" : lastValidated.format(fmt),
            String.valueOf(maxDevices),
            String.valueOf(isActive)
        );
    }

    private static LicenseStorage deserialize(String data) {
        String[] parts = data.split("\\|", -1);
        if (parts.length < 10) throw new IllegalArgumentException("Invalid license data");
        DateTimeFormatter fmt = DateTimeFormatter.ISO_LOCAL_DATE;
        LicenseStorage ls = new LicenseStorage();
        ls.licenseKey    = parts[0];
        ls.planName      = parts[1];
        ls.productName   = parts[2];
        ls.userEmail     = parts[3];
        ls.userName      = parts[4];
        ls.activatedAt   = parts[5].isEmpty() ? null : LocalDate.parse(parts[5], fmt);
        ls.expiresAt     = parts[6].equals("LIFETIME") ? null : LocalDate.parse(parts[6], fmt);
        ls.lastValidated = parts[7].isEmpty() ? null : LocalDate.parse(parts[7], fmt);
        ls.maxDevices    = Integer.parseInt(parts[8]);
        ls.isActive      = Boolean.parseBoolean(parts[9]);
        return ls;
    }

    // ── Validation helpers ────────────────────────────────────────────────────
    public boolean isExpired() {
        return expiresAt != null && LocalDate.now().isAfter(expiresAt);
    }

    public boolean isValid() {
        return isActive && !isExpired();
    }

    public boolean needsOnlineValidation() {
        if (lastValidated == null) return true;
        return LocalDate.now().isAfter(lastValidated.plusDays(30));
    }

    public long daysUntilExpiry() {
        if (expiresAt == null) return Long.MAX_VALUE;
        return java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), expiresAt);
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────
    public String getLicenseKey()    { return licenseKey; }
    public String getPlanName()      { return planName; }
    public String getProductName()   { return productName; }
    public String getUserEmail()     { return userEmail; }
    public String getUserName()      { return userName; }
    public LocalDate getActivatedAt(){ return activatedAt; }
    public LocalDate getExpiresAt()  { return expiresAt; }
    public LocalDate getLastValidated(){ return lastValidated; }
    public int getMaxDevices()       { return maxDevices; }
    public boolean isIsActive()      { return isActive; }

    public void setLicenseKey(String v)    { licenseKey = v; }
    public void setPlanName(String v)      { planName = v; }
    public void setProductName(String v)   { productName = v; }
    public void setUserEmail(String v)     { userEmail = v; }
    public void setUserName(String v)      { userName = v; }
    public void setActivatedAt(LocalDate v){ activatedAt = v; }
    public void setExpiresAt(LocalDate v)  { expiresAt = v; }
    public void setLastValidated(LocalDate v){ lastValidated = v; }
    public void setMaxDevices(int v)       { maxDevices = v; }
    public void setIsActive(boolean v)     { isActive = v; }
}
