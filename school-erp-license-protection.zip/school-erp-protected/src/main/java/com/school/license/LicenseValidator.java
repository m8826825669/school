package com.school.license;

import java.net.URI;
import java.net.http.*;
import java.time.LocalDate;
import java.util.logging.Logger;
import org.json.JSONObject;

/**
 * Validates license keys against the Vexen Labs API.
 * Handles: activation, validation, offline grace period.
 *
 * API endpoint: https://vexenlabs.com/api/licenses/validate/
 */
public class LicenseValidator {

    private static final Logger log = Logger.getLogger(LicenseValidator.class.getName());

    public static final String API_BASE        = "https://vexenlabs.com/api";
    public static final String PRODUCT_SLUG    = "school-erp";
    public static final int    OFFLINE_GRACE   = 30;   // days offline before blocking
    public static final int    EXPIRY_WARN_DAYS = 14;  // warn user N days before expiry

    public enum ValidationResult {
        VALID,              // License is valid, good to go
        ACTIVATED,          // Just activated for the first time on this machine
        INVALID_KEY,        // Key doesn't exist
        EXPIRED,            // License has expired
        MAX_DEVICES,        // Too many activations
        REVOKED,            // Admin revoked this license
        OFFLINE_GRACE,      // Can't reach server, using cached — within grace period
        OFFLINE_BLOCKED,    // Can't reach server AND grace period exceeded
        SERVER_ERROR,       // Server returned unexpected error
    }

    public static class ValidationResponse {
        public final ValidationResult result;
        public final LicenseStorage   storage;   // populated on success
        public final String           message;

        public ValidationResponse(ValidationResult result, LicenseStorage storage, String message) {
            this.result  = result;
            this.storage = storage;
            this.message = message;
        }

        public boolean isValid() {
            return result == ValidationResult.VALID
                || result == ValidationResult.ACTIVATED
                || result == ValidationResult.OFFLINE_GRACE;
        }
    }

    // ── Activate a new license key ───────────────────────────────────────────
    public static ValidationResponse activate(String licenseKey) {
        String machineId   = MachineFingerprint.getMachineId();
        String machineName = System.getenv("COMPUTERNAME");
        if (machineName == null) machineName = System.getProperty("user.name", "PC");
        String osInfo = MachineFingerprint.getOsInfo();

        try {
            JSONObject body = new JSONObject()
                .put("license_key",  licenseKey.trim().toUpperCase())
                .put("machine_id",   machineId)
                .put("machine_name", machineName)
                .put("os_info",      osInfo)
                .put("product_slug", PRODUCT_SLUG);

            JSONObject response = post("/licenses/validate/", body);

            if (response.optBoolean("valid", false)) {
                LicenseStorage ls = buildStorage(licenseKey, response);
                ls.setActivatedAt(LocalDate.now());
                ls.setLastValidated(LocalDate.now());
                ls.save();
                log.info("License activated successfully: " + licenseKey.substring(0, 5) + "...");
                return new ValidationResponse(ValidationResult.ACTIVATED, ls,
                    "License activated successfully! Welcome to School Management ERP.");
            }

            String error = response.optString("error", "Unknown error");
            if (error.contains("maximum") || error.contains("devices"))
                return new ValidationResponse(ValidationResult.MAX_DEVICES, null, error);
            if (error.contains("expired"))
                return new ValidationResponse(ValidationResult.EXPIRED, null, error);
            if (error.contains("revoked") || error.contains("inactive"))
                return new ValidationResponse(ValidationResult.REVOKED, null, error);

            return new ValidationResponse(ValidationResult.INVALID_KEY, null,
                "Invalid license key. Please check and try again.\n\nGet your key at: vexenlabs.com/dashboard");

        } catch (java.net.ConnectException | java.net.UnknownHostException e) {
            return new ValidationResponse(ValidationResult.SERVER_ERROR, null,
                "Cannot connect to license server. Please check your internet connection and try again.");
        } catch (Exception e) {
            log.warning("Activation error: " + e.getMessage());
            return new ValidationResponse(ValidationResult.SERVER_ERROR, null,
                "Activation failed: " + e.getMessage());
        }
    }

    // ── Validate existing (cached) license ────────────────────────────────────
    public static ValidationResponse validateCached() {
        LicenseStorage stored = LicenseStorage.load();

        if (stored == null) {
            return new ValidationResponse(ValidationResult.INVALID_KEY, null,
                "No license found. Please enter your license key.");
        }

        // Check if locally stored license is expired
        if (stored.isExpired()) {
            return new ValidationResponse(ValidationResult.EXPIRED, stored,
                "Your license expired on " + stored.getExpiresAt() + ". Please renew at vexenlabs.com");
        }

        // Don't need online validation yet
        if (!stored.needsOnlineValidation()) {
            log.info("Using cached license (last validated: " + stored.getLastValidated() + ")");
            return new ValidationResponse(ValidationResult.VALID, stored, "License valid.");
        }

        // Try online validation
        try {
            JSONObject body = new JSONObject()
                .put("license_key",  stored.getLicenseKey())
                .put("machine_id",   MachineFingerprint.getMachineId())
                .put("machine_name", System.getenv("COMPUTERNAME"))
                .put("os_info",      MachineFingerprint.getOsInfo())
                .put("product_slug", PRODUCT_SLUG);

            JSONObject response = post("/licenses/validate/", body);

            if (response.optBoolean("valid", false)) {
                stored.setLastValidated(LocalDate.now());
                // Update expiry from server in case plan changed
                String expiresAt = response.optString("expires_at", "");
                if (!expiresAt.isEmpty() && !expiresAt.equals("null")) {
                    stored.setExpiresAt(LocalDate.parse(expiresAt.substring(0, 10)));
                }
                stored.save();
                return new ValidationResponse(ValidationResult.VALID, stored, "License valid.");
            }

            // Server says invalid — revoked or expired
            String error = response.optString("error", "");
            if (error.contains("revoked") || error.contains("inactive")) {
                LicenseStorage.delete();
                return new ValidationResponse(ValidationResult.REVOKED, null,
                    "Your license has been revoked. Contact support@vexenlabs.com");
            }
            if (error.contains("expired")) {
                return new ValidationResponse(ValidationResult.EXPIRED, stored, error);
            }
            return new ValidationResponse(ValidationResult.INVALID_KEY, null, error);

        } catch (java.net.ConnectException | java.net.UnknownHostException e) {
            // Offline — check grace period
            long daysSinceValidated = stored.getLastValidated() == null ? 999 :
                java.time.temporal.ChronoUnit.DAYS.between(stored.getLastValidated(), LocalDate.now());

            if (daysSinceValidated <= OFFLINE_GRACE) {
                log.info("Offline mode — grace period: " + daysSinceValidated + "/" + OFFLINE_GRACE + " days");
                return new ValidationResponse(ValidationResult.OFFLINE_GRACE, stored,
                    "Running in offline mode. License will be verified when internet is available.\n" +
                    "Offline grace: " + daysSinceValidated + "/" + OFFLINE_GRACE + " days used.");
            }
            return new ValidationResponse(ValidationResult.OFFLINE_BLOCKED, null,
                "Cannot verify license. No internet for " + daysSinceValidated + " days (max " + OFFLINE_GRACE + ").\n" +
                "Please connect to the internet to continue using School ERP.");
        } catch (Exception e) {
            log.warning("Online validation failed: " + e.getMessage());
            return new ValidationResponse(ValidationResult.OFFLINE_GRACE, stored,
                "License server unreachable. Using cached license.");
        }
    }

    // ── Deactivate this machine ───────────────────────────────────────────────
    public static boolean deactivate() {
        LicenseStorage stored = LicenseStorage.load();
        if (stored == null) return false;
        try {
            JSONObject body = new JSONObject()
                .put("machine_id", MachineFingerprint.getMachineId());
            post("/licenses/" + stored.getLicenseKey() + "/deactivate/", body);
            LicenseStorage.delete();
            return true;
        } catch (Exception e) {
            LicenseStorage.delete(); // delete locally even if API fails
            return false;
        }
    }

    // ── HTTP helpers ──────────────────────────────────────────────────────────
    private static JSONObject post(String path, JSONObject body) throws Exception {
        HttpClient client = HttpClient.newBuilder()
            .connectTimeout(java.time.Duration.ofSeconds(10))
            .build();

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(API_BASE + path))
            .header("Content-Type", "application/json")
            .header("User-Agent",   "SchoolERP/1.0 (Windows)")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
            .timeout(java.time.Duration.ofSeconds(15))
            .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return new JSONObject(response.body());
    }

    private static LicenseStorage buildStorage(String key, JSONObject response) {
        LicenseStorage ls = new LicenseStorage();
        ls.setLicenseKey(key.trim().toUpperCase());
        ls.setPlanName(response.optString("plan", "Standard"));
        ls.setProductName("School Management ERP");
        ls.setUserEmail(response.optString("user_email", ""));
        ls.setUserName(response.optString("user_name", ""));
        ls.setMaxDevices(response.optInt("max_activations", 1));
        ls.setIsActive(true);

        String expiresAt = response.optString("expires_at", "");
        if (!expiresAt.isEmpty() && !expiresAt.equals("null")) {
            ls.setExpiresAt(LocalDate.parse(expiresAt.substring(0, 10)));
        }
        return ls;
    }
}
