package com.school.license;

import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

/**
 * Generates a stable hardware fingerprint from:
 * - MAC addresses of all network interfaces
 * - CPU info (via OS-specific commands)
 * - Disk serial (via WMIC on Windows)
 *
 * The fingerprint is stable across reboots but changes if
 * hardware is significantly changed (new NIC, new disk).
 */
public class MachineFingerprint {

    private static final Logger log = Logger.getLogger(MachineFingerprint.class.getName());
    private static String cachedFingerprint = null;

    /** Returns a stable 32-char hex machine ID. */
    public static synchronized String getMachineId() {
        if (cachedFingerprint != null) return cachedFingerprint;

        try {
            StringBuilder raw = new StringBuilder();

            // 1. MAC addresses (most stable identifier)
            List<String> macs = getMacAddresses();
            Collections.sort(macs);
            for (String mac : macs) raw.append(mac);

            // 2. Computer name
            raw.append(getEnv("COMPUTERNAME", "HOSTNAME"));

            // 3. Windows disk serial (best hardware ID on Windows)
            String diskSerial = runCommand("wmic", "diskdrive", "get", "SerialNumber");
            if (!diskSerial.isEmpty()) raw.append(diskSerial.trim().replaceAll("\\s+", ""));

            // 4. CPU ID via WMIC
            String cpuId = runCommand("wmic", "cpu", "get", "ProcessorId");
            if (!cpuId.isEmpty()) raw.append(cpuId.trim().replaceAll("\\s+", ""));

            cachedFingerprint = sha256(raw.toString()).substring(0, 32).toUpperCase();
            log.info("Machine ID generated: " + cachedFingerprint.substring(0, 8) + "...");
            return cachedFingerprint;

        } catch (Exception e) {
            log.warning("Fingerprint generation failed, using fallback: " + e.getMessage());
            // Fallback: use computer name + user name
            String fallback = System.getenv("COMPUTERNAME") + System.getProperty("user.name");
            cachedFingerprint = sha256(fallback).substring(0, 32).toUpperCase();
            return cachedFingerprint;
        }
    }

    private static List<String> getMacAddresses() {
        List<String> macs = new ArrayList<>();
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : interfaces) {
                if (ni.isLoopback() || ni.isVirtual()) continue;
                byte[] mac = ni.getHardwareAddress();
                if (mac == null || mac.length == 0) continue;
                StringBuilder sb = new StringBuilder();
                for (byte b : mac) sb.append(String.format("%02X", b));
                if (!sb.toString().equals("000000000000")) {
                    macs.add(sb.toString());
                }
            }
        } catch (Exception e) {
            log.warning("Could not get MAC addresses: " + e.getMessage());
        }
        return macs;
    }

    private static String runCommand(String... cmd) {
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            byte[] bytes = p.getInputStream().readAllBytes();
            return new String(bytes);
        } catch (Exception e) {
            return "";
        }
    }

    private static String getEnv(String... keys) {
        for (String key : keys) {
            String val = System.getenv(key);
            if (val != null && !val.isEmpty()) return val;
        }
        return System.getProperty("user.name", "unknown");
    }

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (Exception e) {
            return input.hashCode() + "0".repeat(32);
        }
    }

    public static String getOsInfo() {
        return System.getProperty("os.name") + " " + System.getProperty("os.version");
    }
}
