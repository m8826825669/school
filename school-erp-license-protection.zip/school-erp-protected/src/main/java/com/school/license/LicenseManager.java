package com.school.license;

import com.school.ui.license.LicenseActivationDialog;
import com.school.ui.license.LicenseWarningDialog;
import com.school.ui.license.LicenseWarningDialog.WarningType;

import javafx.application.Platform;
import javafx.stage.Stage;
import java.util.logging.Logger;

/**
 * ══════════════════════════════════════════════════════════════════
 *  LicenseManager — Call checkLicense(primaryStage) FIRST in
 *  your App.start() method before showing the main window.
 *
 *  Flow:
 *  1. Load cached license from disk
 *  2. If none → show activation dialog
 *  3. If cached → validate online (or use grace period)
 *  4. If expiring soon → show warning
 *  5. If expired/revoked → block and show error
 *  6. Return true if app should continue, false if it should exit
 * ══════════════════════════════════════════════════════════════════
 */
public class LicenseManager {

    private static final Logger log = Logger.getLogger(LicenseManager.class.getName());

    /**
     * Main license check — call this at the start of App.start().
     * Blocks until license is validated or user exits.
     *
     * @return true if license valid and app should start, false to exit
     */
    public static boolean checkLicense(Stage ownerStage) {
        LicenseValidator.ValidationResponse response = LicenseValidator.validateCached();

        switch (response.result) {

            case VALID:
            case OFFLINE_GRACE: {
                LicenseStorage ls = response.storage;

                // Show offline warning if in grace period
                if (response.result == LicenseValidator.ValidationResult.OFFLINE_GRACE) {
                    showAndWait(new LicenseWarningDialog(WarningType.OFFLINE_GRACE, ls, response.message));
                }

                // Show expiry warning if expiring soon
                if (ls != null && ls.getExpiresAt() != null) {
                    long daysLeft = ls.daysUntilExpiry();
                    if (daysLeft <= LicenseValidator.EXPIRY_WARN_DAYS && daysLeft > 0) {
                        showAndWait(new LicenseWarningDialog(WarningType.EXPIRING_SOON, ls,
                            "Your license expires in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s") +
                            ".\nRenew now to avoid interruption."));
                    }
                }
                log.info("License valid. Starting application.");
                return true;
            }

            case INVALID_KEY: {
                // No license stored — show activation dialog
                LicenseActivationDialog dialog = new LicenseActivationDialog();
                dialog.showAndWait();
                if (dialog.isActivated()) {
                    log.info("License activated. Starting application.");
                    return true;
                }
                // User closed dialog without activating
                return false;
            }

            case EXPIRED: {
                LicenseWarningDialog dlg = new LicenseWarningDialog(
                    WarningType.EXPIRED, response.storage,
                    "Your School ERP license has expired.\n" +
                    "Please renew your license to continue using the application.");
                dlg.showAndWait();
                return false;
            }

            case REVOKED: {
                LicenseWarningDialog dlg = new LicenseWarningDialog(
                    WarningType.EXPIRED, null,
                    "Your license has been revoked.\n" +
                    "Please contact support@vexenlabs.com for assistance.");
                dlg.showAndWait();
                LicenseStorage.delete();
                return false;
            }

            case OFFLINE_BLOCKED: {
                LicenseWarningDialog dlg = new LicenseWarningDialog(
                    WarningType.OFFLINE_BLOCKED, null,
                    "License could not be verified for " +
                    LicenseValidator.OFFLINE_GRACE + " days.\n" +
                    "Please connect to the internet to continue.");
                dlg.showAndWait();
                return false;
            }

            default:
                log.warning("Unexpected validation result: " + response.result);
                return false;
        }
    }

    /**
     * Get the currently active license (after checkLicense passes).
     * Returns null if no valid license.
     */
    public static LicenseStorage getCurrentLicense() {
        return LicenseStorage.load();
    }

    /**
     * Deactivate this machine — call from Settings → Deactivate License.
     */
    public static boolean deactivateCurrentMachine() {
        return LicenseValidator.deactivate();
    }

    private static void showAndWait(javafx.stage.Stage stage) {
        stage.showAndWait();
    }
}
