package com.school;

import com.school.license.LicenseManager;
import com.school.license.LicenseStorage;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * ══════════════════════════════════════════════════════════════════
 *  School Management ERP — Main Application Entry Point
 *  Protected by Vexen Labs License System
 * ══════════════════════════════════════════════════════════════════
 *
 *  INTEGRATION INSTRUCTIONS:
 *  Replace your existing App.java with this file.
 *  The only additions are:
 *    1. LicenseManager.checkLicense(stage) call in start()
 *    2. License info in the about dialog / title bar
 *
 *  Everything else stays the same.
 * ══════════════════════════════════════════════════════════════════
 */
@SpringBootApplication
public class App extends Application {

    private static ConfigurableApplicationContext springContext;

    public static void main(String[] args) {
        // Spring Boot starts embedded server in background
        springContext = SpringApplication.run(App.class, args);
        // Launch JavaFX
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        // ══════════════════════════════════════════════════════════════
        //  LICENSE CHECK — must be FIRST, before anything else shows
        // ══════════════════════════════════════════════════════════════
        boolean licenseValid = LicenseManager.checkLicense(primaryStage);

        if (!licenseValid) {
            // License invalid / user cancelled → exit cleanly
            Platform.exit();
            if (springContext != null) springContext.close();
            System.exit(0);
            return;
        }

        // ══════════════════════════════════════════════════════════════
        //  LICENSE IS VALID — start the main application
        // ══════════════════════════════════════════════════════════════

        // Get license info to display in title bar
        LicenseStorage license = LicenseManager.getCurrentLicense();
        String titleSuffix = license != null
            ? " — " + license.getPlanName() + " | " + license.getUserEmail()
            : "";

        // Load main window — replace with your actual FXML loader
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/main-view.fxml"));
        loader.setControllerFactory(springContext::getBean);

        Scene scene = new Scene(loader.load(), 1280, 800);
        scene.getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());

        primaryStage.setTitle("School Management ERP" + titleSuffix);
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1024);
        primaryStage.setMinHeight(700);
        primaryStage.setMaximized(true);

        // Set app icon
        try {
            primaryStage.getIcons().add(new Image(
                getClass().getResourceAsStream("/images/app-icon.png")));
        } catch (Exception ignored) {}

        // Handle close
        primaryStage.setOnCloseRequest(event -> {
            Platform.exit();
            if (springContext != null) springContext.close();
            System.exit(0);
        });

        primaryStage.show();
    }

    /**
     * Called from Settings menu → "About / License Info"
     */
    public static void showLicenseInfo(Stage ownerStage) {
        LicenseStorage license = LicenseManager.getCurrentLicense();
        if (license == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("License Info");
            alert.setContentText("No license information found.");
            alert.showAndWait();
            return;
        }

        String info = String.join("\n",
            "Product:     " + license.getProductName(),
            "Plan:        " + license.getPlanName(),
            "Licensee:    " + license.getUserName(),
            "Email:       " + license.getUserEmail(),
            "Activated:   " + (license.getActivatedAt() != null ? license.getActivatedAt() : "—"),
            "Expires:     " + (license.getExpiresAt() != null ? license.getExpiresAt() : "Lifetime"),
            "Devices:     " + license.getMaxDevices() + " max",
            "Last Verified: " + (license.getLastValidated() != null ? license.getLastValidated() : "—")
        );

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("License Information");
        alert.setHeaderText("School Management ERP — License Details");
        alert.setContentText(info);
        alert.initOwner(ownerStage);
        alert.showAndWait();
    }
}
