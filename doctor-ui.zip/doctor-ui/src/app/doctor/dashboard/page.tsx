'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  Stethoscope, User, MapPin, Calendar, Clock, Star,
  Edit3, Plus, CheckCircle, AlertCircle, Clock3, LogOut
} from 'lucide-react'

interface DoctorProfile {
  id: number
  name: string
  email: string
  specialization: string
  qualification: string
  experienceYears: number
  consultationFee: number
  onlineFee: number
  bio: string
  status: string
  rating: number
  clinics: any[]
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any; bg: string }> = {
  PENDING_VERIFICATION: { label: 'Pending Approval', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200', icon: Clock3 },
  ACTIVE:               { label: 'Active',           color: 'text-green-700',  bg: 'bg-green-50 border-green-200',  icon: CheckCircle },
  INACTIVE:             { label: 'Inactive',          color: 'text-gray-700',   bg: 'bg-gray-50 border-gray-200',   icon: AlertCircle },
  SUSPENDED:            { label: 'Suspended',         color: 'text-red-700',    bg: 'bg-red-50 border-red-200',    icon: AlertCircle },
}

export default function DoctorDashboard() {
  const router = useRouter()
  const [profile, setProfile] = useState<DoctorProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [noProfile, setNoProfile] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) { router.push('/login'); return }

    fetch('http://localhost:8083/api/doctors/my-profile', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => {
        if (r.status === 404) { setNoProfile(true); setLoading(false); return null }
        return r.json()
      })
      .then(data => {
        if (data) setProfile(data.data ?? data)
        setLoading(false)
      })
      .catch(() => { setNoProfile(true); setLoading(false) })
  }, [router])

  const logout = () => {
    localStorage.clear()
    router.push('/login')
  }

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
    </div>
  )

  // No profile yet — prompt to register
  if (noProfile) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg p-10 max-w-md w-full text-center">
        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Stethoscope size={36} className="text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-3">Set Up Your Doctor Profile</h2>
        <p className="text-gray-500 mb-8">
          Complete your professional profile to start accepting appointments on DoctorFinder.
        </p>
        <Link href="/doctor/register"
          className="block w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors">
          Create Profile
        </Link>
        <button onClick={logout} className="mt-4 text-sm text-gray-400 hover:text-gray-600">
          Log out
        </button>
      </div>
    </div>
  )

  const status = STATUS_CONFIG[profile?.status ?? ''] ?? STATUS_CONFIG['INACTIVE']
  const StatusIcon = status.icon

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white border-b px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-blue-600 font-bold text-xl">
          <Stethoscope size={22} /> DoctorFinder
        </Link>
        <div className="flex items-center gap-4">
          <Link href="/doctor/profile" className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-blue-600">
            <Edit3 size={15} /> Edit Profile
          </Link>
          <button onClick={logout} className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-red-600">
            <LogOut size={15} /> Logout
          </button>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">

        {/* Status Banner */}
        <div className={`flex items-center gap-3 px-5 py-4 rounded-xl border ${status.bg}`}>
          <StatusIcon size={20} className={status.color} />
          <div>
            <p className={`font-semibold ${status.color}`}>{status.label}</p>
            {profile?.status === 'PENDING_VERIFICATION' && (
              <p className="text-sm text-amber-600 mt-0.5">
                Your profile is under review. You'll be notified once approved.
              </p>
            )}
            {profile?.status === 'ACTIVE' && (
              <p className="text-sm text-green-600 mt-0.5">Your profile is live and accepting appointments.</p>
            )}
          </div>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl shadow-sm border p-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-center gap-5">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center">
                <span className="text-2xl font-bold text-white">
                  {profile?.name?.charAt(0) ?? 'D'}
                </span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Dr. {profile?.name}</h1>
                <p className="text-blue-600 font-medium">{profile?.specialization}</p>
                <p className="text-gray-500 text-sm">{profile?.qualification}</p>
              </div>
            </div>
            <Link href="/doctor/profile"
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">
              <Edit3 size={15} /> Edit Profile
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t">
            {[
              { label: 'Experience', value: `${profile?.experienceYears ?? 0} yrs` },
              { label: 'Consult Fee', value: `₹${profile?.consultationFee ?? 0}` },
              { label: 'Online Fee', value: `₹${profile?.onlineFee ?? 0}` },
              { label: 'Rating', value: `${profile?.rating ?? '0.0'} ★` },
            ].map(({ label, value }) => (
              <div key={label} className="text-center p-3 bg-gray-50 rounded-xl">
                <p className="text-xl font-bold text-gray-900">{value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          {profile?.bio && (
            <div className="mt-4 p-4 bg-blue-50 rounded-xl">
              <p className="text-sm text-gray-700 leading-relaxed">{profile.bio}</p>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            {
              icon: MapPin, title: 'Manage Clinics',
              desc: `${profile?.clinics?.length ?? 0} clinic(s) added`,
              href: '/doctor/profile#clinics', color: 'bg-purple-100 text-purple-600'
            },
            {
              icon: Calendar, title: 'Manage Schedules',
              desc: 'Set your availability',
              href: '/doctor/schedule', color: 'bg-green-100 text-green-600'
            },
            {
              icon: Clock, title: 'View Appointments',
              desc: 'Check upcoming bookings',
              href: '/patient/appointments', color: 'bg-orange-100 text-orange-600'
            },
          ].map(({ icon: Icon, title, desc, href, color }) => (
            <Link key={title} href={href}
              className="bg-white border rounded-2xl p-5 flex items-center gap-4 hover:shadow-md transition-shadow group">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
                <Icon size={22} />
              </div>
              <div>
                <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{title}</p>
                <p className="text-sm text-gray-500">{desc}</p>
              </div>
            </Link>
          ))}
        </div>

        {/* Clinics */}
        <div className="bg-white rounded-2xl shadow-sm border p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold text-gray-900">My Clinics</h2>
            <Link href="/doctor/profile#clinics"
              className="flex items-center gap-1.5 text-sm text-blue-600 font-medium hover:underline">
              <Plus size={16} /> Add Clinic
            </Link>
          </div>

          {!profile?.clinics?.length ? (
            <div className="text-center py-10 text-gray-400">
              <MapPin size={32} className="mx-auto mb-2 opacity-40" />
              <p>No clinics added yet</p>
              <Link href="/doctor/profile#clinics" className="text-blue-600 text-sm hover:underline mt-1 inline-block">
                Add your first clinic
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {profile.clinics.map((c: any) => (
                <div key={c.id} className="flex items-center gap-4 p-4 border rounded-xl hover:bg-gray-50">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <MapPin size={18} className="text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{c.name}</p>
                    <p className="text-sm text-gray-500">{c.address}, {c.city}, {c.state}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
