'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { Stethoscope, Plus, Trash2, Calendar, ArrowLeft, Loader2 } from 'lucide-react'

const DAYS = [
  { value: 1, label: 'Monday' }, { value: 2, label: 'Tuesday' },
  { value: 3, label: 'Wednesday' }, { value: 4, label: 'Thursday' },
  { value: 5, label: 'Friday' }, { value: 6, label: 'Saturday' },
  { value: 7, label: 'Sunday' },
]
const DURATIONS = [10, 15, 20, 30, 45, 60]

interface Schedule {
  id: number
  dayOfWeek: string
  startTime: string
  endTime: string
  slotDurationMinutes: number
  isActive: boolean
}

export default function DoctorSchedulePage() {
  const router = useRouter()
  const [schedules,    setSchedules]    = useState<Schedule[]>([])
  const [loading,      setLoading]      = useState(true)
  const [saving,       setSaving]       = useState(false)
  const [showForm,     setShowForm]     = useState(false)
  const [form, setForm] = useState({
    dayOfWeek: 1, startTime: '09:00', endTime: '17:00', slotDurationMinutes: 30
  })

  const token = () => localStorage.getItem('accessToken') ?? ''
  const authHeaders = () => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` })

  // We need doctorId to fetch schedules by doctor
  const [doctorId, setDoctorId] = useState<number | null>(null)

  useEffect(() => {
    if (!token()) { router.push('/login'); return }
    fetchMyProfile()
  }, [])

  const fetchMyProfile = async () => {
    try {
      const res = await fetch('http://localhost:8083/api/doctors/my-profile', {
        headers: authHeaders()
      })
      const data = await res.json()
      const p = data.data ?? data
      setDoctorId(p.id)
      fetchSchedules(p.id)
    } catch {
      toast.error('Failed to load profile')
      setLoading(false)
    }
  }

  const fetchSchedules = async (id: number) => {
    try {
      const res = await fetch(`http://localhost:8083/api/doctors/${id}/schedules`)
      const data = await res.json()
      setSchedules(Array.isArray(data) ? data : data.data ?? [])
    } finally {
      setLoading(false)
    }
  }

  const addSchedule = async () => {
    if (form.startTime >= form.endTime) {
      toast.error('End time must be after start time')
      return
    }
    setSaving(true)
    try {
      const res = await fetch('http://localhost:8083/api/doctors/schedules', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          dayOfWeek: form.dayOfWeek,
          startTime: form.startTime,
          endTime: form.endTime,
          slotDurationMinutes: form.slotDurationMinutes,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message ?? 'Failed to add schedule')
      setSchedules(prev => [...prev, data.data ?? data])
      setShowForm(false)
      toast.success('Schedule added! Slots generated for next 30 days.')
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setSaving(false)
    }
  }

  const deleteSchedule = async (id: number) => {
    if (!confirm('Delete this schedule? Future unbooked slots will be removed.')) return
    try {
      const res = await fetch(`http://localhost:8083/api/doctors/schedules/${id}`, {
        method: 'DELETE', headers: authHeaders()
      })
      if (!res.ok) throw new Error('Delete failed')
      setSchedules(prev => prev.filter(s => s.id !== id))
      toast.success('Schedule removed')
    } catch (err: any) {
      toast.error(err.message)
    }
  }

  const getDayLabel = (val: string | number) =>
    DAYS.find(d => d.value === Number(val))?.label ?? `Day ${val}`

  // Group schedules by day
  const grouped = DAYS.map(d => ({
    ...d,
    schedules: schedules.filter(s => Number(s.dayOfWeek) === d.value)
  })).filter(d => d.schedules.length > 0)

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 size={32} className="animate-spin text-blue-600" />
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/" className="flex items-center gap-2 text-blue-600 font-bold text-xl">
          <Stethoscope size={22} /> DoctorFinder
        </Link>
        <Link href="/doctor/dashboard" className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600">
          <ArrowLeft size={16} /> Dashboard
        </Link>
      </nav>

      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Schedule</h1>
            <p className="text-gray-500 text-sm mt-1">Set your weekly availability — slots auto-generate for 30 days</p>
          </div>
          <button onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-blue-700">
            <Plus size={16} /> Add Schedule
          </button>
        </div>

        {/* Add Schedule Form */}
        {showForm && (
          <div className="bg-white rounded-2xl border-2 border-blue-200 p-6 space-y-4">
            <h3 className="font-bold text-gray-900">New Schedule Block</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Day of Week</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.dayOfWeek}
                  onChange={e => setForm(p => ({ ...p, dayOfWeek: parseInt(e.target.value) }))}>
                  {DAYS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Slot Duration (min)</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.slotDurationMinutes}
                  onChange={e => setForm(p => ({ ...p, slotDurationMinutes: parseInt(e.target.value) }))}>
                  {DURATIONS.map(d => <option key={d} value={d}>{d} minutes</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
                <input type="time" className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.startTime}
                  onChange={e => setForm(p => ({ ...p, startTime: e.target.value }))} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
                <input type="time" className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.endTime}
                  onChange={e => setForm(p => ({ ...p, endTime: e.target.value }))} />
              </div>
            </div>

            {/* Slot preview */}
            <div className="bg-blue-50 rounded-xl px-4 py-3 text-sm text-blue-800">
              <Calendar size={14} className="inline mr-1.5 mb-0.5" />
              {(() => {
                const [sh, sm] = form.startTime.split(':').map(Number)
                const [eh, em] = form.endTime.split(':').map(Number)
                const mins = (eh * 60 + em) - (sh * 60 + sm)
                const count = mins > 0 ? Math.floor(mins / form.slotDurationMinutes) : 0
                return `${count} slots × ${form.slotDurationMinutes} min on each ${getDayLabel(form.dayOfWeek)}`
              })()}
            </div>

            <div className="flex gap-3">
              <button onClick={addSchedule} disabled={saving}
                className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-60">
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                {saving ? 'Saving…' : 'Create Schedule'}
              </button>
              <button onClick={() => setShowForm(false)}
                className="px-5 py-2.5 border border-gray-300 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Schedule List */}
        {schedules.length === 0 ? (
          <div className="bg-white rounded-2xl border p-12 text-center text-gray-400">
            <Calendar size={40} className="mx-auto mb-3 opacity-40" />
            <p className="font-medium text-gray-500">No schedules yet</p>
            <p className="text-sm mt-1">Add a schedule block to start accepting bookings</p>
            <button onClick={() => setShowForm(true)}
              className="mt-4 px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
              Add First Schedule
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {grouped.map(day => (
              <div key={day.value} className="bg-white rounded-2xl border shadow-sm overflow-hidden">
                <div className="px-5 py-3 bg-gray-50 border-b">
                  <h3 className="font-bold text-gray-900">{day.label}</h3>
                </div>
                <div className="divide-y">
                  {day.schedules.map(s => {
                    const [sh, sm] = s.startTime.split(':').map(Number)
                    const [eh, em] = s.endTime.split(':').map(Number)
                    const mins = (eh * 60 + em) - (sh * 60 + sm)
                    const slots = Math.floor(mins / s.slotDurationMinutes)

                    return (
                      <div key={s.id} className="flex items-center justify-between px-5 py-4 hover:bg-gray-50 group">
                        <div className="flex items-center gap-4">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                          <div>
                            <p className="font-medium text-gray-900">
                              {s.startTime} – {s.endTime}
                            </p>
                            <p className="text-xs text-gray-500 mt-0.5">
                              {s.slotDurationMinutes} min slots · {slots} slots total
                            </p>
                          </div>
                        </div>
                        <button onClick={() => deleteSchedule(s.id)}
                          className="opacity-0 group-hover:opacity-100 p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
