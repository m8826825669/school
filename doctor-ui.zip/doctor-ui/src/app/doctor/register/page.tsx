'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Stethoscope, ChevronRight, ChevronLeft, Check } from 'lucide-react'

const SPECIALIZATIONS = [
  'Cardiologist', 'Dermatologist', 'Orthopedic Surgeon', 'Gynecologist',
  'Neurologist', 'Pediatrician', 'Psychiatrist', 'ENT Specialist',
  'Ophthalmologist', 'Urologist', 'Oncologist', 'General Physician',
  'Endocrinologist', 'Gastroenterologist', 'Pulmonologist', 'Rheumatologist',
]

const LANGUAGES = ['English', 'Hindi', 'Bengali', 'Tamil', 'Telugu', 'Marathi', 'Gujarati', 'Kannada', 'Malayalam', 'Punjabi']

export default function DoctorRegisterPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    specialization: '',
    qualification: '',
    experienceYears: '',
    consultationFee: '',
    onlineFee: '',
    bio: '',
    languagesSpoken: [] as string[],
    mciNumber: '',
    contactPhone: '',
  })

  const set = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => setForm(p => ({ ...p, [k]: e.target.value }))

  const toggleLanguage = (lang: string) => {
    setForm(p => ({
      ...p,
      languagesSpoken: p.languagesSpoken.includes(lang)
        ? p.languagesSpoken.filter(l => l !== lang)
        : [...p.languagesSpoken, lang],
    }))
  }

  const handleSubmit = async () => {
    if (!form.specialization) return toast.error('Specialization is required')
    if (!form.qualification) return toast.error('Qualification is required')

    setLoading(true)
    try {
      const token = localStorage.getItem('accessToken')
      const res = await fetch('http://localhost:8083/api/doctors/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          specialization: form.specialization,
          qualification: form.qualification,
          experienceYears: parseInt(form.experienceYears) || 0,
          consultationFee: parseFloat(form.consultationFee) || 0,
          onlineFee: parseFloat(form.onlineFee) || 0,
          bio: form.bio,
          languagesSpoken: form.languagesSpoken.join(', '),
          mciNumber: form.mciNumber,
          contactPhone: form.contactPhone,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message || 'Registration failed')
      toast.success('Profile submitted! Awaiting admin approval.')
      router.push('/doctor/dashboard')
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <nav className="bg-white border-b px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-blue-600 font-bold text-xl">
          <Stethoscope size={24} /> DoctorFinder
        </Link>
        <span className="text-sm text-gray-500">Doctor Registration</span>
      </nav>

      <div className="max-w-2xl mx-auto px-4 py-10">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {['Professional Info', 'Fees & Bio', 'Contact & Languages'].map((label, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all
                  ${step > i + 1 ? 'bg-green-500 text-white' : step === i + 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                  {step > i + 1 ? <Check size={14} /> : i + 1}
                </div>
                <span className={`text-xs hidden sm:block ${step === i + 1 ? 'text-blue-600 font-medium' : 'text-gray-400'}`}>
                  {label}
                </span>
                {i < 2 && <div className={`w-12 h-0.5 ${step > i + 1 ? 'bg-blue-600' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg border p-8">
          {/* Step 1 */}
          {step === 1 && (
            <div className="space-y-5">
              <h2 className="text-2xl font-bold text-gray-900">Professional Information</h2>
              <p className="text-gray-500 text-sm">Tell us about your medical background</p>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Specialization *</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.specialization} onChange={set('specialization')}>
                  <option value="">Select specialization</option>
                  {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Qualification *</label>
                <input className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. MBBS, MD (Cardiology)" value={form.qualification} onChange={set('qualification')} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Experience (years)</label>
                  <input type="number" min="0" max="60"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="0" value={form.experienceYears} onChange={set('experienceYears')} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">MCI Registration No.</label>
                  <input className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Optional" value={form.mciNumber} onChange={set('mciNumber')} />
                </div>
              </div>
            </div>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <div className="space-y-5">
              <h2 className="text-2xl font-bold text-gray-900">Fees & Bio</h2>
              <p className="text-gray-500 text-sm">Set your consultation fees and write a short bio</p>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Consultation Fee (₹)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-gray-500">₹</span>
                    <input type="number" min="0"
                      className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="500" value={form.consultationFee} onChange={set('consultationFee')} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Online Fee (₹)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-gray-500">₹</span>
                    <input type="number" min="0"
                      className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="300" value={form.onlineFee} onChange={set('onlineFee')} />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                <textarea rows={5}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  placeholder="Tell patients about your expertise, approach to care, and what makes you unique..."
                  value={form.bio} onChange={set('bio')} />
                <p className="text-xs text-gray-400 mt-1">{form.bio.length}/500 characters</p>
              </div>
            </div>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <div className="space-y-5">
              <h2 className="text-2xl font-bold text-gray-900">Contact & Languages</h2>
              <p className="text-gray-500 text-sm">How can patients reach you?</p>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contact Phone</label>
                <input type="tel"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="9876543210" value={form.contactPhone} onChange={set('contactPhone')} />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Languages Spoken</label>
                <div className="flex flex-wrap gap-2">
                  {LANGUAGES.map(lang => (
                    <button key={lang} type="button" onClick={() => toggleLanguage(lang)}
                      className={`px-4 py-2 rounded-full text-sm font-medium border transition-all
                        ${form.languagesSpoken.includes(lang)
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'}`}>
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              {/* Review summary */}
              <div className="bg-blue-50 rounded-xl p-4 space-y-2 text-sm">
                <p className="font-semibold text-blue-800 mb-2">Review your submission</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-gray-700">
                  <span className="text-gray-500">Specialization:</span><span>{form.specialization || '—'}</span>
                  <span className="text-gray-500">Qualification:</span><span>{form.qualification || '—'}</span>
                  <span className="text-gray-500">Experience:</span><span>{form.experienceYears || 0} years</span>
                  <span className="text-gray-500">Consult fee:</span><span>₹{form.consultationFee || 0}</span>
                  <span className="text-gray-500">Online fee:</span><span>₹{form.onlineFee || 0}</span>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-8 pt-6 border-t">
            {step > 1 ? (
              <button onClick={() => setStep(s => s - 1)}
                className="flex items-center gap-2 px-5 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">
                <ChevronLeft size={18} /> Back
              </button>
            ) : <div />}

            {step < 3 ? (
              <button onClick={() => setStep(s => s + 1)}
                className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                Next <ChevronRight size={18} />
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={loading}
                className="flex items-center gap-2 px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium disabled:opacity-60">
                {loading ? 'Submitting…' : <><Check size={18} /> Submit Profile</>}
              </button>
            )}
          </div>
        </div>

        <p className="text-center text-sm text-gray-500 mt-6">
          Your profile will be reviewed by admin before going live.
          Already registered? <Link href="/doctor/dashboard" className="text-blue-600 hover:underline">Go to dashboard</Link>
        </p>
      </div>
    </div>
  )
}
