'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Stethoscope, Save, Plus, Trash2, MapPin, ArrowLeft, Loader2 } from 'lucide-react'

const SPECIALIZATIONS = [
  'Cardiologist', 'Dermatologist', 'Orthopedic Surgeon', 'Gynecologist',
  'Neurologist', 'Pediatrician', 'Psychiatrist', 'ENT Specialist',
  'Ophthalmologist', 'Urologist', 'Oncologist', 'General Physician',
  'Endocrinologist', 'Gastroenterologist', 'Pulmonologist', 'Rheumatologist',
]

interface ClinicForm {
  name: string; address: string; city: string; state: string; pincode: string
}

const EMPTY_CLINIC: ClinicForm = { name: '', address: '', city: '', state: '', pincode: '' }

export default function DoctorProfilePage() {
  const router = useRouter()
  const clinicsRef = useRef<HTMLDivElement>(null)

  const [loading,       setLoading]       = useState(true)
  const [saving,        setSaving]        = useState(false)
  const [clinicLoading, setClinicLoading] = useState(false)
  const [doctorId,      setDoctorId]      = useState<number | null>(null)
  const [clinics,       setClinics]       = useState<any[]>([])
  const [showAddClinic, setShowAddClinic] = useState(false)
  const [clinicForm,    setClinicForm]    = useState<ClinicForm>(EMPTY_CLINIC)

  const [form, setForm] = useState({
    specialization: '', qualification: '', experienceYears: '',
    consultationFee: '', onlineFee: '', bio: '', languagesSpoken: '',
  })

  const token = () => localStorage.getItem('accessToken') ?? ''
  const authHeaders = () => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` })

  useEffect(() => {
    if (!token()) { router.push('/login'); return }
    fetchProfile()
  }, [])

  // Scroll to clinics section if hash present
  useEffect(() => {
    if (window.location.hash === '#clinics') {
      setTimeout(() => clinicsRef.current?.scrollIntoView({ behavior: 'smooth' }), 400)
    }
  }, [loading])

  const fetchProfile = async () => {
    try {
      const res = await fetch('http://localhost:8083/api/doctors/my-profile', {
        headers: authHeaders()
      })
      if (res.status === 404) { router.push('/doctor/register'); return }
      const data = await res.json()
      const p = data.data ?? data
      setDoctorId(p.id)
      setForm({
        specialization:  p.specialization  ?? '',
        qualification:   p.qualification   ?? '',
        experienceYears: String(p.experienceYears ?? 0),
        consultationFee: String(p.consultationFee ?? 0),
        onlineFee:       String(p.onlineFee       ?? 0),
        bio:             p.bio             ?? '',
        languagesSpoken: p.languagesSpoken ?? '',
      })
      setClinics(p.clinics ?? [])
    } catch {
      toast.error('Failed to load profile')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('http://localhost:8083/api/doctors/my-profile', {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify({
          specialization:  form.specialization,
          qualification:   form.qualification,
          experienceYears: parseInt(form.experienceYears) || 0,
          consultationFee: parseFloat(form.consultationFee) || 0,
          onlineFee:       parseFloat(form.onlineFee) || 0,
          bio:             form.bio,
          languagesSpoken: form.languagesSpoken,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message ?? 'Save failed')
      toast.success('Profile updated successfully!')
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setSaving(false)
    }
  }

  const addClinic = async () => {
    if (!clinicForm.name || !clinicForm.address || !clinicForm.city || !clinicForm.state) {
      toast.error('Please fill all required clinic fields')
      return
    }
    setClinicLoading(true)
    try {
      const res = await fetch('http://localhost:8083/api/doctors/clinics', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify(clinicForm),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message ?? 'Failed to add clinic')
      setClinics(prev => [...prev, data.data ?? data])
      setClinicForm(EMPTY_CLINIC)
      setShowAddClinic(false)
      toast.success('Clinic added!')
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setClinicLoading(false)
    }
  }

  const deleteClinic = async (clinicId: number) => {
    if (!confirm('Remove this clinic?')) return
    try {
      const res = await fetch(`http://localhost:8083/api/doctors/clinics/${clinicId}`, {
        method: 'DELETE', headers: authHeaders()
      })
      if (!res.ok) throw new Error('Delete failed')
      setClinics(prev => prev.filter(c => c.id !== clinicId))
      toast.success('Clinic removed')
    } catch (err: any) {
      toast.error(err.message)
    }
  }

  const setF = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm(p => ({ ...p, [k]: e.target.value }))

  const setC = (k: keyof ClinicForm) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setClinicForm(p => ({ ...p, [k]: e.target.value }))

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 size={32} className="animate-spin text-blue-600" />
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/" className="flex items-center gap-2 text-blue-600 font-bold text-xl">
          <Stethoscope size={22} /> DoctorFinder
        </Link>
        <Link href="/doctor/dashboard" className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600">
          <ArrowLeft size={16} /> Dashboard
        </Link>
      </nav>

      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Edit Profile</h1>
          <p className="text-gray-500 text-sm mt-1">Update your professional information</p>
        </div>

        {/* Professional Info */}
        <div className="bg-white rounded-2xl shadow-sm border p-6 space-y-5">
          <h2 className="font-bold text-gray-900 text-lg border-b pb-3">Professional Information</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Specialization</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={form.specialization} onChange={setF('specialization')}>
                <option value="">Select</option>
                {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Qualification</label>
              <input className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="MBBS, MD..." value={form.qualification} onChange={setF('qualification')} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Experience (years)</label>
              <input type="number" min="0"
                className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={form.experienceYears} onChange={setF('experienceYears')} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Languages Spoken</label>
              <input className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="English, Hindi..." value={form.languagesSpoken} onChange={setF('languagesSpoken')} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Consultation Fee (₹)</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-gray-500 text-sm">₹</span>
                <input type="number" min="0"
                  className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.consultationFee} onChange={setF('consultationFee')} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Online Fee (₹)</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-gray-500 text-sm">₹</span>
                <input type="number" min="0"
                  className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.onlineFee} onChange={setF('onlineFee')} />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
            <textarea rows={4}
              className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              placeholder="Describe your expertise and approach to patient care..."
              value={form.bio} onChange={setF('bio')} />
          </div>

          <button onClick={handleSave} disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-60">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </div>

        {/* Clinics */}
        <div ref={clinicsRef} id="clinics" className="bg-white rounded-2xl shadow-sm border p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-gray-900 text-lg">Clinics</h2>
            <button onClick={() => setShowAddClinic(!showAddClinic)}
              className="flex items-center gap-1.5 text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
              <Plus size={16} /> Add Clinic
            </button>
          </div>

          {/* Add Clinic Form */}
          {showAddClinic && (
            <div className="border-2 border-blue-200 rounded-xl p-5 bg-blue-50 space-y-4">
              <h3 className="font-semibold text-blue-900">New Clinic</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: 'name' as const,    label: 'Clinic Name *',  placeholder: 'Apollo Clinic' },
                  { key: 'address' as const, label: 'Address *',      placeholder: '123 Main Street' },
                  { key: 'city' as const,    label: 'City *',         placeholder: 'Delhi' },
                  { key: 'state' as const,   label: 'State *',        placeholder: 'Delhi' },
                  { key: 'pincode' as const, label: 'Pincode',        placeholder: '110001' },
                ].map(({ key, label, placeholder }) => (
                  <div key={key} className={key === 'address' ? 'sm:col-span-2' : ''}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{label}</label>
                    <input className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      placeholder={placeholder} value={clinicForm[key]} onChange={setC(key)} />
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={addClinic} disabled={clinicLoading}
                  className="flex items-center gap-2 px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-60">
                  {clinicLoading ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                  {clinicLoading ? 'Adding…' : 'Add Clinic'}
                </button>
                <button onClick={() => { setShowAddClinic(false); setClinicForm(EMPTY_CLINIC) }}
                  className="px-5 py-2 border border-gray-300 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Clinic List */}
          {clinics.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <MapPin size={28} className="mx-auto mb-2 opacity-40" />
              <p className="text-sm">No clinics added yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {clinics.map((c: any) => (
                <div key={c.id} className="flex items-start gap-4 p-4 border rounded-xl hover:bg-gray-50 group">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin size={18} className="text-purple-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900">{c.name}</p>
                    <p className="text-sm text-gray-500 truncate">{c.address}, {c.city}, {c.state} {c.pincode}</p>
                  </div>
                  <button onClick={() => deleteClinic(c.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Schedule link */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-lg">Manage Your Schedule</h3>
            <p className="text-blue-100 text-sm mt-1">Set your availability and let patients book appointments</p>
          </div>
          <Link href="/doctor/schedule"
            className="bg-white text-blue-600 px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-blue-50 transition-colors whitespace-nowrap">
            Manage Schedule →
          </Link>
        </div>
      </div>
    </div>
  )
}
