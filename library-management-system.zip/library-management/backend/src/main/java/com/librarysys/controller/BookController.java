package com.librarysys.controller;

import com.librarysys.dto.BookDTO;
import com.librarysys.service.BookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    // ========== BROWSE / SEARCH ==========

    /**
     * GET /api/books?page=0&size=12
     * List all active books (paginated)
     */
    @GetMapping
    public ResponseEntity<BookDTO.PageResponse> getAllBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(bookService.getAllBooks(page, Math.min(size, 50)));
    }

    /**
     * GET /api/books/search?q=keyword&page=0&size=12
     */
    @GetMapping("/search")
    public ResponseEntity<BookDTO.PageResponse> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        if (q == null || q.isBlank()) {
            return ResponseEntity.ok(bookService.getAllBooks(page, size));
        }
        return ResponseEntity.ok(bookService.searchBooks(q, page, Math.min(size, 50)));
    }

    /**
     * GET /api/books/genre/{genre}?page=0&size=12
     */
    @GetMapping("/genre/{genre}")
    public ResponseEntity<BookDTO.PageResponse> getByGenre(
            @PathVariable String genre,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(bookService.getBooksByGenre(genre, page, size));
    }

    /**
     * GET /api/books/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<BookDTO.Response> getBook(@PathVariable Long id) {
        return ResponseEntity.ok(bookService.getBookById(id));
    }

    // ========== PDF STREAMING (read-only) ==========

    /**
     * GET /api/books/{id}/read
     *
     * Streams the PDF with:
     *   - Content-Disposition: inline (browser displays, not download)
     *   - X-Content-Type-Options: nosniff
     *   - Cache-Control: no-store (prevent saving via cache)
     *   - Content-Security-Policy: restricts further embedding
     *
     * This is the ONLY endpoint to serve PDFs — no download endpoint exists.
     */
    @GetMapping("/{id}/read")
    public ResponseEntity<Resource> readPdf(@PathVariable Long id) throws IOException {
        Path pdfPath = bookService.getPdfPathForReading(id);
        Resource resource = new FileSystemResource(pdfPath);

        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_PDF)
            .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"book.pdf\"")
            // Prevent download via browser controls
            .header("X-Content-Type-Options", "nosniff")
            // No caching — prevent saving via browser cache tricks
            .header(HttpHeaders.CACHE_CONTROL, "no-store, no-cache, must-revalidate, max-age=0")
            .header(HttpHeaders.PRAGMA, "no-cache")
            // Prevent embedding in other iframes (only our origin allowed)
            .header("X-Frame-Options", "SAMEORIGIN")
            // Content-Security-Policy for the PDF response itself
            .header("Content-Security-Policy", "default-src 'none'")
            .body(resource);
    }

    /**
     * GET /api/books/{id}/cover
     * Serves the cover image
     */
    @GetMapping("/{id}/cover")
    public ResponseEntity<byte[]> getCover(@PathVariable Long id) throws IOException {
        byte[] cover = bookService.getCoverImage(id);
        if (cover == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok()
            .contentType(MediaType.IMAGE_JPEG)
            .header(HttpHeaders.CACHE_CONTROL, "public, max-age=86400")
            .body(cover);
    }

    // ========== UPLOAD (Admin) ==========

    /**
     * POST /api/books/upload
     * Multipart: pdfFile (required), coverFile (optional), metadata fields
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<BookDTO.Response> uploadBook(
            @RequestPart("pdfFile") MultipartFile pdfFile,
            @RequestPart(value = "coverFile", required = false) MultipartFile coverFile,
            @RequestPart("metadata") BookDTO.CreateRequest metadata) throws IOException {

        BookDTO.Response response = bookService.uploadBook(metadata, pdfFile, coverFile);
        return ResponseEntity.status(201).body(response);
    }

    // ========== STATS & UTILITY ==========

    /**
     * GET /api/books/stats
     */
    @GetMapping("/stats")
    public ResponseEntity<BookDTO.StatsResponse> getStats() {
        return ResponseEntity.ok(bookService.getStats());
    }

    /**
     * GET /api/books/genres
     */
    @GetMapping("/genres")
    public ResponseEntity<List<String>> getGenres() {
        return ResponseEntity.ok(bookService.getAllGenres());
    }

    /**
     * GET /api/books/top-viewed?limit=6
     */
    @GetMapping("/top-viewed")
    public ResponseEntity<List<BookDTO.Response>> getTopViewed(
            @RequestParam(defaultValue = "6") int limit) {
        return ResponseEntity.ok(bookService.getTopViewed(Math.min(limit, 20)));
    }

    /**
     * GET /api/books/recent?limit=6
     */
    @GetMapping("/recent")
    public ResponseEntity<List<BookDTO.Response>> getRecent(
            @RequestParam(defaultValue = "6") int limit) {
        return ResponseEntity.ok(bookService.getRecentlyAdded(Math.min(limit, 20)));
    }

    /**
     * DELETE /api/books/{id}  (soft delete — archives the book)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.ok(Map.of("message", "Book archived successfully", "id", id.toString()));
    }

    // ========== GLOBAL EXCEPTION HANDLING ==========

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, String>> handleNotFound(RuntimeException e) {
        return ResponseEntity.status(404).body(Map.of("error", e.getMessage()));
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, String>> handleIO(IOException e) {
        log.error("IO error serving PDF", e);
        return ResponseEntity.status(500).body(Map.of("error", "File could not be read"));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(IllegalArgumentException e) {
        return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
    }
}
