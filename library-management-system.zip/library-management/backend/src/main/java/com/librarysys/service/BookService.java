package com.librarysys.service;

import com.librarysys.dto.BookDTO;
import com.librarysys.entity.Book;
import com.librarysys.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookService {

    private final BookRepository bookRepository;
    private final FileStorageService fileStorageService;

    private static final String BASE_URL = "http://localhost:8080";

    // ========== UPLOAD ==========

    @Transactional
    public BookDTO.Response uploadBook(
            BookDTO.CreateRequest request,
            MultipartFile pdfFile,
            MultipartFile coverFile) throws IOException {

        // Store PDF on disk
        String pdfPath = fileStorageService.storePdf(pdfFile);

        // Store cover if provided
        String coverPath = null;
        if (coverFile != null && !coverFile.isEmpty()) {
            coverPath = fileStorageService.storeCover(coverFile);
        }

        Book book = Book.builder()
            .title(request.getTitle().trim())
            .author(request.getAuthor().trim())
            .isbn(request.getIsbn())
            .genre(request.getGenre())
            .publisher(request.getPublisher())
            .publishedYear(request.getPublishedYear())
            .pageCount(request.getPageCount())
            .description(request.getDescription())
            .language(request.getLanguage() != null ? request.getLanguage() : "English")
            .pdfFilePath(pdfPath)
            .coverImagePath(coverPath)
            .fileSizeBytes(pdfFile.getSize())
            .uploadedBy(request.getUploadedBy() != null ? request.getUploadedBy() : "admin")
            .tags(request.getTags())
            .status(Book.BookStatus.ACTIVE)
            .build();

        book = bookRepository.save(book);
        log.info("Book uploaded: id={}, title={}", book.getId(), book.getTitle());
        return BookDTO.Response.from(book, BASE_URL);
    }

    // ========== READ ==========

    public BookDTO.PageResponse getAllBooks(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.findByStatusOrderByCreatedAtDesc(
            Book.BookStatus.ACTIVE, pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.PageResponse searchBooks(String query, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.searchBooks(query.trim(), pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.PageResponse getBooksByGenre(String genre, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.findByGenre(genre, pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.Response getBookById(Long id) {
        Book book = findActiveBook(id);
        return BookDTO.Response.from(book, BASE_URL);
    }

    // ========== PDF STREAMING (read-only — no download) ==========

    @Transactional
    public Path getPdfPathForReading(Long id) throws IOException {
        Book book = findActiveBook(id);
        // Increment view counter
        bookRepository.incrementViewCount(id);
        return fileStorageService.getPdfPath(book.getPdfFilePath());
    }

    public byte[] getCoverImage(Long id) throws IOException {
        Book book = findActiveBook(id);
        if (book.getCoverImagePath() == null) {
            return null;
        }
        return fileStorageService.loadCover(book.getCoverImagePath());
    }

    // ========== STATS ==========

    public BookDTO.StatsResponse getStats() {
        Long totalBooks = bookRepository.countActiveBooks();
        Long totalStorage = bookRepository.totalStorageUsed();
        List<String> genres = bookRepository.findDistinctGenres();

        return BookDTO.StatsResponse.builder()
            .totalBooks(totalBooks != null ? totalBooks : 0L)
            .totalStorageBytes(totalStorage != null ? totalStorage : 0L)
            .totalStorageFormatted(formatSize(totalStorage))
            .genres(genres)
            .build();
    }

    public List<BookDTO.Response> getTopViewed(int limit) {
        return bookRepository.findTopViewed(PageRequest.of(0, limit))
            .stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());
    }

    public List<BookDTO.Response> getRecentlyAdded(int limit) {
        return bookRepository.findRecentlyAdded(PageRequest.of(0, limit))
            .stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());
    }

    public List<String> getAllGenres() {
        return bookRepository.findDistinctGenres();
    }

    // ========== DELETE ==========

    @Transactional
    public void deleteBook(Long id) {
        Book book = findActiveBook(id);
        // Soft-delete: set to ARCHIVED
        book.setStatus(Book.BookStatus.ARCHIVED);
        bookRepository.save(book);
        log.info("Book archived: id={}", id);
    }

    // ========== HELPERS ==========

    private Book findActiveBook(Long id) {
        return bookRepository.findById(id)
            .filter(b -> b.getStatus() == Book.BookStatus.ACTIVE)
            .orElseThrow(() -> new RuntimeException("Book not found with id: " + id));
    }

    private BookDTO.PageResponse toPageResponse(Page<Book> page) {
        List<BookDTO.Response> books = page.getContent().stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());

        return BookDTO.PageResponse.builder()
            .books(books)
            .currentPage(page.getNumber())
            .totalPages(page.getTotalPages())
            .totalElements(page.getTotalElements())
            .pageSize(page.getSize())
            .hasNext(page.hasNext())
            .hasPrevious(page.hasPrevious())
            .build();
    }

    private String formatSize(Long bytes) {
        if (bytes == null || bytes == 0) return "0 B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
