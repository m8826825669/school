import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, ShieldCheck, BookOpen, Layers, Globe } from 'lucide-react';
import UploadModal from '../components/UploadModal.jsx';

export default function UploadPage() {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);

  const handleSuccess = (book) => {
    setTimeout(() => navigate(`/book/${book.id}`), 300);
  };

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh', animation: 'fadeIn 0.35s var(--ease)' }}>

      {/* Header */}
      <div style={{
        background: 'var(--ink-soft)',
        borderBottom: '1px solid var(--ink-border)',
        padding: '0.75rem 2rem',
      }}>
        <div className="container" style={{ maxWidth: 900 }}>
          <Link to="/" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            color: 'var(--text-muted)', fontSize: '0.82rem',
          }}>
            <ArrowLeft size={13} />
            Back to Library
          </Link>
        </div>
      </div>

      <div className="container" style={{ maxWidth: 900, padding: '3rem 2rem' }}>

        {/* Hero area */}
        <div style={{
          textAlign: 'center',
          padding: '3rem 2rem 2.5rem',
          background: 'linear-gradient(135deg, var(--ink-soft), var(--ink-mid))',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-xl)',
          marginBottom: '2.5rem',
          position: 'relative',
          overflow: 'hidden',
        }}>
          {/* Decoration */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'radial-gradient(ellipse at 50% 0%, var(--gold-glow), transparent 60%)',
            pointerEvents: 'none',
          }} />
          <div style={{
            width: 64, height: 64,
            background: 'var(--gold-glow)',
            border: '1px solid var(--gold-dim)',
            borderRadius: 16,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 1.25rem',
            position: 'relative',
          }}>
            <Upload size={26} color="var(--gold)" />
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(1.8rem, 3vw, 2.4rem)',
            fontWeight: 600,
            marginBottom: '0.75rem',
            position: 'relative',
          }}>
            Add a Book to the Library
          </h1>
          <p style={{
            color: 'var(--text-secondary)',
            maxWidth: 480, margin: '0 auto 2rem',
            lineHeight: 1.7,
            position: 'relative',
          }}>
            Upload a PDF file along with the book's metadata. The book will be immediately available for readers — in secure, read-only mode.
          </p>
          <button
            className="btn btn-primary"
            onClick={() => setShowModal(true)}
            style={{ padding: '0.75rem 2rem', fontSize: '0.95rem', position: 'relative' }}
          >
            <Upload size={16} />
            Upload New Book
          </button>
        </div>

        {/* Feature grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
          gap: '1rem',
        }}>
          <FeatureCard
            icon={<ShieldCheck size={20} color="var(--gold)" />}
            title="Read-Only Protection"
            desc="PDFs are served inline with no download option. Right-click and browser save are disabled."
          />
          <FeatureCard
            icon={<BookOpen size={20} color="var(--gold)" />}
            title="Browser PDF Viewer"
            desc="Rendered via PDF.js with custom controls — page navigation, zoom, rotation, and fullscreen."
          />
          <FeatureCard
            icon={<Layers size={20} color="var(--gold)" />}
            title="Up to 100 MB"
            desc="Large PDF files supported. Files are stored securely on the server filesystem."
          />
          <FeatureCard
            icon={<Globe size={20} color="var(--gold)" />}
            title="Multilingual Support"
            desc="Books in any language supported — including Hindi, Tamil, Bengali, and other Indian scripts."
          />
        </div>

        {/* Instructions */}
        <div style={{
          marginTop: '2.5rem',
          padding: '1.5rem',
          background: 'var(--surface-2)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-lg)',
        }}>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontSize: '1.1rem',
            marginBottom: '1rem', color: 'var(--text-secondary)',
          }}>
            Upload Guidelines
          </h3>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {[
              'Only PDF files are accepted (max 100 MB per file)',
              'Cover images are optional — a placeholder is shown if not provided',
              'Title and Author are required fields',
              'ISBN must be unique if provided',
              'Tags help readers discover books through search',
              'Books can be archived (soft-deleted) from the book detail page',
            ].map((item, i) => (
              <li key={i} style={{
                display: 'flex', alignItems: 'flex-start', gap: '0.6rem',
                color: 'var(--text-secondary)', fontSize: '0.875rem', lineHeight: 1.6,
              }}>
                <span style={{
                  width: 18, height: 18,
                  background: 'var(--gold-glow)',
                  border: '1px solid var(--gold-dim)',
                  borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '0.65rem',
                  color: 'var(--gold)',
                  flexShrink: 0,
                  fontWeight: 700,
                  marginTop: 2,
                }}>
                  {i + 1}
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {showModal && (
        <UploadModal
          onClose={() => setShowModal(false)}
          onSuccess={handleSuccess}
        />
      )}
    </div>
  );
}

function FeatureCard({ icon, title, desc }) {
  return (
    <div style={{
      padding: '1.25rem',
      background: 'var(--card-bg)',
      border: '1px solid var(--ink-border)',
      borderRadius: 'var(--radius-lg)',
    }}>
      <div style={{ marginBottom: '0.75rem' }}>{icon}</div>
      <h4 style={{
        fontFamily: 'var(--font-display)', fontSize: '1rem',
        fontWeight: 600, marginBottom: '0.4rem',
      }}>
        {title}
      </h4>
      <p style={{ color: 'var(--text-muted)', fontSize: '0.82rem', lineHeight: 1.6 }}>{desc}</p>
    </div>
  );
}
