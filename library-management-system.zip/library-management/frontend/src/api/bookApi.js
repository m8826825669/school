import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
});

// Books API
export const bookApi = {
  // Get all books (paginated)
  getAll: (page = 0, size = 12) =>
    api.get(`/books?page=${page}&size=${size}`).then(r => r.data),

  // Search
  search: (q, page = 0, size = 12) =>
    api.get(`/books/search?q=${encodeURIComponent(q)}&page=${page}&size=${size}`).then(r => r.data),

  // Get by genre
  getByGenre: (genre, page = 0, size = 12) =>
    api.get(`/books/genre/${encodeURIComponent(genre)}?page=${page}&size=${size}`).then(r => r.data),

  // Get single book
  getById: (id) =>
    api.get(`/books/${id}`).then(r => r.data),

  // Stats
  getStats: () =>
    api.get('/books/stats').then(r => r.data),

  // Genres list
  getGenres: () =>
    api.get('/books/genres').then(r => r.data),

  // Top viewed
  getTopViewed: (limit = 6) =>
    api.get(`/books/top-viewed?limit=${limit}`).then(r => r.data),

  // Recently added
  getRecent: (limit = 6) =>
    api.get(`/books/recent?limit=${limit}`).then(r => r.data),

  // Upload book (admin)
  upload: (metadata, pdfFile, coverFile) => {
    const formData = new FormData();
    formData.append('pdfFile', pdfFile);
    if (coverFile) formData.append('coverFile', coverFile);
    formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    return api.post('/books/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (e.onUploadProgress) e.onUploadProgress(e);
      }
    }).then(r => r.data);
  },

  // PDF URL (for inline iframe viewing)
  getPdfUrl: (id) => `/api/books/${id}/read`,

  // Cover image URL
  getCoverUrl: (id) => `/api/books/${id}/cover`,

  // Delete (archive)
  delete: (id) => api.delete(`/books/${id}`).then(r => r.data),
};

export default api;
