import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar.jsx';
import HomePage from './pages/HomePage.jsx';
import BookDetailPage from './pages/BookDetailPage.jsx';
import SearchPage from './pages/SearchPage.jsx';
import TrendingPage from './pages/TrendingPage.jsx';
import UploadPage from './pages/UploadPage.jsx';

export default function App() {
  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/"           element={<HomePage />} />
        <Route path="/book/:id"   element={<BookDetailPage />} />
        <Route path="/search"     element={<SearchPage />} />
        <Route path="/trending"   element={<TrendingPage />} />
        <Route path="/upload"     element={<UploadPage />} />
        <Route path="*"           element={<NotFound />} />
      </Routes>

      <Footer />

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'var(--surface-2)',
            color: 'var(--text-primary)',
            border: '1px solid var(--ink-border)',
            fontFamily: 'var(--font-body)',
            fontSize: '0.875rem',
          },
          success: {
            iconTheme: { primary: 'var(--gold)', secondary: 'var(--ink)' },
          },
          error: {
            iconTheme: { primary: 'var(--error)', secondary: 'var(--ink)' },
          },
        }}
      />
    </>
  );
}

function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid var(--ink-border)',
      background: 'var(--ink-soft)',
      padding: '2rem',
      marginTop: '4rem',
    }}>
      <div className="container" style={{
        maxWidth: 1200,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: '1rem',
      }}>
        <div>
          <p style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.1rem',
            color: 'var(--gold)',
            marginBottom: '0.25rem',
          }}>
            Bibliothèque
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
            Digital library — read-only, secure, open to all.
          </p>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>
          Built with Spring Boot · PostgreSQL · React · PDF.js
        </p>
      </div>
    </footer>
  );
}

function NotFound() {
  return (
    <div style={{
      paddingTop: 'var(--navbar-h)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      minHeight: '80vh', gap: '1rem', textAlign: 'center',
    }}>
      <p style={{ fontFamily: 'var(--font-display)', fontSize: '5rem', color: 'var(--gold)', lineHeight: 1 }}>404</p>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Page Not Found</h2>
      <p style={{ color: 'var(--text-muted)' }}>The page you're looking for doesn't exist.</p>
      <a href="/" className="btn btn-outline" style={{ marginTop: '0.5rem' }}>Go to Library</a>
    </div>
  );
}
