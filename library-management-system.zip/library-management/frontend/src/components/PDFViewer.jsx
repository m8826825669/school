import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import {
  ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize2,
  Minimize2, RotateCw, Loader2, AlertCircle, Book
} from 'lucide-react';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.3.136/pdf.worker.min.mjs`;

export default function PDFViewer({ bookId, title }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  const [pdfDoc, setPdfDoc] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.2);
  const [rotation, setRotation] = useState(0);
  const [loading, setLoading] = useState(true);
  const [pageLoading, setPageLoading] = useState(false);
  const [error, setError] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [inputPage, setInputPage] = useState('1');

  // Prevent right-click on the viewer
  useEffect(() => {
    const prevent = (e) => e.preventDefault();
    const el = containerRef.current;
    if (el) {
      el.addEventListener('contextmenu', prevent);
      return () => el.removeEventListener('contextmenu', prevent);
    }
  }, []);

  // Load PDF
  useEffect(() => {
    if (!bookId) return;
    setLoading(true);
    setError(null);

    const pdfUrl = `/api/books/${bookId}/read`;

    pdfjsLib.getDocument({
      url: pdfUrl,
      // Prevent PDF.js from exposing download options
      disableCreateObjectURL: false,
      withCredentials: false,
    }).promise
      .then(doc => {
        setPdfDoc(doc);
        setTotalPages(doc.numPages);
        setCurrentPage(1);
        setLoading(false);
      })
      .catch(err => {
        console.error('PDF load error:', err);
        setError('Failed to load PDF. Please try again.');
        setLoading(false);
      });
  }, [bookId]);

  // Render page
  const renderPage = useCallback(async (pageNum, doc, currentScale, currentRotation) => {
    if (!doc || !canvasRef.current) return;

    setPageLoading(true);
    try {
      const page = await doc.getPage(pageNum);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      const viewport = page.getViewport({ scale: currentScale, rotation: currentRotation });
      canvas.width = viewport.width;
      canvas.height = viewport.height;

      await page.render({ canvasContext: ctx, viewport }).promise;
    } catch (err) {
      console.error('Page render error:', err);
    } finally {
      setPageLoading(false);
    }
  }, []);

  useEffect(() => {
    if (pdfDoc) {
      renderPage(currentPage, pdfDoc, scale, rotation);
    }
  }, [currentPage, pdfDoc, scale, rotation, renderPage]);

  const goToPage = (page) => {
    const p = Math.max(1, Math.min(page, totalPages));
    setCurrentPage(p);
    setInputPage(String(p));
  };

  const zoomIn = () => setScale(s => Math.min(s + 0.2, 3.0));
  const zoomOut = () => setScale(s => Math.max(s - 0.2, 0.5));
  const rotate = () => setRotation(r => (r + 90) % 360);

  // Keyboard navigation
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') goToPage(currentPage + 1);
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') goToPage(currentPage - 1);
      if (e.key === '+' || e.key === '=') zoomIn();
      if (e.key === '-') zoomOut();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [currentPage, totalPages]);

  const toolbarStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 10,
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    padding: '0.6rem 1rem',
    background: 'rgba(13,13,14,0.95)',
    backdropFilter: 'blur(20px)',
    borderBottom: '1px solid var(--ink-border)',
    flexWrap: 'wrap',
  };

  if (loading) {
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', height: 480, gap: '1rem',
        background: 'var(--surface)',
        borderRadius: 'var(--radius-lg)',
      }}>
        <Loader2 size={36} style={{ color: 'var(--gold)', animation: 'spin 1s linear infinite' }} />
        <p style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-display)', fontSize: '1.1rem' }}>
          Loading {title}...
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', height: 400, gap: '1rem',
        background: 'var(--surface)',
        borderRadius: 'var(--radius-lg)',
      }}>
        <AlertCircle size={36} style={{ color: 'var(--error)' }} />
        <p style={{ color: 'var(--error)', fontSize: '0.95rem' }}>{error}</p>
        <button className="btn btn-outline" onClick={() => window.location.reload()}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      style={{
        background: 'var(--surface)',
        borderRadius: fullscreen ? 0 : 'var(--radius-lg)',
        border: '1px solid var(--ink-border)',
        overflow: 'hidden',
        position: fullscreen ? 'fixed' : 'relative',
        inset: fullscreen ? 0 : 'auto',
        zIndex: fullscreen ? 9999 : 'auto',
        display: 'flex',
        flexDirection: 'column',
        userSelect: 'none', // Prevent text selection as anti-copy measure
      }}
    >
      {/* Toolbar */}
      <div style={toolbarStyle}>
        {/* Book title */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          flex: 1, minWidth: 0,
        }}>
          <Book size={14} style={{ color: 'var(--gold)', flexShrink: 0 }} />
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: '0.95rem',
            color: 'var(--text-secondary)',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {title}
          </span>
        </div>

        {/* Divider */}
        <div style={{ width: 1, height: 24, background: 'var(--ink-border)' }} />

        {/* Page navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage <= 1}
            className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: currentPage <= 1 ? 0.3 : 1 }}
          >
            <ChevronLeft size={16} />
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <input
              type="number"
              value={inputPage}
              onChange={e => setInputPage(e.target.value)}
              onBlur={() => {
                const n = parseInt(inputPage);
                if (!isNaN(n)) goToPage(n);
                else setInputPage(String(currentPage));
              }}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  const n = parseInt(inputPage);
                  if (!isNaN(n)) goToPage(n);
                }
              }}
              style={{
                width: 52, padding: '0.3rem 0.4rem',
                background: 'var(--ink-soft)',
                border: '1px solid var(--ink-border)',
                borderRadius: 'var(--radius)',
                color: 'var(--text-primary)',
                fontSize: '0.8rem',
                textAlign: 'center',
                outline: 'none',
              }}
            />
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
              / {totalPages}
            </span>
          </div>

          <button
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage >= totalPages}
            className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: currentPage >= totalPages ? 0.3 : 1 }}
          >
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Divider */}
        <div style={{ width: 1, height: 24, background: 'var(--ink-border)' }} />

        {/* Zoom controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button onClick={zoomOut} disabled={scale <= 0.5} className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: scale <= 0.5 ? 0.3 : 1 }}>
            <ZoomOut size={15} />
          </button>
          <span style={{
            minWidth: 44, textAlign: 'center',
            fontSize: '0.78rem', color: 'var(--text-secondary)',
          }}>
            {Math.round(scale * 100)}%
          </span>
          <button onClick={zoomIn} disabled={scale >= 3.0} className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: scale >= 3.0 ? 0.3 : 1 }}>
            <ZoomIn size={15} />
          </button>
        </div>

        {/* Rotate */}
        <button onClick={rotate} className="btn btn-ghost" style={{ padding: '0.4rem' }}
          title="Rotate 90°">
          <RotateCw size={15} />
        </button>

        {/* Fullscreen */}
        <button
          onClick={() => setFullscreen(f => !f)}
          className="btn btn-ghost"
          style={{ padding: '0.4rem' }}
          title={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
        >
          {fullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </button>
      </div>

      {/* Canvas area */}
      <div style={{
        flex: 1,
        overflow: 'auto',
        background: 'var(--ink)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        padding: '1.5rem',
        minHeight: fullscreen ? 'calc(100vh - 56px)' : 500,
        position: 'relative',
      }}>
        {pageLoading && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'rgba(13,13,14,0.5)',
            zIndex: 5,
          }}>
            <Loader2 size={28} style={{ color: 'var(--gold)', animation: 'spin 0.8s linear infinite' }} />
          </div>
        )}

        <canvas
          ref={canvasRef}
          style={{
            maxWidth: '100%',
            boxShadow: '0 8px 48px rgba(0,0,0,0.6)',
            borderRadius: 2,
            // Disable all browser default behaviors for copy/download
            WebkitUserSelect: 'none',
            MozUserSelect: 'none',
            userSelect: 'none',
            pointerEvents: 'none', // Prevents drag-to-select
          }}
        />
      </div>

      {/* Page progress bar */}
      <div style={{
        height: 3,
        background: 'var(--ink-border)',
        flexShrink: 0,
      }}>
        <div style={{
          height: '100%',
          background: 'linear-gradient(90deg, var(--gold-dim), var(--gold))',
          width: `${(currentPage / totalPages) * 100}%`,
          transition: 'width 0.3s var(--ease)',
        }} />
      </div>
    </div>
  );
}
