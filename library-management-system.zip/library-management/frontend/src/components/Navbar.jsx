import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { BookOpen, Search, Upload, Library, TrendingUp, X } from 'lucide-react';

export default function Navbar() {
  const [query, setQuery] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  const clearSearch = () => {
    setQuery('');
    navigate('/');
  };

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      height: 'var(--navbar-h)',
      display: 'flex', alignItems: 'center',
      padding: '0 2rem',
      background: scrolled
        ? 'rgba(13,13,14,0.92)'
        : 'linear-gradient(180deg, rgba(13,13,14,0.98) 0%, rgba(13,13,14,0.0) 100%)',
      backdropFilter: scrolled ? 'blur(20px) saturate(180%)' : 'none',
      borderBottom: scrolled ? '1px solid var(--ink-border)' : '1px solid transparent',
      transition: 'all 0.35s var(--ease)',
    }}>
      {/* Logo */}
      <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexShrink: 0 }}>
        <div style={{
          width: 36, height: 36,
          background: 'linear-gradient(135deg, var(--gold), var(--gold-dim))',
          borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <BookOpen size={18} color="#0d0d0e" strokeWidth={2.5} />
        </div>
        <span style={{
          fontFamily: 'var(--font-display)',
          fontSize: '1.4rem',
          fontWeight: 600,
          letterSpacing: '0.02em',
          color: 'var(--text-primary)',
        }}>
          Bibliothèque
        </span>
      </Link>

      {/* Search bar */}
      <form onSubmit={handleSearch} style={{
        flex: 1, maxWidth: 520,
        margin: '0 2rem',
        position: 'relative',
      }}>
        <Search size={15} style={{
          position: 'absolute', left: '0.9rem', top: '50%',
          transform: 'translateY(-50%)',
          color: 'var(--text-muted)',
          pointerEvents: 'none',
        }} />
        <input
          className="input"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search by title, author, genre, ISBN..."
          style={{
            paddingLeft: '2.4rem',
            paddingRight: query ? '2.4rem' : '1rem',
            borderRadius: 100,
            background: 'var(--ink-soft)',
          }}
        />
        {query && (
          <button type="button" onClick={clearSearch} style={{
            position: 'absolute', right: '0.9rem', top: '50%',
            transform: 'translateY(-50%)',
            background: 'none', border: 'none', cursor: 'pointer',
            color: 'var(--text-muted)', display: 'flex',
          }}>
            <X size={14} />
          </button>
        )}
      </form>

      {/* Nav links */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginLeft: 'auto' }}>
        <NavLink to="/" icon={<Library size={15} />} label="Catalog" active={location.pathname === '/'} />
        <NavLink to="/trending" icon={<TrendingUp size={15} />} label="Trending" active={location.pathname === '/trending'} />
        <Link to="/upload">
          <button className="btn btn-primary" style={{ marginLeft: '0.5rem', fontSize: '0.8125rem' }}>
            <Upload size={14} />
            Add Book
          </button>
        </Link>
      </div>
    </nav>
  );
}

function NavLink({ to, icon, label, active }) {
  return (
    <Link to={to} style={{
      display: 'flex', alignItems: 'center', gap: '0.4rem',
      padding: '0.5rem 0.875rem',
      borderRadius: 'var(--radius)',
      color: active ? 'var(--gold)' : 'var(--text-secondary)',
      background: active ? 'var(--gold-glow)' : 'transparent',
      fontSize: '0.875rem',
      fontWeight: 500,
      transition: 'all 0.2s',
    }}
    onMouseEnter={e => {
      if (!active) {
        e.currentTarget.style.color = 'var(--text-primary)';
        e.currentTarget.style.background = 'var(--ink-soft)';
      }
    }}
    onMouseLeave={e => {
      if (!active) {
        e.currentTarget.style.color = 'var(--text-secondary)';
        e.currentTarget.style.background = 'transparent';
      }
    }}>
      {icon}
      {label}
    </Link>
  );
}
