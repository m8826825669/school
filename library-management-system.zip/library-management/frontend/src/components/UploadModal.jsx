import React, { useState, useRef } from 'react';
import {
  X, Upload, FileText, Image, Plus, Loader2,
  AlertCircle, CheckCircle2, BookOpen
} from 'lucide-react';
import { bookApi } from '../api/bookApi.js';
import toast from 'react-hot-toast';

const GENRES = [
  'Fiction', 'Non-Fiction', 'Science', 'Technology', 'History',
  'Philosophy', 'Biography', 'Literature', 'Mathematics', 'Medicine',
  'Law', 'Economics', 'Psychology', 'Engineering', 'Arts', 'Religion',
  'Politics', 'Travel', 'Self-Help', 'Children', 'Comics', 'Poetry'
];

const LANGUAGES = [
  'English', 'Hindi', 'Bengali', 'Telugu', 'Tamil',
  'Marathi', 'Gujarati', 'Kannada', 'Malayalam', 'Punjabi',
  'French', 'German', 'Spanish', 'Arabic', 'Chinese', 'Japanese'
];

export default function UploadModal({ onClose, onSuccess }) {
  const pdfInputRef = useRef(null);
  const coverInputRef = useRef(null);

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [pdfFile, setPdfFile] = useState(null);
  const [coverFile, setCoverFile] = useState(null);
  const [coverPreview, setCoverPreview] = useState(null);
  const [tagInput, setTagInput] = useState('');

  const [form, setForm] = useState({
    title: '', author: '', isbn: '', genre: '',
    publisher: '', publishedYear: '', pageCount: '',
    description: '', language: 'English',
    uploadedBy: 'admin', tags: [],
  });

  const [errors, setErrors] = useState({});

  const set = (field, value) => {
    setForm(f => ({ ...f, [field]: value }));
    if (errors[field]) setErrors(e => ({ ...e, [field]: null }));
  };

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = 'Title is required';
    if (!form.author.trim()) e.author = 'Author is required';
    if (!pdfFile) e.pdf = 'PDF file is required';
    if (form.publishedYear && (isNaN(form.publishedYear) || form.publishedYear < 1000 || form.publishedYear > new Date().getFullYear() + 1)) {
      e.publishedYear = 'Enter a valid year';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handlePdfDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files[0] || e.target.files[0];
    if (!file) return;
    if (file.type !== 'application/pdf') {
      toast.error('Only PDF files are allowed');
      return;
    }
    setPdfFile(file);
    if (errors.pdf) setErrors(e => ({ ...e, pdf: null }));
  };

  const handleCoverChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setCoverFile(file);
    const url = URL.createObjectURL(file);
    setCoverPreview(url);
  };

  const addTag = () => {
    const tag = tagInput.trim().toLowerCase();
    if (tag && !form.tags.includes(tag) && form.tags.length < 8) {
      set('tags', [...form.tags, tag]);
      setTagInput('');
    }
  };

  const removeTag = (tag) => set('tags', form.tags.filter(t => t !== tag));

  const handleSubmit = async () => {
    if (!validate()) return;
    setUploading(true);
    setUploadProgress(0);

    const metadata = {
      ...form,
      publishedYear: form.publishedYear ? parseInt(form.publishedYear) : null,
      pageCount: form.pageCount ? parseInt(form.pageCount) : null,
    };

    try {
      // Simulate progress
      const timer = setInterval(() => {
        setUploadProgress(p => Math.min(p + 8, 85));
      }, 200);

      const book = await bookApi.upload(metadata, pdfFile, coverFile);
      clearInterval(timer);
      setUploadProgress(100);

      toast.success(`"${book.title}" uploaded successfully!`);
      setTimeout(() => {
        onSuccess?.(book);
        onClose();
      }, 600);
    } catch (err) {
      setUploading(false);
      setUploadProgress(0);
      const msg = err.response?.data?.error || 'Upload failed. Please try again.';
      toast.error(msg);
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.75)',
      backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '1rem',
      animation: 'fadeIn 0.2s var(--ease)',
    }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{
        background: 'var(--surface-2)',
        border: '1px solid var(--ink-border)',
        borderRadius: 'var(--radius-xl)',
        width: '100%',
        maxWidth: 720,
        maxHeight: '92vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 32px 80px rgba(0,0,0,0.7)',
      }}>
        {/* Header */}
        <div style={{
          padding: '1.25rem 1.5rem',
          borderBottom: '1px solid var(--ink-border)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div style={{
              width: 32, height: 32,
              background: 'var(--gold-glow)',
              border: '1px solid var(--gold-dim)',
              borderRadius: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <BookOpen size={15} color="var(--gold)" />
            </div>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 600 }}>
                Add New Book
              </h2>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 1 }}>
                Upload a PDF to the library
              </p>
            </div>
          </div>
          <button onClick={onClose} className="btn btn-ghost" style={{ padding: '0.4rem' }}>
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: 'auto', padding: '1.5rem', flex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>

            {/* Left column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

              {/* PDF Upload Drop Zone */}
              <div>
                <label>PDF File *</label>
                <div
                  onClick={() => pdfInputRef.current?.click()}
                  onDragOver={e => e.preventDefault()}
                  onDrop={handlePdfDrop}
                  style={{
                    border: `2px dashed ${errors.pdf ? 'var(--error)' : pdfFile ? 'var(--gold-dim)' : 'var(--ink-border)'}`,
                    borderRadius: 'var(--radius-lg)',
                    padding: '1.5rem 1rem',
                    textAlign: 'center',
                    cursor: 'pointer',
                    background: pdfFile ? 'var(--gold-glow)' : 'var(--surface)',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => {
                    if (!pdfFile) e.currentTarget.style.borderColor = 'var(--gold-dim)';
                  }}
                  onMouseLeave={e => {
                    if (!pdfFile) e.currentTarget.style.borderColor = errors.pdf ? 'var(--error)' : 'var(--ink-border)';
                  }}
                >
                  <input
                    ref={pdfInputRef}
                    type="file"
                    accept="application/pdf"
                    style={{ display: 'none' }}
                    onChange={handlePdfDrop}
                  />
                  {pdfFile ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.4rem' }}>
                      <CheckCircle2 size={24} color="var(--gold)" />
                      <p style={{ color: 'var(--gold)', fontSize: '0.85rem', fontWeight: 500 }}>
                        {pdfFile.name}
                      </p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                        {(pdfFile.size / (1024 * 1024)).toFixed(1)} MB
                      </p>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.4rem' }}>
                      <FileText size={28} style={{ color: errors.pdf ? 'var(--error)' : 'var(--text-muted)' }} />
                      <p style={{ color: errors.pdf ? 'var(--error)' : 'var(--text-secondary)', fontSize: '0.85rem' }}>
                        Drop PDF here or click to browse
                      </p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>Max 100 MB</p>
                    </div>
                  )}
                </div>
                {errors.pdf && <p style={{ color: 'var(--error)', fontSize: '0.75rem', marginTop: '0.3rem' }}>{errors.pdf}</p>}
              </div>

              {/* Cover Image */}
              <div>
                <label>Cover Image (optional)</label>
                <div
                  onClick={() => coverInputRef.current?.click()}
                  style={{
                    border: '1px dashed var(--ink-border)',
                    borderRadius: 'var(--radius-lg)',
                    cursor: 'pointer',
                    overflow: 'hidden',
                    background: 'var(--surface)',
                    aspectRatio: '3/4',
                    maxHeight: 160,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    transition: 'border-color 0.2s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--gold-dim)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--ink-border)'}
                >
                  <input
                    ref={coverInputRef}
                    type="file"
                    accept="image/*"
                    style={{ display: 'none' }}
                    onChange={handleCoverChange}
                  />
                  {coverPreview ? (
                    <img src={coverPreview} alt="Cover preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      <Image size={22} style={{ margin: '0 auto 0.3rem' }} />
                      <p style={{ fontSize: '0.75rem' }}>Upload cover</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right column — metadata */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label>Title *</label>
                <input
                  className="input"
                  value={form.title}
                  onChange={e => set('title', e.target.value)}
                  placeholder="Book title"
                  style={{ borderColor: errors.title ? 'var(--error)' : undefined }}
                />
                {errors.title && <p style={{ color: 'var(--error)', fontSize: '0.75rem', marginTop: '0.3rem' }}>{errors.title}</p>}
              </div>

              <div>
                <label>Author *</label>
                <input
                  className="input"
                  value={form.author}
                  onChange={e => set('author', e.target.value)}
                  placeholder="Author name"
                  style={{ borderColor: errors.author ? 'var(--error)' : undefined }}
                />
                {errors.author && <p style={{ color: 'var(--error)', fontSize: '0.75rem', marginTop: '0.3rem' }}>{errors.author}</p>}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label>ISBN</label>
                  <input className="input" value={form.isbn} onChange={e => set('isbn', e.target.value)} placeholder="978-..." />
                </div>
                <div>
                  <label>Year</label>
                  <input
                    className="input"
                    type="number"
                    value={form.publishedYear}
                    onChange={e => set('publishedYear', e.target.value)}
                    placeholder="2024"
                    style={{ borderColor: errors.publishedYear ? 'var(--error)' : undefined }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label>Genre</label>
                  <select
                    className="input"
                    value={form.genre}
                    onChange={e => set('genre', e.target.value)}
                    style={{ appearance: 'none' }}
                  >
                    <option value="">Select genre</option>
                    {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div>
                  <label>Language</label>
                  <select
                    className="input"
                    value={form.language}
                    onChange={e => set('language', e.target.value)}
                    style={{ appearance: 'none' }}
                  >
                    {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label>Publisher</label>
                <input className="input" value={form.publisher} onChange={e => set('publisher', e.target.value)} placeholder="Publisher name" />
              </div>

              <div>
                <label>Pages</label>
                <input className="input" type="number" value={form.pageCount} onChange={e => set('pageCount', e.target.value)} placeholder="e.g. 352" />
              </div>
            </div>
          </div>

          {/* Description - full width */}
          <div style={{ marginTop: '1rem' }}>
            <label>Description</label>
            <textarea
              className="input"
              value={form.description}
              onChange={e => set('description', e.target.value)}
              placeholder="Brief description or synopsis..."
              rows={3}
              style={{ resize: 'vertical' }}
            />
          </div>

          {/* Tags */}
          <div style={{ marginTop: '1rem' }}>
            <label>Tags</label>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '0.5rem' }}>
              {form.tags.map(tag => (
                <span key={tag} className="badge" style={{ cursor: 'pointer' }} onClick={() => removeTag(tag)}>
                  {tag} <X size={10} />
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <input
                className="input"
                value={tagInput}
                onChange={e => setTagInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                placeholder="Add tag, press Enter"
                style={{ flex: 1 }}
                disabled={form.tags.length >= 8}
              />
              <button type="button" className="btn btn-outline" onClick={addTag} disabled={!tagInput.trim() || form.tags.length >= 8}>
                <Plus size={14} />
              </button>
            </div>
          </div>

          {/* Upload progress */}
          {uploading && (
            <div style={{ marginTop: '1rem' }}>
              <div style={{
                height: 4,
                background: 'var(--ink-border)',
                borderRadius: 100,
                overflow: 'hidden',
              }}>
                <div style={{
                  height: '100%',
                  background: 'linear-gradient(90deg, var(--gold-dim), var(--gold))',
                  width: `${uploadProgress}%`,
                  transition: 'width 0.2s',
                  borderRadius: 100,
                }} />
              </div>
              <p style={{ textAlign: 'center', fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.4rem' }}>
                Uploading... {uploadProgress}%
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          padding: '1rem 1.5rem',
          borderTop: '1px solid var(--ink-border)',
          display: 'flex', gap: '0.75rem', justifyContent: 'flex-end',
          flexShrink: 0,
          background: 'var(--surface)',
        }}>
          <button className="btn btn-ghost" onClick={onClose} disabled={uploading}>
            Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={handleSubmit}
            disabled={uploading}
            style={{ minWidth: 120 }}
          >
            {uploading ? (
              <><Loader2 size={14} style={{ animation: 'spin 0.8s linear infinite' }} /> Uploading...</>
            ) : (
              <><Upload size={14} /> Upload Book</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
