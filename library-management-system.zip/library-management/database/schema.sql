-- ============================================================
-- Bibliothèque — Library Management System
-- PostgreSQL Schema
-- ============================================================

-- Create database (run as superuser)
CREATE DATABASE library_db
  ENCODING = 'UTF8'
  LC_COLLATE = 'en_US.UTF-8'
  LC_CTYPE = 'en_US.UTF-8'
  TEMPLATE = template0;

\c library_db;

-- ============================================================
-- Core tables (Hibernate auto-creates these, but here for ref)
-- ============================================================

CREATE TABLE IF NOT EXISTS books (
    id                BIGSERIAL PRIMARY KEY,
    title             VARCHAR(500)  NOT NULL,
    author            VARCHAR(300)  NOT NULL,
    isbn              VARCHAR(20)   UNIQUE,
    genre             VARCHAR(100),
    publisher         VARCHAR(100),
    published_year    INTEGER,
    page_count        INTEGER,
    description       TEXT,
    language          VARCHAR(50)   DEFAULT 'English',
    pdf_file_path     VARCHAR(500)  NOT NULL,
    cover_image_path  VARCHAR(500),
    file_size_bytes   BIGINT,
    status            VARCHAR(20)   NOT NULL DEFAULT 'ACTIVE',
    view_count        BIGINT        DEFAULT 0,
    uploaded_by       VARCHAR(100)  DEFAULT 'admin',
    created_at        TIMESTAMP     NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP     NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS book_tags (
    book_id  BIGINT REFERENCES books(id) ON DELETE CASCADE,
    tag      VARCHAR(50),
    PRIMARY KEY (book_id, tag)
);

-- Indexes for fast search
CREATE INDEX IF NOT EXISTS idx_books_title       ON books USING gin(to_tsvector('english', title));
CREATE INDEX IF NOT EXISTS idx_books_author      ON books(author);
CREATE INDEX IF NOT EXISTS idx_books_genre       ON books(genre);
CREATE INDEX IF NOT EXISTS idx_books_status      ON books(status);
CREATE INDEX IF NOT EXISTS idx_books_view_count  ON books(view_count DESC);
CREATE INDEX IF NOT EXISTS idx_books_created_at  ON books(created_at DESC);

-- ============================================================
-- Trigger to auto-update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_books_updated_at ON books;
CREATE TRIGGER trg_books_updated_at
  BEFORE UPDATE ON books
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- Sample seed data (for testing without real PDFs)
-- Replace pdf_file_path with actual stored filenames after upload
-- ============================================================
INSERT INTO books (title, author, isbn, genre, publisher, published_year, page_count, description, language, pdf_file_path, file_size_bytes, status, view_count)
VALUES
  ('The Art of Computer Programming', 'Donald E. Knuth', '978-0201896831', 'Technology',
   'Addison-Wesley', 1968, 672,
   'The bible of all fundamental algorithms and the work that launched the field of computer science as an academic discipline.',
   'English', 'placeholder_knuth.pdf', 5242880, 'ACTIVE', 142),

  ('Sapiens: A Brief History of Humankind', 'Yuval Noah Harari', '978-0062316097', 'History',
   'Harper', 2015, 443,
   'From a renowned historian comes a groundbreaking narrative of humanity''s creation and evolution.',
   'English', 'placeholder_sapiens.pdf', 3145728, 'ACTIVE', 389),

  ('Clean Code', 'Robert C. Martin', '978-0132350884', 'Technology',
   'Prentice Hall', 2008, 464,
   'A handbook of agile software craftsmanship. Explains how to write clean, maintainable code.',
   'English', 'placeholder_cleancode.pdf', 4194304, 'ACTIVE', 275),

  ('Thinking, Fast and Slow', 'Daniel Kahneman', '978-0374533557', 'Psychology',
   'Farrar, Straus and Giroux', 2011, 499,
   'A landmark in social thought exploring the two systems that drive the way we think.',
   'English', 'placeholder_kahneman.pdf', 2097152, 'ACTIVE', 198),

  ('The Pragmatic Programmer', 'David Thomas & Andrew Hunt', '978-0135957059', 'Technology',
   'Addison-Wesley', 2019, 352,
   'Straight from the programming trenches, this guide cuts through the increasing specialization and technique ''(Divide to Conquer)''.',
   'English', 'placeholder_pragprog.pdf', 3670016, 'ACTIVE', 164),

  ('Meditations', 'Marcus Aurelius', NULL, 'Philosophy',
   'Penguin Classics', 180, 256,
   'A series of personal writings by Marcus Aurelius, Emperor of Rome — considered one of the greatest works of Stoic philosophy.',
   'English', 'placeholder_meditations.pdf', 1048576, 'ACTIVE', 521)
ON CONFLICT (isbn) DO NOTHING;

-- ============================================================
-- Useful queries
-- ============================================================

-- Full-text search
-- SELECT * FROM books WHERE to_tsvector('english', title || ' ' || COALESCE(author,'') || ' ' || COALESCE(description,'')) @@ plainto_tsquery('clean code');

-- Top viewed
-- SELECT id, title, view_count FROM books ORDER BY view_count DESC LIMIT 10;

-- Storage usage
-- SELECT pg_size_pretty(SUM(file_size_bytes)::bigint) AS total_storage FROM books WHERE status = 'ACTIVE';

-- Genre distribution
-- SELECT genre, COUNT(*) FROM books WHERE status = 'ACTIVE' GROUP BY genre ORDER BY count DESC;
