package com.librarysys.dto;

import com.librarysys.entity.Book;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

public class BookDTO {

    /**
     * Response DTO — safe to send to frontend (no internal file paths)
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private String title;
        private String author;
        private String isbn;
        private String genre;
        private String publisher;
        private Integer publishedYear;
        private Integer pageCount;
        private String description;
        private String language;
        private Long fileSizeBytes;
        private String fileSizeFormatted;
        private Long viewCount;
        private String status;
        private List<String> tags;
        private String coverUrl;   // public URL (no internal path)
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;

        public static Response from(Book book, String baseUrl) {
            return Response.builder()
                .id(book.getId())
                .title(book.getTitle())
                .author(book.getAuthor())
                .isbn(book.getIsbn())
                .genre(book.getGenre())
                .publisher(book.getPublisher())
                .publishedYear(book.getPublishedYear())
                .pageCount(book.getPageCount())
                .description(book.getDescription())
                .language(book.getLanguage())
                .fileSizeBytes(book.getFileSizeBytes())
                .fileSizeFormatted(formatFileSize(book.getFileSizeBytes()))
                .viewCount(book.getViewCount())
                .status(book.getStatus().name())
                .tags(book.getTags())
                .coverUrl(book.getCoverImagePath() != null
                    ? baseUrl + "/api/books/" + book.getId() + "/cover"
                    : null)
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt())
                .build();
        }

        private static String formatFileSize(Long bytes) {
            if (bytes == null) return "Unknown";
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
            if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
            return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
        }
    }

    /**
     * Create/Update request DTO
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateRequest {
        private String title;
        private String author;
        private String isbn;
        private String genre;
        private String publisher;
        private Integer publishedYear;
        private Integer pageCount;
        private String description;
        private String language;
        private List<String> tags;
        private String uploadedBy;
    }

    /**
     * Library stats DTO
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StatsResponse {
        private Long totalBooks;
        private Long totalStorageBytes;
        private String totalStorageFormatted;
        private List<String> genres;
        private Long totalViews;
    }

    /**
     * Paginated response wrapper
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PageResponse {
        private List<Response> books;
        private int currentPage;
        private int totalPages;
        private long totalElements;
        private int pageSize;
        private boolean hasNext;
        private boolean hasPrevious;
    }
}
