package com.librarysys.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Slf4j
@Service
public class FileStorageService {

    @Value("${app.storage.location}")
    private String booksStorageLocation;

    @Value("${app.storage.covers}")
    private String coversStorageLocation;

    private Path booksRoot;
    private Path coversRoot;

    @PostConstruct
    public void init() throws IOException {
        booksRoot = Paths.get(booksStorageLocation).toAbsolutePath().normalize();
        coversRoot = Paths.get(coversStorageLocation).toAbsolutePath().normalize();
        Files.createDirectories(booksRoot);
        Files.createDirectories(coversRoot);
        log.info("Storage initialized: books={}, covers={}", booksRoot, coversRoot);
    }

    /**
     * Store PDF file. Returns relative path stored in DB.
     */
    public String storePdf(MultipartFile file) throws IOException {
        validatePdf(file);
        String originalName = StringUtils.cleanPath(file.getOriginalFilename());
        String extension = getExtension(originalName);
        String storedName = UUID.randomUUID().toString() + "." + extension;

        Path target = booksRoot.resolve(storedName);
        try (InputStream is = file.getInputStream()) {
            Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING);
        }
        log.info("Stored PDF: {} -> {}", originalName, storedName);
        return storedName;
    }

    /**
     * Store cover image. Returns relative path.
     */
    public String storeCover(MultipartFile file) throws IOException {
        validateImage(file);
        String originalName = StringUtils.cleanPath(file.getOriginalFilename());
        String extension = getExtension(originalName);
        String storedName = UUID.randomUUID().toString() + "." + extension;

        Path target = coversRoot.resolve(storedName);
        try (InputStream is = file.getInputStream()) {
            Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING);
        }
        return storedName;
    }

    /**
     * Load PDF as byte array for streaming.
     */
    public byte[] loadPdf(String relativePath) throws IOException {
        Path filePath = booksRoot.resolve(relativePath).normalize();
        // Security check: ensure path is within books root
        if (!filePath.startsWith(booksRoot)) {
            throw new SecurityException("Attempted path traversal: " + relativePath);
        }
        return Files.readAllBytes(filePath);
    }

    /**
     * Load cover image as byte array.
     */
    public byte[] loadCover(String relativePath) throws IOException {
        Path filePath = coversRoot.resolve(relativePath).normalize();
        if (!filePath.startsWith(coversRoot)) {
            throw new SecurityException("Attempted path traversal: " + relativePath);
        }
        return Files.readAllBytes(filePath);
    }

    /**
     * Get PDF file path for streaming (efficient for large files).
     */
    public Path getPdfPath(String relativePath) throws IOException {
        Path filePath = booksRoot.resolve(relativePath).normalize();
        if (!filePath.startsWith(booksRoot)) {
            throw new SecurityException("Attempted path traversal: " + relativePath);
        }
        if (!Files.exists(filePath)) {
            throw new IOException("PDF file not found: " + relativePath);
        }
        return filePath;
    }

    /**
     * Delete PDF file from disk.
     */
    public void deletePdf(String relativePath) {
        try {
            Path filePath = booksRoot.resolve(relativePath).normalize();
            if (filePath.startsWith(booksRoot)) {
                Files.deleteIfExists(filePath);
                log.info("Deleted PDF: {}", relativePath);
            }
        } catch (IOException e) {
            log.warn("Could not delete PDF: {}", relativePath, e);
        }
    }

    /**
     * Delete cover image from disk.
     */
    public void deleteCover(String relativePath) {
        try {
            Path filePath = coversRoot.resolve(relativePath).normalize();
            if (filePath.startsWith(coversRoot)) {
                Files.deleteIfExists(filePath);
            }
        } catch (IOException e) {
            log.warn("Could not delete cover: {}", relativePath, e);
        }
    }

    private void validatePdf(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("PDF file is required");
        }
        String contentType = file.getContentType();
        if (contentType == null || !contentType.equals("application/pdf")) {
            throw new IllegalArgumentException("Only PDF files are allowed. Got: " + contentType);
        }
        // 100MB max
        if (file.getSize() > 100L * 1024 * 1024) {
            throw new IllegalArgumentException("PDF file too large. Max 100MB allowed.");
        }
    }

    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) return;
        String contentType = file.getContentType();
        if (contentType == null || (!contentType.startsWith("image/"))) {
            throw new IllegalArgumentException("Only image files allowed for cover");
        }
        if (file.getSize() > 5L * 1024 * 1024) {
            throw new IllegalArgumentException("Cover image too large. Max 5MB.");
        }
    }

    private String getExtension(String filename) {
        int dot = filename.lastIndexOf('.');
        return (dot >= 0) ? filename.substring(dot + 1).toLowerCase() : "pdf";
    }
}
