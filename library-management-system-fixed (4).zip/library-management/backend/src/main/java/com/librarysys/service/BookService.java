package com.librarysys.service;

import com.librarysys.dto.BookDTO;
import com.librarysys.entity.Book;
import com.librarysys.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.librarysys.exception.BookNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookService {

    private final BookRepository bookRepository;
    private final FileStorageService fileStorageService;

    private static final String BASE_URL = "http://localhost:8080";

    // ========== UPLOAD ==========

    @Transactional
    public BookDTO.Response uploadBook(
            BookDTO.CreateRequest request,
            MultipartFile pdfFile,
            MultipartFile coverFile) throws IOException {

        // Store PDF on disk
        String pdfPath = fileStorageService.storePdf(pdfFile);

        // Store cover if provided
        String coverPath = null;
        if (coverFile != null && !coverFile.isEmpty()) {
            coverPath = fileStorageService.storeCover(coverFile);
        }

        // Normalize blank strings to null — avoids unique constraint violation on empty ISBN
        String isbn      = blankToNull(request.getIsbn());
        String genre     = blankToNull(request.getGenre());
        String publisher = blankToNull(request.getPublisher());

        Book book = Book.builder()
            .title(request.getTitle().trim())
            .author(request.getAuthor().trim())
            .isbn(isbn)
            .genre(genre)
            .publisher(publisher)
            .publishedYear(request.getPublishedYear())
            .pageCount(request.getPageCount())
            .description(blankToNull(request.getDescription()))
            .language(request.getLanguage() != null && !request.getLanguage().isBlank() ? request.getLanguage().trim() : "English")
            .pdfFilePath(pdfPath)
            .coverImagePath(coverPath)
            .fileSizeBytes(pdfFile.getSize())
            .uploadedBy(request.getUploadedBy() != null ? request.getUploadedBy() : "admin")
            .tags(request.getTags())
            .status(Book.BookStatus.ACTIVE)
            .build();

        book = bookRepository.save(book);
        log.info("Book uploaded: id={}, title={}", book.getId(), book.getTitle());
        return BookDTO.Response.from(book, BASE_URL);
    }

    // ========== READ ==========

    public BookDTO.PageResponse getAllBooks(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.findByStatusOrderByCreatedAtDesc(
            Book.BookStatus.ACTIVE, pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.PageResponse searchBooks(String query, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.searchBooks(query.trim(), pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.PageResponse getBooksByGenre(String genre, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.findByGenre(genre, pageable);
        return toPageResponse(bookPage);
    }

    public BookDTO.Response getBookById(Long id) {
        Book book = findActiveBook(id);
        return BookDTO.Response.from(book, BASE_URL);
    }

    // ========== PDF STREAMING (read-only — no download) ==========

    @Transactional
    public Path getPdfPathForReading(Long id) throws IOException {
        Book book = findActiveBook(id);
        // Increment view counter
        bookRepository.incrementViewCount(id);
        return fileStorageService.getPdfPath(book.getPdfFilePath());
    }

    public byte[] getCoverImage(Long id) throws IOException {
        Book book = findActiveBook(id);
        if (book.getCoverImagePath() == null) {
            return null;
        }
        return fileStorageService.loadCover(book.getCoverImagePath());
    }

    // ========== STATS ==========

    public BookDTO.StatsResponse getStats() {
        Long totalBooks = bookRepository.countActiveBooks();
        Long totalStorage = bookRepository.totalStorageUsed();
        List<String> genres = bookRepository.findDistinctGenres();

        return BookDTO.StatsResponse.builder()
            .totalBooks(totalBooks != null ? totalBooks : 0L)
            .totalStorageBytes(totalStorage != null ? totalStorage : 0L)
            .totalStorageFormatted(formatSize(totalStorage))
            .genres(genres)
            .build();
    }

    public List<BookDTO.Response> getTopViewed(int limit) {
        return bookRepository.findTopViewed(PageRequest.of(0, limit))
            .stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());
    }

    public List<BookDTO.Response> getRecentlyAdded(int limit) {
        return bookRepository.findRecentlyAdded(PageRequest.of(0, limit))
            .stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());
    }

    public List<String> getAllGenres() {
        return bookRepository.findDistinctGenres();
    }

    // ========== DELETE ==========

    @Transactional
    public void deleteBook(Long id) {
        Book book = findActiveBook(id);
        // Soft-delete: set to ARCHIVED
        book.setStatus(Book.BookStatus.ARCHIVED);
        bookRepository.save(book);
        log.info("Book archived: id={}", id);
    }

    // ========== HELPERS ==========

    private Book findActiveBook(Long id) {
        return bookRepository.findById(id)
            .filter(b -> b.getStatus() == Book.BookStatus.ACTIVE)
            .orElseThrow(() -> new BookNotFoundException(id));
    }

    private BookDTO.PageResponse toPageResponse(Page<Book> page) {
        List<BookDTO.Response> books = page.getContent().stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());

        return BookDTO.PageResponse.builder()
            .books(books)
            .currentPage(page.getNumber())
            .totalPages(page.getTotalPages())
            .totalElements(page.getTotalElements())
            .pageSize(page.getSize())
            .hasNext(page.hasNext())
            .hasPrevious(page.hasPrevious())
            .build();
    }

    /** Convert blank/whitespace-only strings to null to avoid unique constraint issues */
    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }


    /** Checks PDF exists on disk — throws IOException if missing, RuntimeException if book not found */
    public void checkPdfExists(Long id) throws java.io.IOException {
        Book book = findActiveBook(id); // throws RuntimeException if not found
        fileStorageService.getPdfPath(book.getPdfFilePath()); // throws IOException if file missing
    }

    private String formatSize(Long bytes) {
        if (bytes == null || bytes == 0) return "0 B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    // ========== UPDATE / RESTORE (Admin) ==========

    @Transactional
    public BookDTO.Response updateBook(Long id, BookDTO.CreateRequest request,
                                       MultipartFile newPdfFile, MultipartFile newCoverFile)
            throws IOException {
        Book book = bookRepository.findById(id)
            .orElseThrow(() -> new BookNotFoundException(id));

        if (request.getTitle() != null && !request.getTitle().isBlank())
            book.setTitle(request.getTitle().trim());
        if (request.getAuthor() != null && !request.getAuthor().isBlank())
            book.setAuthor(request.getAuthor().trim());

        book.setIsbn(blankToNull(request.getIsbn()));
        book.setGenre(blankToNull(request.getGenre()));
        book.setPublisher(blankToNull(request.getPublisher()));
        book.setDescription(blankToNull(request.getDescription()));

        if (request.getPublishedYear() != null) book.setPublishedYear(request.getPublishedYear());
        if (request.getPageCount() != null)    book.setPageCount(request.getPageCount());
        if (request.getLanguage() != null && !request.getLanguage().isBlank())
            book.setLanguage(request.getLanguage().trim());
        if (request.getTags() != null) book.setTags(request.getTags());

        // Replace PDF if a new one is provided
        if (newPdfFile != null && !newPdfFile.isEmpty()) {
            String oldPath = book.getPdfFilePath();
            String newPath = fileStorageService.storePdf(newPdfFile);
            book.setPdfFilePath(newPath);
            book.setFileSizeBytes(newPdfFile.getSize());
            fileStorageService.deletePdf(oldPath);
            log.info("Replaced PDF for book id={}", id);
        }

        // Replace cover if provided
        if (newCoverFile != null && !newCoverFile.isEmpty()) {
            if (book.getCoverImagePath() != null) fileStorageService.deleteCover(book.getCoverImagePath());
            book.setCoverImagePath(fileStorageService.storeCover(newCoverFile));
        }

        book = bookRepository.save(book);
        log.info("Book updated: id={}, title={}", book.getId(), book.getTitle());
        return BookDTO.Response.from(book, BASE_URL);
    }

    @Transactional
    public BookDTO.Response restoreBook(Long id) {
        Book book = bookRepository.findById(id)
            .orElseThrow(() -> new BookNotFoundException(id));
        book.setStatus(Book.BookStatus.ACTIVE);
        book = bookRepository.save(book);
        log.info("Book restored: id={}", id);
        return BookDTO.Response.from(book, BASE_URL);
    }

    /** Hard-delete: removes DB record AND file from disk */
    @Transactional
    public void hardDeleteBook(Long id) {
        Book book = bookRepository.findById(id)
            .orElseThrow(() -> new BookNotFoundException(id));
        fileStorageService.deletePdf(book.getPdfFilePath());
        if (book.getCoverImagePath() != null) fileStorageService.deleteCover(book.getCoverImagePath());
        bookRepository.deleteById(id);
        log.info("Book hard-deleted: id={}", id);
    }

    public BookDTO.PageResponse getAllBooksAdmin(int page, int size, String status) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage;
        if ("ARCHIVED".equalsIgnoreCase(status)) {
            bookPage = bookRepository.findByStatusOrderByCreatedAtDesc(Book.BookStatus.ARCHIVED, pageable);
        } else if ("ALL".equalsIgnoreCase(status)) {
            bookPage = bookRepository.findAll(pageable);
        } else {
            bookPage = bookRepository.findByStatusOrderByCreatedAtDesc(Book.BookStatus.ACTIVE, pageable);
        }
        return toPageResponseAll(bookPage);
    }

    private BookDTO.PageResponse toPageResponseAll(Page<Book> page) {
        List<BookDTO.Response> books = page.getContent().stream()
            .map(b -> BookDTO.Response.from(b, BASE_URL))
            .collect(Collectors.toList());
        return BookDTO.PageResponse.builder()
            .books(books)
            .currentPage(page.getNumber())
            .totalPages(page.getTotalPages())
            .totalElements(page.getTotalElements())
            .pageSize(page.getSize())
            .hasNext(page.hasNext())
            .hasPrevious(page.hasPrevious())
            .build();
    }

}
