package com.librarysys.controller;

import com.librarysys.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/health")
@RequiredArgsConstructor
public class HealthController {

    private final BookRepository bookRepository;

    /**
     * GET /api/health
     * Returns backend status, DB connectivity, and book count.
     * If the DB is broken, this returns the actual error instead of silent 404.
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("status", "UP");
        info.put("timestamp", LocalDateTime.now().toString());
        info.put("app", "Bibliotheque Library System");

        try {
            long count = bookRepository.countActiveBooks();
            info.put("db", "CONNECTED");
            info.put("activeBooks", count);
        } catch (Exception e) {
            log.error("DB health check failed", e);
            info.put("db", "ERROR");
            info.put("dbError", e.getMessage());
            return ResponseEntity.status(503).body(info);
        }

        return ResponseEntity.ok(info);
    }
}
