package com.librarysys.repository;

import com.librarysys.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    // Full-text search across title, author, description
    @Query("""
        SELECT b FROM Book b
        WHERE b.status = 'ACTIVE'
        AND (
            LOWER(b.title)       LIKE LOWER(CONCAT('%', :query, '%')) OR
            LOWER(b.author)      LIKE LOWER(CONCAT('%', :query, '%')) OR
            LOWER(b.description) LIKE LOWER(CONCAT('%', :query, '%')) OR
            LOWER(b.genre)       LIKE LOWER(CONCAT('%', :query, '%')) OR
            LOWER(b.publisher)   LIKE LOWER(CONCAT('%', :query, '%')) OR
            LOWER(b.isbn)        LIKE LOWER(CONCAT('%', :query, '%'))
        )
        ORDER BY b.viewCount DESC, b.createdAt DESC
        """)
    Page<Book> searchBooks(@Param("query") String query, Pageable pageable);

    // Browse all active books
    Page<Book> findByStatusOrderByCreatedAtDesc(Book.BookStatus status, Pageable pageable);

    // Filter by genre
    @Query("""
        SELECT b FROM Book b
        WHERE b.status = 'ACTIVE'
        AND LOWER(b.genre) = LOWER(:genre)
        ORDER BY b.title ASC
        """)
    Page<Book> findByGenre(@Param("genre") String genre, Pageable pageable);

    // Filter by author
    @Query("""
        SELECT b FROM Book b
        WHERE b.status = 'ACTIVE'
        AND LOWER(b.author) LIKE LOWER(CONCAT('%', :author, '%'))
        ORDER BY b.publishedYear DESC
        """)
    Page<Book> findByAuthor(@Param("author") String author, Pageable pageable);

    // Get distinct genres for filter sidebar
    @Query("SELECT DISTINCT b.genre FROM Book b WHERE b.status = 'ACTIVE' AND b.genre IS NOT NULL ORDER BY b.genre")
    List<String> findDistinctGenres();

    // Get most viewed books
    @Query("SELECT b FROM Book b WHERE b.status = 'ACTIVE' ORDER BY b.viewCount DESC")
    List<Book> findTopViewed(Pageable pageable);

    // Get recently added
    @Query("SELECT b FROM Book b WHERE b.status = 'ACTIVE' ORDER BY b.createdAt DESC")
    List<Book> findRecentlyAdded(Pageable pageable);

    Optional<Book> findByIsbn(String isbn);

    // Increment view count atomically
    @Modifying
    @Query("UPDATE Book b SET b.viewCount = b.viewCount + 1 WHERE b.id = :id")
    void incrementViewCount(@Param("id") Long id);

    // Stats
    @Query("SELECT COUNT(b) FROM Book b WHERE b.status = 'ACTIVE'")
    Long countActiveBooks();

    @Query("SELECT SUM(b.fileSizeBytes) FROM Book b WHERE b.status = 'ACTIVE'")
    Long totalStorageUsed();
}
