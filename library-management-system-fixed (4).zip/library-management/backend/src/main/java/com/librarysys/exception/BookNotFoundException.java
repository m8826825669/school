package com.librarysys.exception;

/**
 * Thrown when a book is requested but doesn't exist or is not ACTIVE.
 * Maps to HTTP 404.  All other RuntimeExceptions map to HTTP 500.
 */
public class BookNotFoundException extends RuntimeException {
    public BookNotFoundException(Long id) {
        super("Book not found with id: " + id);
    }
    public BookNotFoundException(String message) {
        super(message);
    }
}
