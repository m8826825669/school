# 📚 Bibliothèque — Library Management System

A production-grade digital library with **read-only PDF serving**, full-text search,
and a beautiful dark editorial UI.

```
Stack: Spring Boot 3.2 · PostgreSQL · React 18 · PDF.js · Vite
```

---

## 🏗️ Architecture

```
library-management/
├── backend/                           ← Spring Boot REST API
│   ├── pom.xml
│   └── src/main/java/com/librarysys/
│       ├── LibraryApplication.java    — Entry point
│       ├── entity/Book.java           — JPA entity
│       ├── repository/BookRepository  — JPA queries + search
│       ├── dto/BookDTO.java           — Request/Response DTOs
│       ├── service/
│       │   ├── BookService.java       — Business logic
│       │   └── FileStorageService.java— PDF/image file ops
│       ├── controller/BookController  — REST endpoints
│       └── config/SecurityConfig.java — CORS + security headers
│
├── frontend/                          ← React SPA
│   └── src/
│       ├── App.jsx                    — Router
│       ├── api/bookApi.js             — Axios API client
│       ├── components/
│       │   ├── Navbar.jsx             — Top navigation + search
│       │   ├── BookCard.jsx           — Grid card with hover
│       │   ├── PDFViewer.jsx          — PDF.js canvas viewer
│       │   └── UploadModal.jsx        — Upload form with drag-drop
│       └── pages/
│           ├── HomePage.jsx           — Catalog + sidebar filters
│           ├── BookDetailPage.jsx     — Book info + embedded reader
│           ├── SearchPage.jsx         — Search results
│           ├── TrendingPage.jsx       — Most read + podium
│           └── UploadPage.jsx         — Upload landing
│
└── database/
    └── schema.sql                     — DDL + indexes + seed data
```

---

## 🚀 Quick Start

### 1. PostgreSQL Setup

```bash
# Create database
psql -U postgres -c "CREATE DATABASE library_db;"

# Run schema (optional — Hibernate auto-creates tables)
psql -U postgres -d library_db -f database/schema.sql
```

### 2. Backend

```bash
cd backend

# Edit credentials in src/main/resources/application.properties:
#   spring.datasource.username=postgres
#   spring.datasource.password=yourpassword

mvn spring-boot:run
# API → http://localhost:8080
```

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
# UI → http://localhost:5173
```

---

## 📡 API Reference

| Method   | Endpoint                    | Description                        |
|----------|-----------------------------|------------------------------------|
| `GET`    | `/api/books`                | List all books (paginated)         |
| `GET`    | `/api/books?page=0&size=12` | Browse with pagination             |
| `GET`    | `/api/books/search?q=`      | Full-text search                   |
| `GET`    | `/api/books/genre/{genre}`  | Filter by genre                    |
| `GET`    | `/api/books/{id}`           | Single book details                |
| `GET`    | `/api/books/{id}/read`      | **Stream PDF (inline, read-only)** |
| `GET`    | `/api/books/{id}/cover`     | Cover image                        |
| `POST`   | `/api/books/upload`         | Upload new book (multipart)        |
| `GET`    | `/api/books/stats`          | Library statistics                 |
| `GET`    | `/api/books/genres`         | All available genres               |
| `GET`    | `/api/books/top-viewed`     | Most read books                    |
| `GET`    | `/api/books/recent`         | Recently added books               |
| `DELETE` | `/api/books/{id}`           | Archive book (soft delete)         |

### Upload Request Example

```bash
curl -X POST http://localhost:8080/api/books/upload \
  -F "pdfFile=@mybook.pdf;type=application/pdf" \
  -F "coverFile=@cover.jpg;type=image/jpeg" \
  -F 'metadata={"title":"Clean Code","author":"Robert Martin","genre":"Technology","language":"English","publishedYear":2008};type=application/json'
```

---

## 🔒 Read-Only PDF Protection

PDF files are protected at multiple layers:

| Layer               | Mechanism                                        |
|---------------------|--------------------------------------------------|
| **HTTP Header**     | `Content-Disposition: inline` (never attachment) |
| **Cache-Control**   | `no-store, no-cache` — blocks browser save       |
| **No download URL** | Only `/read` endpoint — no `/download` route     |
| **Canvas renderer** | PDF.js renders to `<canvas>` — not `<embed>`     |
| **Right-click**     | `contextmenu` event prevented on viewer          |
| **CSS selection**   | `user-select: none` + `pointer-events: none`     |
| **X-Frame-Options** | `SAMEORIGIN` — no embedding in other origins     |
| **Path traversal**  | Server validates all paths stay within root dir  |

> **Note:** These measures prevent casual downloading. For military-grade DRM,
> a commercial solution with watermarking is required.

---

## 🖥️ UI Features

- **Dark editorial aesthetic** — Cormorant Garamond + DM Sans fonts, amber/gold accents
- **PDF.js canvas viewer** with custom toolbar:
  - Page navigation (prev/next/jump to page)
  - Zoom 50%–300% with step buttons
  - Rotation (90° increments)
  - Fullscreen mode
  - Keyboard shortcuts (←→ pages, +/- zoom)
  - Reading progress bar
- **Sidebar genre filter** — click to filter catalog
- **Full-text search** across title, author, genre, ISBN, description
- **Trending page** with podium for top 3 most-read books
- **Upload modal** with drag-and-drop PDF zone + cover image preview
- **Book cards** with animated hover, placeholder cover generation
- **Paginated catalog** with page number navigation
- **Toast notifications** for all actions
- **Responsive** — works on tablet/mobile

---

## ⚙️ Configuration

### application.properties

```properties
# Database
spring.datasource.url=jdbc:postgresql://localhost:5432/library_db
spring.datasource.username=postgres
spring.datasource.password=yourpassword

# File storage paths (absolute or relative to working dir)
app.storage.location=./library-storage/books
app.storage.covers=./library-storage/covers

# Max PDF upload size
spring.servlet.multipart.max-file-size=100MB

# CORS (add your frontend URL)
app.cors.allowed-origins=http://localhost:5173,https://yourdomain.com
```

### Production Build

```bash
# Backend
mvn package -DskipTests
java -jar target/library-management-1.0.0.jar

# Frontend
npm run build
# Serve dist/ with Nginx or Spring Boot static resources
```

---

## 🚀 Production Deployment (Nginx)

```nginx
server {
    listen 80;
    server_name library.yourdomain.com;

    # Frontend static files
    root /var/www/library/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend API proxy
    location /api/ {
        proxy_pass         http://localhost:8080;
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_read_timeout 120s;
        
        # PDF streaming — disable proxy buffering
        proxy_buffering    off;
        proxy_max_temp_file_size 0;
    }
}
```

---

## 🗺️ Roadmap

- [ ] JWT authentication — admin vs reader roles
- [ ] PDF watermarking with reader's name/IP
- [ ] Full-text search inside PDF content (Apache Tika + PostgreSQL FTS)
- [ ] Reading progress tracking (resume where you left off)
- [ ] Collections / bookshelves
- [ ] Book ratings and reviews
- [ ] Email notifications for new additions
- [ ] S3 / MinIO storage backend option
- [ ] OPDS catalog feed (for e-reader apps)
