import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      }
    }
  },
  // pdfjs-dist v4 uses top-level await — requires esnext target
  build: {
    target: 'esnext',
  },
  optimizeDeps: {
    // Exclude pdfjs-dist from pre-bundling; let Vite handle it natively as ESM
    exclude: ['pdfjs-dist'],
  },
  worker: {
    format: 'es',
  },
})
