import React, { useState, useRef } from 'react';
import { X, Save, Loader2, FileText, Image, CheckCircle2, RefreshCw } from 'lucide-react';
import { bookApi } from '../api/bookApi.js';
import toast from 'react-hot-toast';

const GENRES = [
  'Fiction', 'Non-Fiction', 'Science', 'Technology', 'History',
  'Philosophy', 'Biography', 'Literature', 'Mathematics', 'Medicine',
  'Law', 'Economics', 'Psychology', 'Engineering', 'Arts', 'Religion',
  'Politics', 'Travel', 'Self-Help', 'Children', 'Comics', 'Poetry'
];
const LANGUAGES = [
  'English', 'Hindi', 'Bengali', 'Telugu', 'Tamil', 'Marathi',
  'Gujarati', 'Kannada', 'Malayalam', 'Punjabi',
  'French', 'German', 'Spanish', 'Arabic', 'Chinese', 'Japanese'
];

export default function EditBookModal({ book, onClose, onSuccess }) {
  const pdfInputRef   = useRef(null);
  const coverInputRef = useRef(null);

  const [saving, setSaving] = useState(false);
  const [newPdf, setNewPdf] = useState(null);
  const [newCover, setNewCover] = useState(null);
  const [coverPreview, setCoverPreview] = useState(book.coverUrl || null);

  const [form, setForm] = useState({
    title:         book.title || '',
    author:        book.author || '',
    isbn:          book.isbn || '',
    genre:         book.genre || '',
    publisher:     book.publisher || '',
    publishedYear: book.publishedYear || '',
    pageCount:     book.pageCount || '',
    description:   book.description || '',
    language:      book.language || 'English',
    tags:          book.tags || [],
  });

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const handlePdfChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.type !== 'application/pdf') { toast.error('Only PDF allowed'); return; }
    setNewPdf(file);
  };

  const handleCoverChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setNewCover(file);
    setCoverPreview(URL.createObjectURL(file));
  };

  const handleSave = async () => {
    if (!form.title.trim() || !form.author.trim()) {
      toast.error('Title and Author are required');
      return;
    }
    setSaving(true);
    try {
      const metadata = {
        ...form,
        publishedYear: form.publishedYear ? parseInt(form.publishedYear) : null,
        pageCount:     form.pageCount     ? parseInt(form.pageCount)     : null,
      };
      await bookApi.update(book.id, metadata, newPdf, newCover);
      toast.success('Book updated successfully');
      onSuccess();
    } catch (err) {
      const msg = err.response?.data?.error || 'Update failed';
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.75)',
      backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '1rem',
      animation: 'fadeIn 0.2s var(--ease)',
    }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{
        background: 'var(--surface-2)',
        border: '1px solid var(--ink-border)',
        borderRadius: 'var(--radius-xl)',
        width: '100%', maxWidth: 700,
        maxHeight: '90vh',
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
        boxShadow: '0 32px 80px rgba(0,0,0,0.7)',
      }}>
        {/* Header */}
        <div style={{
          padding: '1.1rem 1.5rem',
          borderBottom: '1px solid var(--ink-border)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexShrink: 0,
        }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: 600 }}>
              Edit Book
            </h2>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 2 }}>
              ID #{book.id} · {book.fileSizeFormatted}
            </p>
          </div>
          <button onClick={onClose} className="btn btn-ghost" style={{ padding: '0.4rem' }}>
            <X size={17} />
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: 'auto', padding: '1.5rem', flex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>

            {/* Left */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

              {/* Replace PDF */}
              <div>
                <label>Replace PDF (optional)</label>
                <div
                  onClick={() => pdfInputRef.current?.click()}
                  style={{
                    border: `1px dashed ${newPdf ? 'var(--gold-dim)' : 'var(--ink-border)'}`,
                    borderRadius: 'var(--radius-lg)',
                    padding: '1rem',
                    textAlign: 'center',
                    cursor: 'pointer',
                    background: newPdf ? 'var(--gold-glow)' : 'var(--surface)',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => { if (!newPdf) e.currentTarget.style.borderColor = 'var(--gold-dim)'; }}
                  onMouseLeave={e => { if (!newPdf) e.currentTarget.style.borderColor = 'var(--ink-border)'; }}
                >
                  <input ref={pdfInputRef} type="file" accept="application/pdf" style={{ display: 'none' }} onChange={handlePdfChange} />
                  {newPdf ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.3rem' }}>
                      <CheckCircle2 size={20} color="var(--gold)" />
                      <p style={{ color: 'var(--gold)', fontSize: '0.8rem', fontWeight: 500 }}>{newPdf.name}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>{(newPdf.size / (1024 * 1024)).toFixed(1)} MB</p>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.3rem' }}>
                      <RefreshCw size={20} style={{ color: 'var(--text-muted)' }} />
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Click to replace PDF</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Leave empty to keep existing</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Replace Cover */}
              <div>
                <label>Replace Cover (optional)</label>
                <div
                  onClick={() => coverInputRef.current?.click()}
                  style={{
                    border: '1px dashed var(--ink-border)',
                    borderRadius: 'var(--radius-lg)',
                    cursor: 'pointer',
                    overflow: 'hidden',
                    background: 'var(--surface)',
                    aspectRatio: '3/4', maxHeight: 160,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}
                >
                  <input ref={coverInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleCoverChange} />
                  {coverPreview ? (
                    <img src={coverPreview} alt="Cover" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      <Image size={20} style={{ margin: '0 auto 0.3rem' }} />
                      <p style={{ fontSize: '0.72rem' }}>Upload cover</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right — metadata */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <Field label="Title *">
                <input className="input" value={form.title} onChange={e => set('title', e.target.value)} />
              </Field>
              <Field label="Author *">
                <input className="input" value={form.author} onChange={e => set('author', e.target.value)} />
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <Field label="ISBN">
                  <input className="input" value={form.isbn} onChange={e => set('isbn', e.target.value)} placeholder="978-…" />
                </Field>
                <Field label="Year">
                  <input className="input" type="number" value={form.publishedYear} onChange={e => set('publishedYear', e.target.value)} />
                </Field>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <Field label="Genre">
                  <select className="input" value={form.genre} onChange={e => set('genre', e.target.value)} style={{ appearance: 'none' }}>
                    <option value="">Select…</option>
                    {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </Field>
                <Field label="Language">
                  <select className="input" value={form.language} onChange={e => set('language', e.target.value)} style={{ appearance: 'none' }}>
                    {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </Field>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <Field label="Publisher">
                  <input className="input" value={form.publisher} onChange={e => set('publisher', e.target.value)} />
                </Field>
                <Field label="Pages">
                  <input className="input" type="number" value={form.pageCount} onChange={e => set('pageCount', e.target.value)} />
                </Field>
              </div>
            </div>
          </div>

          {/* Description */}
          <div style={{ marginTop: '1rem' }}>
            <Field label="Description">
              <textarea
                className="input"
                value={form.description}
                onChange={e => set('description', e.target.value)}
                rows={3}
                style={{ resize: 'vertical' }}
              />
            </Field>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding: '1rem 1.5rem',
          borderTop: '1px solid var(--ink-border)',
          display: 'flex', gap: '0.75rem', justifyContent: 'flex-end',
          flexShrink: 0,
          background: 'var(--surface)',
        }}>
          <button className="btn btn-ghost" onClick={onClose} disabled={saving}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving} style={{ minWidth: 110 }}>
            {saving
              ? <><Loader2 size={14} style={{ animation: 'spin 0.8s linear infinite' }} /> Saving…</>
              : <><Save size={14} /> Save Changes</>
            }
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label>{label}</label>
      {children}
    </div>
  );
}
