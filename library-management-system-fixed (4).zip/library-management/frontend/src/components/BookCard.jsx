import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Eye, Calendar, User, Tag } from 'lucide-react';

export default function BookCard({ book }) {
  const [imgError, setImgError] = useState(false);
  const [hovered, setHovered] = useState(false);

  const genreColors = {
    'Fiction': '#7c6af7',
    'Non-Fiction': '#4caf84',
    'Science': '#4aa3df',
    'History': '#c9a84c',
    'Technology': '#5bc2e7',
    'Philosophy': '#e07c9c',
    'Biography': '#e09c4a',
    'Literature': '#9cba7c',
  };
  const genreColor = genreColors[book.genre] || 'var(--gold)';

  return (
    <Link to={`/book/${book.id}`} style={{ textDecoration: 'none' }}>
      <article
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          background: hovered ? 'var(--card-hover)' : 'var(--card-bg)',
          border: `1px solid ${hovered ? 'var(--gold-dim)' : 'var(--ink-border)'}`,
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
          transition: 'all 0.28s var(--ease)',
          transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
          boxShadow: hovered
            ? '0 12px 40px rgba(0,0,0,0.5), 0 0 0 1px var(--gold-dim)'
            : '0 2px 8px rgba(0,0,0,0.2)',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
        }}
      >
        {/* Cover image */}
        <div style={{
          width: '100%',
          aspectRatio: '3/4',
          maxHeight: 240,
          overflow: 'hidden',
          position: 'relative',
          background: 'var(--ink-mid)',
          flexShrink: 0,
        }}>
          {book.coverUrl && !imgError ? (
            <img
              src={book.coverUrl}
              alt={book.title}
              onError={() => setImgError(true)}
              style={{
                width: '100%', height: '100%',
                objectFit: 'cover',
                transition: 'transform 0.4s var(--ease)',
                transform: hovered ? 'scale(1.05)' : 'scale(1)',
              }}
            />
          ) : (
            <PlaceholderCover title={book.title} author={book.author} color={genreColor} hovered={hovered} />
          )}

          {/* Overlay on hover */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(180deg, transparent 40%, rgba(13,13,14,0.9) 100%)',
            opacity: hovered ? 1 : 0,
            transition: 'opacity 0.25s',
            display: 'flex', alignItems: 'flex-end',
            padding: '1rem',
          }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.4rem',
              color: 'var(--gold)',
              fontFamily: 'var(--font-display)',
              fontSize: '1rem',
              fontWeight: 500,
            }}>
              <BookOpen size={16} />
              Read Now
            </div>
          </div>

          {/* Genre badge */}
          {book.genre && (
            <div style={{
              position: 'absolute', top: '0.6rem', left: '0.6rem',
              padding: '0.2rem 0.6rem',
              borderRadius: 100,
              fontSize: '0.68rem',
              fontWeight: 600,
              letterSpacing: '0.06em',
              background: `${genreColor}22`,
              color: genreColor,
              border: `1px solid ${genreColor}44`,
              backdropFilter: 'blur(8px)',
              textTransform: 'uppercase',
            }}>
              {book.genre}
            </div>
          )}
        </div>

        {/* Info */}
        <div style={{ padding: '1rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          <h3 style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.05rem',
            fontWeight: 600,
            color: 'var(--text-primary)',
            lineHeight: 1.3,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            transition: 'color 0.2s',
            ...(hovered && { color: 'var(--gold-light)' }),
          }}>
            {book.title}
          </h3>

          <p style={{
            fontSize: '0.8125rem',
            color: 'var(--text-secondary)',
            display: 'flex', alignItems: 'center', gap: '0.35rem',
          }}>
            <User size={11} />
            {book.author}
          </p>

          {book.description && (
            <p style={{
              fontSize: '0.8rem',
              color: 'var(--text-muted)',
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
              lineHeight: 1.5,
              marginTop: '0.2rem',
            }}>
              {book.description}
            </p>
          )}

          <div style={{ marginTop: 'auto', paddingTop: '0.6rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              <Eye size={11} />
              {book.viewCount?.toLocaleString() ?? 0} views
            </span>
            {book.publishedYear && (
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                <Calendar size={11} />
                {book.publishedYear}
              </span>
            )}
            <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
              {book.fileSizeFormatted}
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

function PlaceholderCover({ title, author, color, hovered }) {
  const initials = title?.slice(0, 2).toUpperCase() || 'BK';
  return (
    <div style={{
      width: '100%', height: '100%',
      background: `linear-gradient(135deg, ${color}18, ${color}08)`,
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      gap: '0.75rem',
      borderBottom: `3px solid ${color}44`,
      transition: 'background 0.3s',
    }}>
      {/* Decorative lines */}
      <div style={{ position: 'absolute', inset: '1rem', border: `1px solid ${color}18`, borderRadius: 4 }} />
      <div style={{
        width: 64, height: 64,
        borderRadius: '50%',
        background: `${color}22`,
        border: `2px solid ${color}44`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)',
        fontSize: '1.5rem',
        color: color,
        fontWeight: 600,
        letterSpacing: '0.05em',
      }}>
        {initials}
      </div>
      <p style={{
        fontSize: '0.7rem',
        color: `${color}88`,
        fontStyle: 'italic',
        textAlign: 'center',
        padding: '0 1rem',
        fontFamily: 'var(--font-display)',
      }}>
        {author}
      </p>
    </div>
  );
}
