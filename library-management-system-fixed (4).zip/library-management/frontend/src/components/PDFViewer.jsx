import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize2,
  Minimize2, RotateCw, Loader2, AlertCircle, Book
} from 'lucide-react';

// Lazy-load pdfjs to prevent top-level-await crash at module init time
let pdfjsLib = null;
async function getPdfJs() {
  if (pdfjsLib) return pdfjsLib;
  const pdfjs = await import('pdfjs-dist');
  // Use CDN worker — avoids bundler issues with pdfjs worker format
  pdfjs.GlobalWorkerOptions.workerSrc =
    `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.3.136/pdf.worker.min.mjs`;
  pdfjsLib = pdfjs;
  return pdfjs;
}

export default function PDFViewer({ bookId, title }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  const [pdfDoc, setPdfDoc] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.2);
  const [rotation, setRotation] = useState(0);
  const [loading, setLoading] = useState(true);
  const [pageLoading, setPageLoading] = useState(false);
  const [error, setError] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [inputPage, setInputPage] = useState('1');
  const [retryCount, setRetryCount] = useState(0);

  // Prevent right-click on the viewer
  useEffect(() => {
    const prevent = (e) => e.preventDefault();
    const el = containerRef.current;
    if (el) {
      el.addEventListener('contextmenu', prevent);
      return () => el.removeEventListener('contextmenu', prevent);
    }
  }, []);

  // Load PDF — dynamically import pdfjs to avoid Vite/esnext crash
  useEffect(() => {
    if (!bookId) return;
    setLoading(true);
    setError(null);

    const pdfUrl = `/api/books/${bookId}/read`;

    getPdfJs()
      .then(pdfjs => pdfjs.getDocument({ url: pdfUrl, withCredentials: false }).promise)
      .then(doc => {
        setPdfDoc(doc);
        setTotalPages(doc.numPages);
        setCurrentPage(1);
        setLoading(false);
      })
      .catch(err => {
        console.error('PDF load error:', err);
        // pdfjs wraps HTTP errors — check status
        const status = err?.status || err?.response?.status;
        if (status === 404 || (err?.message && err.message.includes('404'))) {
          setError('PDF_NOT_FOUND');
        } else {
          setError('PDF_LOAD_ERROR');
        }
        setLoading(false);
      });
  }, [bookId, retryCount]);

  // Render page
  const renderPage = useCallback(async (pageNum, doc, currentScale, currentRotation) => {
    if (!doc || !canvasRef.current) return;

    setPageLoading(true);
    try {
      const page = await doc.getPage(pageNum);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      const viewport = page.getViewport({ scale: currentScale, rotation: currentRotation });
      canvas.width = viewport.width;
      canvas.height = viewport.height;

      await page.render({ canvasContext: ctx, viewport }).promise;
    } catch (err) {
      console.error('Page render error:', err);
    } finally {
      setPageLoading(false);
    }
  }, []);

  useEffect(() => {
    if (pdfDoc) {
      renderPage(currentPage, pdfDoc, scale, rotation);
    }
  }, [currentPage, pdfDoc, scale, rotation, renderPage]);

  const goToPage = (page) => {
    const p = Math.max(1, Math.min(page, totalPages));
    setCurrentPage(p);
    setInputPage(String(p));
  };

  const zoomIn = () => setScale(s => Math.min(s + 0.2, 3.0));
  const zoomOut = () => setScale(s => Math.max(s - 0.2, 0.5));
  const rotate = () => setRotation(r => (r + 90) % 360);

  // Keyboard navigation
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') goToPage(currentPage + 1);
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') goToPage(currentPage - 1);
      if (e.key === '+' || e.key === '=') zoomIn();
      if (e.key === '-') zoomOut();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [currentPage, totalPages]);

  const toolbarStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 10,
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    padding: '0.6rem 1rem',
    background: 'rgba(13,13,14,0.95)',
    backdropFilter: 'blur(20px)',
    borderBottom: '1px solid var(--ink-border)',
    flexWrap: 'wrap',
  };

  if (loading) {
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', height: 480, gap: '1rem',
        background: 'var(--surface)',
        borderRadius: 'var(--radius-lg)',
      }}>
        <Loader2 size={36} style={{ color: 'var(--gold)', animation: 'spin 1s linear infinite' }} />
        <p style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-display)', fontSize: '1.1rem' }}>
          Loading {title}...
        </p>
      </div>
    );
  }

  if (error) {
    const isNotFound = error === 'PDF_NOT_FOUND';
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', minHeight: 420, gap: '1.5rem',
        background: 'var(--surface)',
        border: '1px solid var(--ink-border)',
        borderRadius: 'var(--radius-lg)',
        padding: '3rem 2rem',
        textAlign: 'center',
      }}>
        {/* Icon */}
        <div style={{
          width: 80, height: 80,
          borderRadius: '50%',
          background: isNotFound ? 'rgba(201,168,76,0.08)' : 'rgba(224,92,92,0.08)',
          border: `1px solid ${isNotFound ? 'rgba(201,168,76,0.25)' : 'rgba(224,92,92,0.25)'}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {isNotFound
            ? <Book size={34} color="var(--gold)" style={{ opacity: 0.7 }} />
            : <AlertCircle size={34} color="var(--error)" style={{ opacity: 0.8 }} />
          }
        </div>

        {/* Decorative line */}
        <div style={{
          width: 40, height: 2,
          background: isNotFound
            ? 'linear-gradient(90deg, transparent, var(--gold-dim), transparent)'
            : 'linear-gradient(90deg, transparent, var(--error), transparent)',
          borderRadius: 2,
        }} />

        <div>
          <h3 style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.4rem',
            fontWeight: 600,
            marginBottom: '0.5rem',
            color: 'var(--text-primary)',
          }}>
            {isNotFound ? 'PDF File Unavailable' : 'Could Not Load PDF'}
          </h3>
          <p style={{
            color: 'var(--text-muted)',
            fontSize: '0.875rem',
            maxWidth: 380,
            lineHeight: 1.7,
          }}>
            {isNotFound
              ? 'The physical PDF file for this book is missing from the server storage. The book record exists but the file may have been removed or not yet uploaded.'
              : 'Something went wrong while loading the PDF. This may be a network issue or the file may be corrupted.'
            }
          </p>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', justifyContent: 'center' }}>
          {!isNotFound && (
            <button
              className="btn btn-primary"
              onClick={() => { setError(null); setLoading(true); setRetryCount(r => r + 1); }}
            >
              Try Again
            </button>
          )}
          <button
            className="btn btn-outline"
            onClick={() => window.history.back()}
          >
            Go Back
          </button>
        </div>

        {isNotFound && (
          <p style={{
            fontSize: '0.75rem',
            color: 'var(--text-muted)',
            padding: '0.6rem 1rem',
            background: 'var(--ink-mid)',
            borderRadius: 'var(--radius)',
            border: '1px solid var(--ink-border)',
          }}>
            💡 To fix this: re-upload the book PDF using the <strong style={{ color: 'var(--text-secondary)' }}>Add Book</strong> button with the same metadata.
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      style={{
        background: 'var(--surface)',
        borderRadius: fullscreen ? 0 : 'var(--radius-lg)',
        border: '1px solid var(--ink-border)',
        overflow: 'hidden',
        position: fullscreen ? 'fixed' : 'relative',
        inset: fullscreen ? 0 : 'auto',
        zIndex: fullscreen ? 9999 : 'auto',
        display: 'flex',
        flexDirection: 'column',
        userSelect: 'none', // Prevent text selection as anti-copy measure
      }}
    >
      {/* Toolbar */}
      <div style={toolbarStyle}>
        {/* Book title */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          flex: 1, minWidth: 0,
        }}>
          <Book size={14} style={{ color: 'var(--gold)', flexShrink: 0 }} />
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: '0.95rem',
            color: 'var(--text-secondary)',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {title}
          </span>
        </div>

        {/* Divider */}
        <div style={{ width: 1, height: 24, background: 'var(--ink-border)' }} />

        {/* Page navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage <= 1}
            className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: currentPage <= 1 ? 0.3 : 1 }}
          >
            <ChevronLeft size={16} />
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <input
              type="number"
              value={inputPage}
              onChange={e => setInputPage(e.target.value)}
              onBlur={() => {
                const n = parseInt(inputPage);
                if (!isNaN(n)) goToPage(n);
                else setInputPage(String(currentPage));
              }}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  const n = parseInt(inputPage);
                  if (!isNaN(n)) goToPage(n);
                }
              }}
              style={{
                width: 52, padding: '0.3rem 0.4rem',
                background: 'var(--ink-soft)',
                border: '1px solid var(--ink-border)',
                borderRadius: 'var(--radius)',
                color: 'var(--text-primary)',
                fontSize: '0.8rem',
                textAlign: 'center',
                outline: 'none',
              }}
            />
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
              / {totalPages}
            </span>
          </div>

          <button
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage >= totalPages}
            className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: currentPage >= totalPages ? 0.3 : 1 }}
          >
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Divider */}
        <div style={{ width: 1, height: 24, background: 'var(--ink-border)' }} />

        {/* Zoom controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button onClick={zoomOut} disabled={scale <= 0.5} className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: scale <= 0.5 ? 0.3 : 1 }}>
            <ZoomOut size={15} />
          </button>
          <span style={{
            minWidth: 44, textAlign: 'center',
            fontSize: '0.78rem', color: 'var(--text-secondary)',
          }}>
            {Math.round(scale * 100)}%
          </span>
          <button onClick={zoomIn} disabled={scale >= 3.0} className="btn btn-ghost"
            style={{ padding: '0.4rem', opacity: scale >= 3.0 ? 0.3 : 1 }}>
            <ZoomIn size={15} />
          </button>
        </div>

        {/* Rotate */}
        <button onClick={rotate} className="btn btn-ghost" style={{ padding: '0.4rem' }}
          title="Rotate 90°">
          <RotateCw size={15} />
        </button>

        {/* Fullscreen */}
        <button
          onClick={() => setFullscreen(f => !f)}
          className="btn btn-ghost"
          style={{ padding: '0.4rem' }}
          title={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
        >
          {fullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </button>
      </div>

      {/* Canvas area */}
      <div style={{
        flex: 1,
        overflow: 'auto',
        background: 'var(--ink)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        padding: '1.5rem',
        minHeight: fullscreen ? 'calc(100vh - 56px)' : 500,
        position: 'relative',
      }}>
        {pageLoading && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'rgba(13,13,14,0.5)',
            zIndex: 5,
          }}>
            <Loader2 size={28} style={{ color: 'var(--gold)', animation: 'spin 0.8s linear infinite' }} />
          </div>
        )}

        <canvas
          ref={canvasRef}
          style={{
            maxWidth: '100%',
            boxShadow: '0 8px 48px rgba(0,0,0,0.6)',
            borderRadius: 2,
            // Disable all browser default behaviors for copy/download
            WebkitUserSelect: 'none',
            MozUserSelect: 'none',
            userSelect: 'none',
            pointerEvents: 'none', // Prevents drag-to-select
          }}
        />
      </div>

      {/* Page progress bar */}
      <div style={{
        height: 3,
        background: 'var(--ink-border)',
        flexShrink: 0,
      }}>
        <div style={{
          height: '100%',
          background: 'linear-gradient(90deg, var(--gold-dim), var(--gold))',
          width: `${(currentPage / totalPages) * 100}%`,
          transition: 'width 0.3s var(--ease)',
        }} />
      </div>
    </div>
  );
}
