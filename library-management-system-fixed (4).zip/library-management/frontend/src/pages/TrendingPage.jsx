import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Eye, ArrowLeft, BookOpen, Award } from 'lucide-react';
import BookCard from '../components/BookCard.jsx';
import { bookApi } from '../api/bookApi.js';

export default function TrendingPage() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    bookApi.getTopViewed(24)
      .then(setBooks)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh', animation: 'fadeIn 0.35s var(--ease)' }}>

      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, var(--ink-soft), var(--ink-mid))',
        borderBottom: '1px solid var(--ink-border)',
        padding: '3rem 2rem 2.5rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', right: -80, top: -80,
          width: 360, height: 360,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(201,168,76,0.08) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div className="container" style={{ maxWidth: 1200 }}>
          <Link to="/" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            color: 'var(--text-muted)', fontSize: '0.82rem', marginBottom: '1rem',
          }}>
            <ArrowLeft size={13} />
            Back to Library
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              width: 44, height: 44,
              background: 'var(--gold-glow)',
              border: '1px solid var(--gold-dim)',
              borderRadius: 10,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <TrendingUp size={20} color="var(--gold)" />
            </div>
            <div>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 600 }}>
                Most Read
              </h1>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.2rem' }}>
                Top books by total reads across the library
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container" style={{ maxWidth: 1200, padding: '2.5rem 2rem' }}>
        {/* Top 3 podium */}
        {!loading && books.length >= 3 && (
          <div style={{ marginBottom: '3rem' }}>
            <p style={{
              fontSize: '0.7rem', letterSpacing: '0.15em',
              textTransform: 'uppercase', color: 'var(--text-muted)',
              marginBottom: '1.25rem',
            }}>
              Top Picks
            </p>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1.1fr 1fr',
              gap: '1rem',
              alignItems: 'end',
            }}>
              {[books[1], books[0], books[2]].map((book, podiumIdx) => {
                const rank = podiumIdx === 1 ? 1 : podiumIdx === 0 ? 2 : 3;
                const heights = [180, 220, 160];
                const colors = ['#c0c0c0', 'var(--gold)', '#cd7f32'];
                return (
                  <Link key={book.id} to={`/book/${book.id}`} style={{ textDecoration: 'none' }}>
                    <div style={{
                      background: 'var(--card-bg)',
                      border: `1px solid ${rank === 1 ? 'var(--gold-dim)' : 'var(--ink-border)'}`,
                      borderRadius: 'var(--radius-lg)',
                      padding: '1.25rem',
                      textAlign: 'center',
                      height: heights[podiumIdx],
                      display: 'flex', flexDirection: 'column', justifyContent: 'center',
                      gap: '0.5rem',
                      transition: 'all 0.2s',
                      position: 'relative',
                      boxShadow: rank === 1 ? '0 8px 32px var(--gold-glow)' : 'none',
                    }}>
                      {rank === 1 && (
                        <Award size={20} style={{
                          color: 'var(--gold)',
                          position: 'absolute', top: '0.75rem', right: '0.75rem',
                        }} />
                      )}
                      <div style={{
                        width: 32, height: 32,
                        borderRadius: '50%',
                        background: `${colors[podiumIdx]}22`,
                        border: `2px solid ${colors[podiumIdx]}`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        margin: '0 auto',
                        fontSize: '0.85rem',
                        fontWeight: 700,
                        color: colors[podiumIdx],
                      }}>
                        {rank}
                      </div>
                      <p style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        color: 'var(--text-primary)',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}>
                        {book.title}
                      </p>
                      <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{book.author}</p>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                        color: 'var(--gold)', fontSize: '0.78rem', justifyContent: 'center',
                      }}>
                        <Eye size={11} />{book.viewCount?.toLocaleString()} reads
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* Full grid */}
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '4rem' }}>
            <div className="spinner" />
          </div>
        ) : books.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <p style={{
              fontSize: '0.7rem', letterSpacing: '0.15em',
              textTransform: 'uppercase', color: 'var(--text-muted)',
              marginBottom: '1.25rem',
            }}>
              Full Ranking
            </p>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: '1.25rem',
            }}>
              {books.map((book, idx) => (
                <div key={book.id} style={{ position: 'relative' }}>
                  <div style={{
                    position: 'absolute', top: 8, right: 8,
                    width: 28, height: 28,
                    background: 'rgba(13,13,14,0.85)',
                    backdropFilter: 'blur(8px)',
                    borderRadius: '50%',
                    border: '1px solid var(--ink-border)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    color: idx < 3 ? 'var(--gold)' : 'var(--text-muted)',
                    zIndex: 2,
                  }}>
                    #{idx + 1}
                  </div>
                  <BookCard book={book} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>
      <BookOpen size={40} style={{ margin: '0 auto 1rem', opacity: 0.4 }} />
      <p>No books have been read yet.</p>
    </div>
  );
}
