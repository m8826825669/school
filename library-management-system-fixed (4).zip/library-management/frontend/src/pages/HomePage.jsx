import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import {
  Library, TrendingUp, Clock, ChevronRight, ChevronLeft,
  Search, SlidersHorizontal, BookOpen, Layers, Loader2
} from 'lucide-react';
import BookCard from '../components/BookCard.jsx';
import { bookApi, healthCheck } from '../api/bookApi.js';

const PAGE_SIZE = 12;

export default function HomePage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [books, setBooks] = useState([]);
  const [stats, setStats] = useState(null);
  const [genres, setGenres] = useState([]);
  const [trending, setTrending] = useState([]);
  const [recent, setRecent] = useState([]);

  const [activeGenre, setActiveGenre] = useState(null);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);
  const [activeTab, setActiveTab] = useState('all'); // all | trending | recent

  // Load sidebar data once
  useEffect(() => {
    Promise.all([
      bookApi.getStats(),
      bookApi.getGenres(),
      bookApi.getTopViewed(6),
      bookApi.getRecent(6),
    ]).then(([s, g, t, r]) => {
      setStats(s);
      setGenres(g);
      setTrending(t);
      setRecent(r);
    }).catch(console.error);
  }, []);

  // Load books based on filters
  const loadBooks = useCallback(async () => {
    setLoading(true);
    try {
      let result;
      if (activeGenre) {
        result = await bookApi.getByGenre(activeGenre, page, PAGE_SIZE);
      } else if (activeTab === 'trending') {
        const data = await bookApi.getTopViewed(24);
        setBooks(data);
        setTotalPages(1);
        setTotalElements(data.length);
        setLoading(false);
        return;
      } else if (activeTab === 'recent') {
        const data = await bookApi.getRecent(24);
        setBooks(data);
        setTotalPages(1);
        setTotalElements(data.length);
        setLoading(false);
        return;
      } else {
        result = await bookApi.getAll(page, PAGE_SIZE);
      }
      setBooks(result.books);
      setTotalPages(result.totalPages);
      setTotalElements(result.totalElements);
    } catch (err) {
      console.error('Books API error:', err?.response?.status, err?.response?.data || err.message);
      // Run health check to give a meaningful diagnosis
      healthCheck().then(h => {
        if (h.db === 'ERROR') {
          setApiError('Database error: ' + h.dbError);
        } else if (h.status !== 'UP') {
          setApiError(h.error || 'Cannot connect to backend on port 8080. Run: cd backend && mvn spring-boot:run');
        } else {
          const status = err?.response?.status;
          const detail = err?.response?.data?.detail || err?.response?.data?.error || '';
          setApiError('API error (HTTP ' + (status || '?') + ')' + (detail ? ': ' + detail : '') + '. Check backend console logs.');
        }
      }).catch(() => {
        setApiError('Cannot connect to backend on port 8080. Run: cd backend && mvn spring-boot:run');
      });
    } finally {
      setLoading(false);
    }
  }, [activeGenre, page, activeTab]);

  useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  const selectGenre = (genre) => {
    setActiveGenre(genre === activeGenre ? null : genre);
    setActiveTab('all');
    setPage(0);
  };

  const selectTab = (tab) => {
    setActiveTab(tab);
    setActiveGenre(null);
    setPage(0);
  };

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh' }}>

      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(135deg, var(--ink-soft) 0%, var(--ink-mid) 100%)',
        borderBottom: '1px solid var(--ink-border)',
        padding: '3.5rem 2rem 3rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Background decorations */}
        <div style={{
          position: 'absolute', right: -60, top: -60,
          width: 400, height: 400,
          borderRadius: '50%',
          background: 'radial-gradient(circle, var(--gold-glow) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', left: '40%', bottom: -40,
          width: 200, height: 200,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(76, 175, 132, 0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div className="container" style={{ maxWidth: 1200, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.75rem' }}>
            <div style={{ width: 3, height: 24, background: 'var(--gold)', borderRadius: 2 }} />
            <span style={{
              fontSize: '0.75rem', letterSpacing: '0.15em',
              color: 'var(--gold)', textTransform: 'uppercase', fontWeight: 600
            }}>
              Digital Library
            </span>
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            fontWeight: 600,
            marginBottom: '0.75rem',
            background: 'linear-gradient(135deg, var(--text-primary) 0%, var(--gold-light) 60%, var(--gold) 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Bibliothèque
          </h1>
          <p style={{
            color: 'var(--text-secondary)', fontSize: '1rem',
            maxWidth: 480, lineHeight: 1.7, marginBottom: '2rem',
          }}>
            A curated collection of knowledge. Read, explore, and discover — entirely in your browser.
          </p>

          {/* Stats row */}
          {stats && (
            <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
              <StatPill icon={<BookOpen size={14} />} label="Books" value={stats.totalBooks?.toLocaleString()} />
              <StatPill icon={<Layers size={14} />} label="Genres" value={stats.genres?.length} />
              <StatPill icon={<Library size={14} />} label="Storage" value={stats.totalStorageFormatted} />
            </div>
          )}
        </div>
      </div>

      {/* Main layout */}
      <div className="container" style={{
        maxWidth: 1200,
        display: 'grid',
        gridTemplateColumns: '220px 1fr',
        gap: '2rem',
        padding: '2rem',
        alignItems: 'start',
      }}>

        {/* Sidebar */}
        <aside style={{ position: 'sticky', top: 'calc(var(--navbar-h) + 1rem)' }}>

          {/* Section tabs */}
          <div style={{ marginBottom: '1.5rem' }}>
            <p style={{ fontSize: '0.7rem', letterSpacing: '0.12em', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.6rem' }}>
              Browse
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
              {[
                { id: 'all', icon: <Library size={14} />, label: 'All Books' },
                { id: 'trending', icon: <TrendingUp size={14} />, label: 'Most Read' },
                { id: 'recent', icon: <Clock size={14} />, label: 'Recently Added' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => selectTab(tab.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '0.6rem',
                    padding: '0.55rem 0.75rem',
                    borderRadius: 'var(--radius)',
                    border: 'none',
                    background: activeTab === tab.id && !activeGenre ? 'var(--gold-glow)' : 'transparent',
                    color: activeTab === tab.id && !activeGenre ? 'var(--gold)' : 'var(--text-secondary)',
                    fontSize: '0.85rem',
                    fontWeight: activeTab === tab.id && !activeGenre ? 600 : 400,
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'all 0.15s',
                  }}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="divider" style={{ margin: '1rem 0' }} />

          {/* Genres */}
          {genres.length > 0 && (
            <div>
              <p style={{ fontSize: '0.7rem', letterSpacing: '0.12em', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.6rem' }}>
                Genres
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.15rem' }}>
                {genres.map(genre => (
                  <button
                    key={genre}
                    onClick={() => selectGenre(genre)}
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '0.45rem 0.75rem',
                      borderRadius: 'var(--radius)',
                      border: 'none',
                      background: activeGenre === genre ? 'var(--gold-glow)' : 'transparent',
                      color: activeGenre === genre ? 'var(--gold)' : 'var(--text-secondary)',
                      fontSize: '0.84rem',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'all 0.15s',
                    }}
                  >
                    {genre}
                    {activeGenre === genre && <ChevronRight size={12} />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* Main content */}
        <main>
          {/* Toolbar */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            marginBottom: '1.5rem',
          }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 600 }}>
                {activeGenre ? activeGenre :
                  activeTab === 'trending' ? 'Most Read' :
                  activeTab === 'recent' ? 'Recently Added' : 'All Books'}
              </h2>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                {totalElements > 0 ? `${totalElements.toLocaleString()} book${totalElements !== 1 ? 's' : ''}` : ''}
              </p>
            </div>
            {activeGenre && (
              <button className="btn btn-ghost" onClick={() => selectGenre(null)} style={{ fontSize: '0.8rem' }}>
                <X size={13} /> Clear filter
              </button>
            )}
          </div>

          {/* Book grid */}
          {loading ? (
            <LoadingGrid />
          ) : books.length === 0 ? (
            <EmptyState onUpload={() => navigate('/upload')} />
          ) : (
            <>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                gap: '1.25rem',
              }}>
                {books.map(book => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  gap: '0.5rem', marginTop: '2.5rem',
                }}>
                  <button
                    className="btn btn-ghost"
                    onClick={() => setPage(p => p - 1)}
                    disabled={page === 0}
                    style={{ opacity: page === 0 ? 0.3 : 1 }}
                  >
                    <ChevronLeft size={16} /> Prev
                  </button>
                  <div style={{ display: 'flex', gap: '0.3rem' }}>
                    {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                      const pageNum = totalPages <= 7 ? i :
                        page < 4 ? i :
                        page > totalPages - 4 ? totalPages - 7 + i :
                        page - 3 + i;
                      return (
                        <button
                          key={pageNum}
                          onClick={() => setPage(pageNum)}
                          style={{
                            width: 36, height: 36,
                            borderRadius: 'var(--radius)',
                            border: '1px solid ' + (pageNum === page ? 'var(--gold)' : 'var(--ink-border)'),
                            background: pageNum === page ? 'var(--gold-glow)' : 'transparent',
                            color: pageNum === page ? 'var(--gold)' : 'var(--text-secondary)',
                            fontSize: '0.85rem',
                            cursor: 'pointer',
                            fontWeight: pageNum === page ? 600 : 400,
                            transition: 'all 0.15s',
                          }}
                        >
                          {pageNum + 1}
                        </button>
                      );
                    })}
                  </div>
                  <button
                    className="btn btn-ghost"
                    onClick={() => setPage(p => p + 1)}
                    disabled={page >= totalPages - 1}
                    style={{ opacity: page >= totalPages - 1 ? 0.3 : 1 }}
                  >
                    Next <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

function StatPill({ icon, label, value }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '0.5rem',
      padding: '0.4rem 0.9rem',
      background: 'rgba(255,255,255,0.04)',
      border: '1px solid var(--ink-border)',
      borderRadius: 100,
    }}>
      <span style={{ color: 'var(--gold)' }}>{icon}</span>
      <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>{label}</span>
      <span style={{ color: 'var(--text-primary)', fontSize: '0.85rem', fontWeight: 600 }}>{value ?? '—'}</span>
    </div>
  );
}

function LoadingGrid() {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: '1.25rem',
    }}>
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
          animation: `pulse 1.8s ease-in-out ${i * 0.08}s infinite`,
        }}>
          <div style={{ aspectRatio: '3/4', maxHeight: 240, background: 'var(--ink-mid)' }} />
          <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <div style={{ height: 14, background: 'var(--ink-light)', borderRadius: 4, width: '80%' }} />
            <div style={{ height: 11, background: 'var(--ink-light)', borderRadius: 4, width: '55%' }} />
          </div>
        </div>
      ))}
      <style>{`@keyframes pulse { 0%,100%{opacity:.7} 50%{opacity:.4} }`}</style>
    </div>
  );
}

function ApiErrorState({ message }) {
  const [health, setHealth] = React.useState(null);

  React.useEffect(() => {
    healthCheck().then(setHealth).catch(() => setHealth({ status: 'DOWN' }));
  }, []);

  return (
    <div style={{
      textAlign: 'center', padding: '4rem 2rem',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem',
    }}>
      <div style={{
        width: 72, height: 72, borderRadius: '50%',
        background: 'rgba(201,168,76,0.1)',
        border: '1px solid rgba(201,168,76,0.3)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '2rem',
      }}>⚠️</div>
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem' }}>
        Backend Error
      </h3>
      <p style={{ color: 'var(--text-muted)', maxWidth: 460, lineHeight: 1.7 }}>
        {message}
      </p>
      {health && (
        <div style={{
          padding: '0.75rem 1.25rem',
          background: 'var(--ink-mid)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius)',
          fontSize: '0.8rem',
          textAlign: 'left',
          maxWidth: 440,
          width: '100%',
        }}>
          <p style={{ color: 'var(--text-muted)', marginBottom: '0.4rem', letterSpacing: '0.08em', fontSize: '0.7rem', textTransform: 'uppercase' }}>
            Health Check — <a href="http://localhost:8080/api/health" target="_blank" rel="noreferrer" style={{ color: 'var(--gold)' }}>localhost:8080/api/health</a>
          </p>
          <p style={{ color: health.status === 'UP' ? '#4caf84' : 'var(--error)', fontWeight: 600 }}>
            Backend: {health.status || 'DOWN'}
          </p>
          {health.db && (
            <p style={{ color: health.db === 'CONNECTED' ? '#4caf84' : 'var(--error)' }}>
              Database: {health.db}{health.dbError ? ' — ' + health.dbError : ''}
            </p>
          )}
          {health.activeBooks !== undefined && (
            <p style={{ color: 'var(--text-secondary)' }}>Active books in DB: {health.activeBooks}</p>
          )}
        </div>
      )}
      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
        <code style={{
          padding: '0.4rem 0.875rem',
          background: 'var(--ink-mid)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius)',
          fontSize: '0.8rem',
          color: 'var(--gold)',
        }}>
          cd backend &amp;&amp; mvn spring-boot:run
        </code>
        <button className="btn btn-outline" onClick={() => window.location.reload()}>
          Retry
        </button>
      </div>
    </div>
  );
}

function EmptyState({ onUpload }) {
  return (
    <div style={{
      textAlign: 'center', padding: '5rem 2rem',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem',
    }}>
      <div style={{
        width: 80, height: 80,
        borderRadius: '50%',
        background: 'var(--gold-glow)',
        border: '1px solid var(--gold-dim)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <BookOpen size={32} color="var(--gold)" />
      </div>
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Library is empty</h3>
      <p style={{ color: 'var(--text-muted)', maxWidth: 320 }}>
        No books found. Start building your collection by uploading the first PDF.
      </p>
      <button className="btn btn-primary" onClick={onUpload} style={{ marginTop: '0.5rem' }}>
        Upload First Book
      </button>
    </div>
  );
}

// Needed for clear filter button
function X({ size }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
