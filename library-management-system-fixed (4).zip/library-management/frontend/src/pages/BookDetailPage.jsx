import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, BookOpen, User, Calendar, Hash, Globe,
  Building2, FileText, Tag, Eye, Clock, Layers,
  BookMarked, AlertCircle, Loader2, Trash2
} from 'lucide-react';
import PDFViewer from '../components/PDFViewer.jsx';
import { bookApi } from '../api/bookApi.js';
import toast from 'react-hot-toast';

export default function BookDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reading, setReading] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [pdfStatus, setPdfStatus] = useState('unknown'); // 'available' | 'missing' | 'unknown'

  // Effect 1: Load book metadata — completely isolated from PDF check
  useEffect(() => {
    if (!id || id === 'undefined') {
      setError('Invalid book ID');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    setBook(null);
    setPdfStatus('unknown');
    setReading(false);

    bookApi.getById(id)
      .then(b => {
        setBook(b);
      })
      .catch(err => {
        const status = err?.response?.status;
        if (status === 404) {
          setError('Book not found');
        } else if (!navigator.onLine || err?.code === 'ERR_NETWORK') {
          setError('Cannot connect to the server. Is the backend running on port 8080?');
        } else {
          setError('Failed to load book. Please try again.');
        }
      })
      .finally(() => setLoading(false));

    window.scrollTo(0, 0);
  }, [id]);

  // Effect 2: Check PDF status separately — never affects book loading
  useEffect(() => {
    if (!book) return;
    setPdfStatus('checking');
    bookApi.checkPdfStatus(book.id)
      .then(result => setPdfStatus(result?.available ? 'available' : 'missing'))
      .catch(() => setPdfStatus('missing'));
  }, [book]);

  const handleDelete = async () => {
    try {
      await bookApi.delete(id);
      toast.success('Book archived');
      navigate('/');
    } catch {
      toast.error('Could not delete book');
    }
  };

  if (loading) {
    return (
      <div style={{
        paddingTop: 'var(--navbar-h)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        minHeight: '100vh',
      }}>
        <div style={{ textAlign: 'center' }}>
          <Loader2 size={36} style={{ color: 'var(--gold)', animation: 'spin 1s linear infinite', margin: '0 auto 1rem' }} />
          <p style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-display)' }}>Loading book...</p>
        </div>
      </div>
    );
  }

  if (error || (!loading && !book)) {
    const isNotFound = error === 'Book not found';
    const isNetwork  = error?.includes('Cannot connect');
    return (
      <div style={{
        paddingTop: 'var(--navbar-h)',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', minHeight: '80vh', gap: '1.5rem',
        textAlign: 'center', padding: '2rem',
      }}>
        <div style={{
          width: 72, height: 72, borderRadius: '50%',
          background: isNetwork ? 'rgba(201,168,76,0.1)' : 'rgba(224,92,92,0.1)',
          border: `1px solid ${isNetwork ? 'rgba(201,168,76,0.3)' : 'rgba(224,92,92,0.3)'}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <AlertCircle size={32} style={{ color: isNetwork ? 'var(--warning)' : 'var(--error)' }} />
        </div>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', marginBottom: '0.5rem' }}>
            {isNotFound ? 'Book Not Found' : isNetwork ? 'Cannot Reach Server' : 'Something Went Wrong'}
          </h2>
          <p style={{ color: 'var(--text-muted)', maxWidth: 420, lineHeight: 1.7 }}>
            {error || 'The requested book could not be loaded.'}
          </p>
          {isNetwork && (
            <p style={{
              marginTop: '0.75rem', fontSize: '0.8rem',
              color: 'var(--text-muted)',
              padding: '0.5rem 0.875rem',
              background: 'var(--ink-mid)',
              borderRadius: 'var(--radius)',
              display: 'inline-block',
              fontFamily: 'monospace',
            }}>
              Make sure backend is running: mvn spring-boot:run
            </p>
          )}
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          {!isNotFound && (
            <button className="btn btn-primary" onClick={() => window.location.reload()}>
              Retry
            </button>
          )}
          <Link to="/" className="btn btn-outline">
            <ArrowLeft size={14} /> Back to Library
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh', animation: 'fadeIn 0.4s var(--ease)' }}>

      {/* Back bar */}
      <div style={{
        background: 'var(--ink-soft)',
        borderBottom: '1px solid var(--ink-border)',
        padding: '0.75rem 2rem',
      }}>
        <div className="container" style={{ maxWidth: 1200 }}>
          <Link to="/" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            color: 'var(--text-muted)', fontSize: '0.85rem',
            transition: 'color 0.2s',
          }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
          >
            <ArrowLeft size={14} />
            Back to Library
          </Link>
        </div>
      </div>

      <div className="container" style={{ maxWidth: 1200, padding: '2.5rem 2rem' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '280px 1fr',
          gap: '3rem',
          alignItems: 'start',
        }}>

          {/* Left: Cover + actions */}
          <div>
            {/* Book cover */}
            <div style={{
              borderRadius: 'var(--radius-lg)',
              overflow: 'hidden',
              border: '1px solid var(--ink-border)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
              aspectRatio: '3/4',
              maxHeight: 380,
              background: 'var(--ink-mid)',
              marginBottom: '1.5rem',
            }}>
              {book.coverUrl && !imgError ? (
                <img
                  src={book.coverUrl}
                  alt={book.title}
                  onError={() => setImgError(true)}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              ) : (
                <div style={{
                  width: '100%', height: '100%',
                  display: 'flex', flexDirection: 'column',
                  alignItems: 'center', justifyContent: 'center',
                  gap: '1rem',
                  background: 'linear-gradient(135deg, var(--ink-mid), var(--ink-light))',
                }}>
                  <div style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '3rem',
                    fontWeight: 700,
                    color: 'var(--gold)',
                    opacity: 0.6,
                  }}>
                    {book.title.slice(0, 2).toUpperCase()}
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', textAlign: 'center', padding: '0 1.5rem', fontStyle: 'italic' }}>
                    {book.author}
                  </p>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {pdfStatus === 'missing' ? (
                <div style={{
                  padding: '0.75rem 1rem',
                  background: 'rgba(224,92,92,0.06)',
                  border: '1px solid rgba(224,92,92,0.25)',
                  borderRadius: 'var(--radius)',
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  color: 'var(--error)', fontSize: '0.82rem',
                }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  PDF file missing — re-upload to enable reading
                </div>
              ) : (
                <button
                  className="btn btn-primary"
                  onClick={() => { setReading(true); setTimeout(() => document.getElementById('reader')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  style={{ width: '100%', justifyContent: 'center', padding: '0.75rem' }}
                  disabled={pdfStatus === 'checking' || pdfStatus === 'unknown'}
                >
                  <BookOpen size={16} />
                  {(pdfStatus === 'checking' || pdfStatus === 'unknown') ? 'Checking...' : 'Read Now'}
                </button>
              )}

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                {confirmDelete ? (
                  <>
                    <button
                      className="btn btn-danger"
                      onClick={handleDelete}
                      style={{ flex: 1, justifyContent: 'center', fontSize: '0.8rem' }}
                    >
                      Confirm Delete
                    </button>
                    <button
                      className="btn btn-ghost"
                      onClick={() => setConfirmDelete(false)}
                      style={{ flex: 1, justifyContent: 'center', fontSize: '0.8rem' }}
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <button
                    className="btn btn-ghost"
                    onClick={() => setConfirmDelete(true)}
                    style={{ flex: 1, justifyContent: 'center', fontSize: '0.8rem' }}
                  >
                    <Trash2 size={13} />
                    Archive
                  </button>
                )}
              </div>
            </div>

            {/* File info */}
            <div style={{
              marginTop: '1.25rem',
              padding: '1rem',
              background: 'var(--surface-2)',
              border: '1px solid var(--ink-border)',
              borderRadius: 'var(--radius-lg)',
              display: 'flex', flexDirection: 'column', gap: '0.6rem',
            }}>
              <InfoRow icon={<FileText size={13} />} label="Format" value="PDF" />
              <InfoRow icon={<Layers size={13} />} label="Size" value={book.fileSizeFormatted} />
              {book.pageCount && <InfoRow icon={<BookMarked size={13} />} label="Pages" value={book.pageCount.toLocaleString()} />}
              <InfoRow icon={<Eye size={13} />} label="Views" value={book.viewCount?.toLocaleString() ?? '0'} />
              <InfoRow icon={<Clock size={13} />} label="Added" value={new Date(book.createdAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' })} />
            </div>
          </div>

          {/* Right: Book info */}
          <div>
            {/* Genre badge */}
            {book.genre && (
              <span className="badge badge-gold" style={{ marginBottom: '1rem', display: 'inline-flex' }}>
                {book.genre}
              </span>
            )}

            {/* Title */}
            <h1 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(1.8rem, 3vw, 2.6rem)',
              fontWeight: 600,
              lineHeight: 1.2,
              marginBottom: '0.6rem',
            }}>
              {book.title}
            </h1>

            {/* Author */}
            <p style={{
              display: 'flex', alignItems: 'center', gap: '0.4rem',
              color: 'var(--text-secondary)',
              fontFamily: 'var(--font-display)',
              fontSize: '1.1rem',
              fontStyle: 'italic',
              marginBottom: '1.5rem',
            }}>
              <User size={14} />
              {book.author}
            </p>

            {/* Metadata grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
              gap: '0.75rem',
              marginBottom: '1.75rem',
            }}>
              {book.publisher && (
                <MetaCard icon={<Building2 size={14} />} label="Publisher" value={book.publisher} />
              )}
              {book.publishedYear && (
                <MetaCard icon={<Calendar size={14} />} label="Published" value={book.publishedYear} />
              )}
              {book.isbn && (
                <MetaCard icon={<Hash size={14} />} label="ISBN" value={book.isbn} />
              )}
              {book.language && (
                <MetaCard icon={<Globe size={14} />} label="Language" value={book.language} />
              )}
            </div>

            {/* Description */}
            {book.description && (
              <div style={{ marginBottom: '1.75rem' }}>
                <div className="divider" />
                <h3 style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '1.1rem',
                  fontWeight: 500,
                  color: 'var(--text-secondary)',
                  marginBottom: '0.75rem',
                  letterSpacing: '0.04em',
                }}>
                  About this Book
                </h3>
                <p style={{
                  color: 'var(--text-secondary)',
                  lineHeight: 1.8,
                  fontSize: '0.95rem',
                }}>
                  {book.description}
                </p>
              </div>
            )}

            {/* Tags */}
            {book.tags && book.tags.length > 0 && (
              <div style={{ marginBottom: '1.75rem' }}>
                <p style={{ fontSize: '0.75rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '0.6rem' }}>
                  Tags
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {book.tags.map(tag => (
                    <span key={tag} className="badge">
                      <Tag size={9} />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Read inline CTA */}
            {!reading && (
              <div style={{
                padding: '1.5rem',
                background: 'linear-gradient(135deg, var(--gold-glow), transparent)',
                border: '1px solid var(--gold-dim)',
                borderRadius: 'var(--radius-xl)',
                display: 'flex', alignItems: 'center', gap: '1rem',
              }}>
                <div style={{
                  width: 44, height: 44,
                  borderRadius: '50%',
                  background: 'var(--gold-glow)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <BookOpen size={20} color="var(--gold)" />
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 600 }}>
                    Read in Browser
                  </p>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                    Secure, read-only viewer. No download required.
                  </p>
                </div>
                <button
                  className="btn btn-primary"
                  onClick={() => { setReading(true); setTimeout(() => document.getElementById('reader')?.scrollIntoView({ behavior: 'smooth' }), 150); }}
                  style={{ marginLeft: 'auto', flexShrink: 0 }}
                  disabled={pdfStatus === 'missing' || pdfStatus === 'checking' || pdfStatus === 'unknown'}
                >
                  {pdfStatus === 'missing' ? 'Unavailable' : (pdfStatus !== 'available' ? 'Checking...' : 'Open Reader')}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* PDF Reader — rendered below the fold */}
        {reading && (
          <div id="reader" style={{ marginTop: '3rem' }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.6rem',
              marginBottom: '1rem',
            }}>
              <div style={{ width: 3, height: 22, background: 'var(--gold)', borderRadius: 2 }} />
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 500 }}>
                Reader
              </h2>
              <span style={{ marginLeft: 'auto' }}>
                <button
                  className="btn btn-ghost"
                  onClick={() => setReading(false)}
                  style={{ fontSize: '0.8rem' }}
                >
                  Close Reader
                </button>
              </span>
            </div>
            <PDFViewer bookId={book.id} title={book.title} />
          </div>
        )}
      </div>
    </div>
  );
}

function MetaCard({ icon, label, value }) {
  return (
    <div style={{
      padding: '0.75rem',
      background: 'var(--surface-2)',
      border: '1px solid var(--ink-border)',
      borderRadius: 'var(--radius)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--gold)', marginBottom: '0.3rem' }}>
        {icon}
        <span style={{ fontSize: '0.7rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{label}</span>
      </div>
      <p style={{ fontSize: '0.875rem', color: 'var(--text-primary)', fontWeight: 500 }}>{value}</p>
    </div>
  );
}

function InfoRow({ icon, label, value }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
        {icon} {label}
      </span>
      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{value}</span>
    </div>
  );
}
