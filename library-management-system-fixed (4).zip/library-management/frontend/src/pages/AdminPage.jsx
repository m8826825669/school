import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Shield, BookOpen, HardDrive, TrendingUp, Eye, RefreshCw,
  Trash2, RotateCcw, Edit2, ChevronLeft, ChevronRight,
  CheckCircle, Archive, AlertTriangle, Search, Filter,
  Database, Activity, Plus, Layers, Clock
} from 'lucide-react';
import { bookApi } from '../api/bookApi.js';
import toast from 'react-hot-toast';
import EditBookModal from '../components/EditBookModal.jsx';

const STATUS_COLORS = {
  ACTIVE:     { bg: 'rgba(76,175,132,0.12)', border: 'rgba(76,175,132,0.3)', text: '#4caf84' },
  ARCHIVED:   { bg: 'rgba(224,92,92,0.10)',  border: 'rgba(224,92,92,0.3)',  text: '#e05c5c' },
  PROCESSING: { bg: 'rgba(201,168,76,0.12)', border: 'rgba(201,168,76,0.3)', text: '#c9a84c' },
};

export default function AdminPage() {
  const navigate = useNavigate();

  const [stats, setStats]           = useState(null);
  const [books, setBooks]           = useState([]);
  const [loading, setLoading]       = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [page, setPage]             = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchQuery, setSearchQuery]   = useState('');
  const [editBook, setEditBook]         = useState(null);
  const [confirmHardDelete, setConfirmHardDelete] = useState(null);

  // Load stats
  const loadStats = useCallback(() => {
    setStatsLoading(true);
    bookApi.getStats()
      .then(setStats)
      .catch(console.error)
      .finally(() => setStatsLoading(false));
  }, []);

  // Load books table
  const loadBooks = useCallback(() => {
    setLoading(true);
    bookApi.adminGetAll(statusFilter, page, 15)
      .then(r => {
        setBooks(r.books || []);
        setTotalPages(r.totalPages);
        setTotalElements(r.totalElements);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [statusFilter, page]);

  useEffect(() => { loadStats(); }, [loadStats]);
  useEffect(() => { loadBooks(); }, [loadBooks]);
  useEffect(() => { setPage(0); }, [statusFilter]);

  const handleArchive = async (id, title) => {
    try {
      await bookApi.delete(id);
      toast.success(`"${title}" archived`);
      loadBooks(); loadStats();
    } catch { toast.error('Failed to archive'); }
  };

  const handleRestore = async (id, title) => {
    try {
      await bookApi.restore(id);
      toast.success(`"${title}" restored`);
      loadBooks(); loadStats();
    } catch { toast.error('Failed to restore'); }
  };

  const handleHardDelete = async (book) => {
    try {
      await bookApi.hardDelete(book.id);
      toast.success(`"${book.title}" permanently deleted`);
      setConfirmHardDelete(null);
      loadBooks(); loadStats();
    } catch { toast.error('Failed to delete'); }
  };

  const filteredBooks = searchQuery
    ? books.filter(b =>
        b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.author.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : books;

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh', animation: 'fadeIn 0.35s var(--ease)' }}>

      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, var(--ink-soft) 0%, var(--ink-mid) 100%)',
        borderBottom: '1px solid var(--ink-border)',
        padding: '2.5rem 2rem',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', right: -60, top: -60,
          width: 320, height: 320, borderRadius: '50%',
          background: 'radial-gradient(circle, var(--gold-glow), transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div className="container" style={{ maxWidth: 1300, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.5rem' }}>
                <Shield size={16} style={{ color: 'var(--gold)' }} />
                <span style={{ fontSize: '0.72rem', letterSpacing: '0.15em', color: 'var(--gold)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Admin Panel
                </span>
              </div>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 600 }}>
                Library Management
              </h1>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.3rem' }}>
                Manage books, monitor storage, and maintain the collection.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <Link to="/upload" className="btn btn-primary">
                <Plus size={15} /> Add Book
              </Link>
              <Link to="/" className="btn btn-outline">
                <BookOpen size={15} /> View Library
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="container" style={{ maxWidth: 1300, padding: '2rem' }}>

        {/* Stats row */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: '1rem',
          marginBottom: '2.5rem',
        }}>
          <StatCard
            icon={<BookOpen size={18} />}
            label="Active Books"
            value={statsLoading ? '…' : (stats?.totalBooks ?? 0).toLocaleString()}
            color="var(--gold)"
          />
          <StatCard
            icon={<HardDrive size={18} />}
            label="Storage Used"
            value={statsLoading ? '…' : (stats?.totalStorageFormatted ?? '0 B')}
            color="#4caf84"
          />
          <StatCard
            icon={<Layers size={18} />}
            label="Genres"
            value={statsLoading ? '…' : (stats?.genres?.length ?? 0)}
            color="#4aa3df"
          />
          <StatCard
            icon={<Activity size={18} />}
            label="Total Records"
            value={statsLoading ? '…' : totalElements.toLocaleString()}
            color="#a07cf7"
          />
        </div>

        {/* Books table */}
        <div style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
        }}>
          {/* Table toolbar */}
          <div style={{
            padding: '1rem 1.25rem',
            borderBottom: '1px solid var(--ink-border)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            flexWrap: 'wrap', gap: '0.75rem',
            background: 'var(--surface-2)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600 }}>
                Books
              </h2>
              {/* Status filter tabs */}
              <div style={{ display: 'flex', gap: '0.25rem' }}>
                {['ALL', 'ACTIVE', 'ARCHIVED'].map(s => (
                  <button
                    key={s}
                    onClick={() => setStatusFilter(s)}
                    style={{
                      padding: '0.3rem 0.75rem',
                      borderRadius: 100,
                      border: '1px solid ' + (statusFilter === s ? 'var(--gold-dim)' : 'var(--ink-border)'),
                      background: statusFilter === s ? 'var(--gold-glow)' : 'transparent',
                      color: statusFilter === s ? 'var(--gold)' : 'var(--text-muted)',
                      fontSize: '0.78rem', fontWeight: 500, cursor: 'pointer',
                      transition: 'all 0.15s',
                    }}
                  >{s}</button>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              {/* Search */}
              <div style={{ position: 'relative' }}>
                <Search size={13} style={{ position: 'absolute', left: '0.65rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', pointerEvents: 'none' }} />
                <input
                  className="input"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Filter by title / author…"
                  style={{ paddingLeft: '2rem', fontSize: '0.8rem', height: 34, width: 220 }}
                />
              </div>
              <button className="btn btn-ghost" onClick={loadBooks} style={{ padding: '0.4rem' }} title="Refresh">
                <RefreshCw size={14} />
              </button>
            </div>
          </div>

          {/* Table */}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--ink-soft)' }}>
                  {['#', 'Title', 'Author', 'Genre', 'Language', 'Size', 'Views', 'Status', 'Added', 'Actions'].map(h => (
                    <th key={h} style={{
                      padding: '0.65rem 1rem',
                      textAlign: 'left',
                      fontSize: '0.7rem',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      fontWeight: 600,
                      borderBottom: '1px solid var(--ink-border)',
                      whiteSpace: 'nowrap',
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <tr key={i}>
                      {Array.from({ length: 10 }).map((_, j) => (
                        <td key={j} style={{ padding: '0.75rem 1rem', borderBottom: '1px solid var(--ink-border)' }}>
                          <div style={{ height: 12, background: 'var(--ink-light)', borderRadius: 4, opacity: 0.6, width: j === 1 ? '80%' : j === 2 ? '60%' : '40%' }} />
                        </td>
                      ))}
                    </tr>
                  ))
                ) : filteredBooks.length === 0 ? (
                  <tr>
                    <td colSpan={10} style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      No books found.
                    </td>
                  </tr>
                ) : (
                  filteredBooks.map((book, idx) => {
                    const sc = STATUS_COLORS[book.status] || STATUS_COLORS.ACTIVE;
                    return (
                      <tr key={book.id} style={{
                        borderBottom: '1px solid var(--ink-border)',
                        transition: 'background 0.15s',
                      }}
                        onMouseEnter={e => e.currentTarget.style.background = 'var(--ink-soft)'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                          {page * 15 + idx + 1}
                        </td>
                        <td style={{ padding: '0.75rem 1rem', maxWidth: 220 }}>
                          <Link to={`/book/${book.id}`} style={{
                            color: 'var(--text-primary)', fontWeight: 500,
                            fontSize: '0.85rem',
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                          }}>
                            {book.title}
                          </Link>
                        </td>
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>
                          {book.author}
                        </td>
                        <td style={{ padding: '0.75rem 1rem' }}>
                          {book.genre
                            ? <span className="badge" style={{ fontSize: '0.7rem' }}>{book.genre}</span>
                            : <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>—</span>
                          }
                        </td>
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)', fontSize: '0.78rem', whiteSpace: 'nowrap' }}>
                          {book.language || '—'}
                        </td>
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)', fontSize: '0.78rem', whiteSpace: 'nowrap' }}>
                          {book.fileSizeFormatted}
                        </td>
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
                          <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                            <Eye size={11} /> {book.viewCount?.toLocaleString() ?? 0}
                          </span>
                        </td>
                        <td style={{ padding: '0.75rem 1rem' }}>
                          <span style={{
                            padding: '0.2rem 0.6rem',
                            borderRadius: 100,
                            fontSize: '0.7rem',
                            fontWeight: 600,
                            letterSpacing: '0.04em',
                            background: sc.bg,
                            color: sc.text,
                            border: `1px solid ${sc.border}`,
                          }}>
                            {book.status}
                          </span>
                        </td>
                        <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)', fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                          {book.createdAt
                            ? new Date(book.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
                            : '—'
                          }
                        </td>
                        <td style={{ padding: '0.75rem 1rem' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                            {/* Edit */}
                            <ActionBtn
                              icon={<Edit2 size={12} />}
                              title="Edit metadata"
                              color="var(--gold)"
                              onClick={() => setEditBook(book)}
                            />
                            {/* Archive / Restore */}
                            {book.status === 'ACTIVE' ? (
                              <ActionBtn
                                icon={<Archive size={12} />}
                                title="Archive"
                                color="var(--text-muted)"
                                onClick={() => handleArchive(book.id, book.title)}
                              />
                            ) : (
                              <ActionBtn
                                icon={<RotateCcw size={12} />}
                                title="Restore"
                                color="#4caf84"
                                onClick={() => handleRestore(book.id, book.title)}
                              />
                            )}
                            {/* Hard delete */}
                            {confirmHardDelete === book.id ? (
                              <div style={{ display: 'flex', gap: '0.25rem' }}>
                                <button
                                  onClick={() => handleHardDelete(book)}
                                  style={{
                                    padding: '0.2rem 0.5rem', borderRadius: 'var(--radius)',
                                    background: 'rgba(224,92,92,0.15)', border: '1px solid rgba(224,92,92,0.4)',
                                    color: 'var(--error)', fontSize: '0.7rem', cursor: 'pointer',
                                  }}
                                >Confirm</button>
                                <button
                                  onClick={() => setConfirmHardDelete(null)}
                                  style={{
                                    padding: '0.2rem 0.5rem', borderRadius: 'var(--radius)',
                                    background: 'transparent', border: '1px solid var(--ink-border)',
                                    color: 'var(--text-muted)', fontSize: '0.7rem', cursor: 'pointer',
                                  }}
                                >Cancel</button>
                              </div>
                            ) : (
                              <ActionBtn
                                icon={<Trash2 size={12} />}
                                title="Permanently delete"
                                color="var(--error)"
                                onClick={() => setConfirmHardDelete(book.id)}
                              />
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{
              padding: '0.875rem 1.25rem',
              borderTop: '1px solid var(--ink-border)',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              background: 'var(--surface)',
            }}>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Showing {page * 15 + 1}–{Math.min((page + 1) * 15, totalElements)} of {totalElements.toLocaleString()} records
              </span>
              <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                <button
                  className="btn btn-ghost"
                  onClick={() => setPage(p => p - 1)}
                  disabled={page === 0}
                  style={{ padding: '0.35rem 0.6rem', opacity: page === 0 ? 0.3 : 1 }}
                >
                  <ChevronLeft size={15} />
                </button>
                <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', padding: '0 0.5rem' }}>
                  {page + 1} / {totalPages}
                </span>
                <button
                  className="btn btn-ghost"
                  onClick={() => setPage(p => p + 1)}
                  disabled={page >= totalPages - 1}
                  style={{ padding: '0.35rem 0.6rem', opacity: page >= totalPages - 1 ? 0.3 : 1 }}
                >
                  <ChevronRight size={15} />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Quick info */}
        <div style={{
          marginTop: '1.5rem',
          padding: '1rem 1.25rem',
          background: 'var(--surface-2)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-lg)',
          display: 'flex', alignItems: 'center', gap: '0.6rem',
        }}>
          <AlertTriangle size={14} style={{ color: 'var(--warning)', flexShrink: 0 }} />
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
            <strong style={{ color: 'var(--text-secondary)' }}>Archive</strong> soft-deletes (recoverable).
            {' '}<strong style={{ color: 'var(--error)' }}>Permanently Delete</strong> removes the DB record AND the PDF file from disk — this cannot be undone.
          </p>
        </div>
      </div>

      {/* Edit modal */}
      {editBook && (
        <EditBookModal
          book={editBook}
          onClose={() => setEditBook(null)}
          onSuccess={() => { setEditBook(null); loadBooks(); loadStats(); }}
        />
      )}

      {/* Hard delete confirm overlay */}
      {confirmHardDelete && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 500,
          background: 'rgba(0,0,0,0.4)',
        }} onClick={() => setConfirmHardDelete(null)} />
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div style={{
      padding: '1.25rem',
      background: 'var(--card-bg)',
      border: '1px solid var(--ink-border)',
      borderRadius: 'var(--radius-lg)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <span style={{ color, opacity: 0.8 }}>{icon}</span>
        <span style={{ fontSize: '0.68rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
          {label}
        </span>
      </div>
      <p style={{
        fontFamily: 'var(--font-display)',
        fontSize: '1.75rem',
        fontWeight: 600,
        color: 'var(--text-primary)',
        lineHeight: 1,
      }}>
        {value}
      </p>
    </div>
  );
}

function ActionBtn({ icon, title, color, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onClick}
      title={title}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: 28, height: 28,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 'var(--radius)',
        border: 'none',
        background: hov ? `${color}18` : 'transparent',
        color: hov ? color : 'var(--text-muted)',
        cursor: 'pointer',
        transition: 'all 0.15s',
      }}
    >
      {icon}
    </button>
  );
}
