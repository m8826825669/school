import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, ArrowLeft, ChevronLeft, ChevronRight, BookOpen } from 'lucide-react';
import BookCard from '../components/BookCard.jsx';
import { bookApi } from '../api/bookApi.js';

const PAGE_SIZE = 12;

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const q = searchParams.get('q') || '';

  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);

  useEffect(() => {
    setPage(0);
  }, [q]);

  useEffect(() => {
    if (!q) return;
    setLoading(true);
    bookApi.search(q, page, PAGE_SIZE)
      .then(result => {
        setBooks(result.books);
        setTotalPages(result.totalPages);
        setTotalElements(result.totalElements);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [q, page]);

  return (
    <div style={{ paddingTop: 'var(--navbar-h)', minHeight: '100vh', animation: 'fadeIn 0.35s var(--ease)' }}>

      {/* Header */}
      <div style={{
        background: 'var(--ink-soft)',
        borderBottom: '1px solid var(--ink-border)',
        padding: '2rem 2rem',
      }}>
        <div className="container" style={{ maxWidth: 1200 }}>
          <Link to="/" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            color: 'var(--text-muted)', fontSize: '0.82rem',
            marginBottom: '1rem',
          }}>
            <ArrowLeft size={13} />
            Back to Library
          </Link>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <Search size={20} style={{ color: 'var(--gold)' }} />
            <div>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 600 }}>
                "{q}"
              </h1>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '0.2rem' }}>
                {loading ? 'Searching...' : `${totalElements.toLocaleString()} result${totalElements !== 1 ? 's' : ''} found`}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container" style={{ maxWidth: 1200, padding: '2.5rem 2rem' }}>
        {loading ? (
          <LoadingSkeleton />
        ) : books.length === 0 ? (
          <NoResults query={q} />
        ) : (
          <>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: '1.25rem',
            }}>
              {books.map(book => <BookCard key={book.id} book={book} />)}
            </div>

            {totalPages > 1 && (
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                gap: '0.5rem', marginTop: '3rem',
              }}>
                <button
                  className="btn btn-ghost"
                  onClick={() => setPage(p => p - 1)}
                  disabled={page === 0}
                  style={{ opacity: page === 0 ? 0.3 : 1 }}
                >
                  <ChevronLeft size={16} /> Prev
                </button>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem', padding: '0 0.5rem' }}>
                  Page {page + 1} of {totalPages}
                </span>
                <button
                  className="btn btn-ghost"
                  onClick={() => setPage(p => p + 1)}
                  disabled={page >= totalPages - 1}
                  style={{ opacity: page >= totalPages - 1 ? 0.3 : 1 }}
                >
                  Next <ChevronRight size={16} />
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: '1.25rem',
    }}>
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--ink-border)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
          opacity: 0.6 + i * 0.04,
        }}>
          <div style={{ aspectRatio: '3/4', maxHeight: 240, background: 'var(--ink-mid)' }} />
          <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <div style={{ height: 14, background: 'var(--ink-light)', borderRadius: 4 }} />
            <div style={{ height: 11, background: 'var(--ink-light)', borderRadius: 4, width: '60%' }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function NoResults({ query }) {
  return (
    <div style={{
      textAlign: 'center', padding: '5rem 2rem',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem',
    }}>
      <div style={{
        width: 72, height: 72,
        borderRadius: '50%',
        background: 'var(--ink-mid)',
        border: '1px solid var(--ink-border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Search size={28} style={{ color: 'var(--text-muted)' }} />
      </div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.6rem' }}>
        No results for "{query}"
      </h2>
      <p style={{ color: 'var(--text-muted)', maxWidth: 360, lineHeight: 1.7 }}>
        Try searching with different keywords — by title, author name, genre, or ISBN.
      </p>
      <Link to="/" className="btn btn-outline" style={{ marginTop: '0.5rem' }}>
        <BookOpen size={14} />
        Browse All Books
      </Link>
    </div>
  );
}
