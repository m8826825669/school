import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
});

// Books API
export const bookApi = {
  // Get all books (paginated)
  getAll: (page = 0, size = 12) =>
    api.get(`/books?page=${page}&size=${size}`).then(r => r.data),

  // Search
  search: (q, page = 0, size = 12) =>
    api.get(`/books/search?q=${encodeURIComponent(q)}&page=${page}&size=${size}`).then(r => r.data),

  // Get by genre
  getByGenre: (genre, page = 0, size = 12) =>
    api.get(`/books/genre/${encodeURIComponent(genre)}?page=${page}&size=${size}`).then(r => r.data),

  // Get single book
  getById: (id) =>
    api.get(`/books/${id}`).then(r => r.data),

  // Stats
  getStats: () =>
    api.get('/books/stats').then(r => r.data),

  // Genres list
  getGenres: () =>
    api.get('/books/genres').then(r => r.data),

  // Top viewed
  getTopViewed: (limit = 6) =>
    api.get(`/books/top-viewed?limit=${limit}`).then(r => r.data),

  // Recently added (alias: getRecentlyAdded)
  getRecent: (limit = 6) =>
    api.get(`/books/recent?limit=${limit}`).then(r => r.data),

  getRecentlyAdded: (limit = 6) =>
    api.get(`/books/recent?limit=${limit}`).then(r => r.data),

  // Upload book (admin)
  upload: (metadata, pdfFile, coverFile) => {
    const formData = new FormData();
    formData.append('pdfFile', pdfFile);
    if (coverFile) formData.append('coverFile', coverFile);
    formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    return api.post('/books/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (e.onUploadProgress) e.onUploadProgress(e);
      }
    }).then(r => r.data);
  },

  // PDF URL (for inline iframe viewing)
  getPdfUrl: (id) => `/api/books/${id}/read`,

  // Cover image URL
  getCoverUrl: (id) => `/api/books/${id}/cover`,

  // Delete (archive — soft)
  delete: (id) => api.delete(`/books/${id}`).then(r => r.data),

  // Restore archived book
  restore: (id) => api.patch(`/books/${id}/restore`).then(r => r.data),

  // Lightweight PDF existence check — no streaming, no side effects
  checkPdfStatus: (id) =>
    api.get(`/books/${id}/pdf-status`).then(r => r.data).catch(() => ({ available: false })),

  // Hard delete (removes file from disk)
  hardDelete: (id) => api.delete(`/books/${id}/hard`).then(r => r.data),

  // Update book metadata (and optionally replace PDF/cover)
  update: (id, metadata, pdfFile, coverFile) => {
    const formData = new FormData();
    if (pdfFile) formData.append('pdfFile', pdfFile);
    if (coverFile) formData.append('coverFile', coverFile);
    formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    return api.put(`/books/${id}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  // Admin: list all books (including archived)
  adminGetAll: (status = 'ALL', page = 0, size = 20) =>
    api.get(`/books/admin/all?status=${status}&page=${page}&size=${size}`).then(r => r.data),
};

// Health check — quick way to verify backend is alive
export const healthCheck = () =>
  api.get('/health').then(r => r.data).catch(err => ({
    status: 'DOWN',
    error: err?.code === 'ERR_NETWORK'
      ? 'Backend not reachable on port 8080'
      : `HTTP ${err?.response?.status}: ${err?.response?.data?.detail || err.message}`,
  }));

export default api;
