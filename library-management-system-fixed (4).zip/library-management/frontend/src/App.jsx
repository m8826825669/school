import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar.jsx';

// Lazy-load all pages — prevents a broken page from crashing the whole app
const HomePage       = lazy(() => import('./pages/HomePage.jsx'));
const BookDetailPage = lazy(() => import('./pages/BookDetailPage.jsx'));
const SearchPage     = lazy(() => import('./pages/SearchPage.jsx'));
const TrendingPage   = lazy(() => import('./pages/TrendingPage.jsx'));
const UploadPage     = lazy(() => import('./pages/UploadPage.jsx'));
const AdminPage      = lazy(() => import('./pages/AdminPage.jsx'));

function PageLoader() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      height: 'calc(100vh - var(--navbar-h))',
      marginTop: 'var(--navbar-h)',
    }}>
      <div className="spinner" />
    </div>
  );
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error('App error:', error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          paddingTop: 'var(--navbar-h)',
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          minHeight: '80vh', gap: '1rem', textAlign: 'center', padding: '2rem',
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            background: 'rgba(224,92,92,0.1)',
            border: '1px solid rgba(224,92,92,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.5rem',
          }}>⚠️</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Something went wrong</h2>
          <p style={{ color: 'var(--text-muted)', maxWidth: 400 }}>
            {this.state.error?.message || 'An unexpected error occurred.'}
          </p>
          <button className="btn btn-outline"
            onClick={() => { this.setState({ hasError: false, error: null }); window.location.href = '/'; }}>
            Go to Home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <Navbar />
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/"         element={<HomePage />} />
          <Route path="/book/:id" element={<BookDetailPage />} />
          <Route path="/search"   element={<SearchPage />} />
          <Route path="/trending" element={<TrendingPage />} />
          <Route path="/upload"   element={<UploadPage />} />
          <Route path="/admin"      element={<AdminPage />} />
          <Route path="*"         element={<NotFound />} />
        </Routes>
      </Suspense>
      <Footer />
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'var(--surface-2)',
            color: 'var(--text-primary)',
            border: '1px solid var(--ink-border)',
            fontFamily: 'var(--font-body)',
            fontSize: '0.875rem',
          },
          success: { iconTheme: { primary: 'var(--gold)', secondary: 'var(--ink)' } },
          error:   { iconTheme: { primary: 'var(--error)', secondary: 'var(--ink)' } },
        }}
      />
    </ErrorBoundary>
  );
}

function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid var(--ink-border)',
      background: 'var(--ink-soft)',
      padding: '2rem',
      marginTop: '4rem',
    }}>
      <div className="container" style={{
        maxWidth: 1200,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: '1rem',
      }}>
        <div>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', color: 'var(--gold)', marginBottom: '0.25rem' }}>
            Bibliothèque
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
            Digital library — read-only, secure, open to all.
          </p>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>
          Built with Spring Boot · PostgreSQL · React · PDF.js
        </p>
      </div>
    </footer>
  );
}

function NotFound() {
  return (
    <div style={{
      paddingTop: 'var(--navbar-h)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      minHeight: '80vh', gap: '1rem', textAlign: 'center',
    }}>
      <p style={{ fontFamily: 'var(--font-display)', fontSize: '5rem', color: 'var(--gold)', lineHeight: 1 }}>404</p>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Page Not Found</h2>
      <p style={{ color: 'var(--text-muted)' }}>The page you're looking for doesn't exist.</p>
      <a href="/" className="btn btn-outline" style={{ marginTop: '0.5rem' }}>Go to Library</a>
    </div>
  );
}
