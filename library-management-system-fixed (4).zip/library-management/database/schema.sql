-- ============================================================
-- Bibliothèque — Library Management System
-- PostgreSQL Schema
-- ============================================================

-- Create database (run as superuser)
CREATE DATABASE library_db
  ENCODING = 'UTF8'
  LC_COLLATE = 'en_US.UTF-8'
  LC_CTYPE = 'en_US.UTF-8'
  TEMPLATE = template0;

\c library_db;

-- ============================================================
-- Core tables (Hibernate auto-creates these, but here for ref)
-- ============================================================

CREATE TABLE IF NOT EXISTS books (
    id                BIGSERIAL PRIMARY KEY,
    title             VARCHAR(500)  NOT NULL,
    author            VARCHAR(300)  NOT NULL,
    isbn              VARCHAR(20)   UNIQUE,
    genre             VARCHAR(100),
    publisher         VARCHAR(100),
    published_year    INTEGER,
    page_count        INTEGER,
    description       TEXT,
    language          VARCHAR(50)   DEFAULT 'English',
    pdf_file_path     VARCHAR(500)  NOT NULL,
    cover_image_path  VARCHAR(500),
    file_size_bytes   BIGINT,
    status            VARCHAR(20)   NOT NULL DEFAULT 'ACTIVE',
    view_count        BIGINT        DEFAULT 0,
    uploaded_by       VARCHAR(100)  DEFAULT 'admin',
    created_at        TIMESTAMP     NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP     NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS book_tags (
    book_id  BIGINT REFERENCES books(id) ON DELETE CASCADE,
    tag      VARCHAR(50),
    PRIMARY KEY (book_id, tag)
);

-- Indexes for fast search
CREATE INDEX IF NOT EXISTS idx_books_title       ON books USING gin(to_tsvector('english', title));
CREATE INDEX IF NOT EXISTS idx_books_author      ON books(author);
CREATE INDEX IF NOT EXISTS idx_books_genre       ON books(genre);
CREATE INDEX IF NOT EXISTS idx_books_status      ON books(status);
CREATE INDEX IF NOT EXISTS idx_books_view_count  ON books(view_count DESC);
CREATE INDEX IF NOT EXISTS idx_books_created_at  ON books(created_at DESC);

-- ============================================================
-- Trigger to auto-update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_books_updated_at ON books;
CREATE TRIGGER trg_books_updated_at
  BEFORE UPDATE ON books
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- Seed data — DO NOT RUN unless you have real PDF files
-- ============================================================
-- The INSERT below is commented out to prevent "PDF not found" errors.
-- Upload real books via the UI or API instead.
-- To clean up any stale placeholder records from a previous run:
--
--   DELETE FROM books WHERE pdf_file_path LIKE 'placeholder_%';
--
-- If you do want sample data, replace pdf_file_path values
-- with actual filenames from your library-storage/books/ directory.
-- ============================================================

-- EXAMPLE (uncomment and edit after you have real PDFs):
-- INSERT INTO books (title, author, isbn, genre, language, pdf_file_path, file_size_bytes, status)
-- VALUES ('My Book', 'Author Name', NULL, 'Technology', 'English', 'actual-uuid-filename.pdf', 1048576, 'ACTIVE');

-- ============================================================
-- Useful queries
-- ============================================================

-- Full-text search
-- SELECT * FROM books WHERE to_tsvector('english', title || ' ' || COALESCE(author,'') || ' ' || COALESCE(description,'')) @@ plainto_tsquery('clean code');

-- Top viewed
-- SELECT id, title, view_count FROM books ORDER BY view_count DESC LIMIT 10;

-- Storage usage
-- SELECT pg_size_pretty(SUM(file_size_bytes)::bigint) AS total_storage FROM books WHERE status = 'ACTIVE';

-- Genre distribution
-- SELECT genre, COUNT(*) FROM books WHERE status = 'ACTIVE' GROUP BY genre ORDER BY count DESC;
