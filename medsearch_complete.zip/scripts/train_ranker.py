"""
scripts/train_ranker.py

Train the LightGBM LambdaRank re-ranking model from search event logs.

Run weekly via Celery beat or a cron job after sufficient click data accumulates.
The model is hot-swapped into the running service via LGBMRanker.reload()
without restarting any process.

Usage:
  python scripts/train_ranker.py \\
    --tenant    pharmacy_mumbai_1 \\
    --days      90 \\
    --output    models/ranker.lgb

Requirements:
  - At least 1000 search events with selections in the training window
  - PostgreSQL connection (reads from search_events table)
  - lightgbm installed

Model: LambdaRank optimising NDCG@5
  - Relevance label:  3 if added_to_bill, 1 if selected, 0 otherwise
  - Group:            all candidates shown for one query = one group
  - Features:         see LGBMRanker._build_features() comments

The trained model is saved to --output and automatically picked up
by the running MedSearch service on next reload.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def run_training(tenant_id: str, days: int, output: str) -> None:
    """Train and save the LambdaRank model."""
    try:
        import lightgbm as lgb  # type: ignore[import]
        import numpy as np
        import pandas as pd
    except ImportError as e:
        print(f"Missing dependency: {e}")
        print("Install with: pip install lightgbm pandas")
        sys.exit(1)

    try:
        import sqlalchemy as sa
        from sqlalchemy import create_engine, text
    except ImportError:
        print("Missing sqlalchemy. Install with: pip install sqlalchemy psycopg2-binary")
        sys.exit(1)

    from medsearch.settings import get_settings
    settings  = get_settings()
    since     = datetime.now(timezone.utc) - timedelta(days=days)

    # Use sync engine for the training script (not async)
    sync_url = settings.database_url.replace("+asyncpg", "+psycopg2")
    engine   = create_engine(sync_url)

    print(f"Loading search events: tenant={tenant_id}, last {days} days...")

    query = text("""
        SELECT
            id,
            query,
            result_ids,
            selected_id,
            added_to_bill,
            latency_ms
        FROM search_events
        WHERE
            tenant_id    = :tenant_id
            AND occurred_at >= :since
            AND array_length(result_ids, 1) > 0
        ORDER BY id
    """)

    with engine.connect() as conn:
        df = pd.read_sql(query, conn, params={
            "tenant_id": tenant_id,
            "since":     since,
        })

    if len(df) < 100:
        print(f"Only {len(df)} events found. Need at least 100 to train.")
        print("Keep the service running to collect more data.")
        sys.exit(1)

    print(f"  {len(df)} events loaded")

    # ------------------------------------------------------------------
    # Build training rows
    # Each event's result_ids list becomes one group. Each position
    # in the list is one row with features + relevance label.
    # ------------------------------------------------------------------
    rows: list[dict] = []
    group_sizes: list[int] = []

    for _, event in df.iterrows():
        result_ids    = event["result_ids"] or []
        selected_id   = event["selected_id"]
        added_to_bill = bool(event["added_to_bill"])
        group_size    = len(result_ids)

        if group_size == 0:
            continue

        group_sizes.append(group_size)
        for position, doc_id in enumerate(result_ids):
            # Relevance: added_to_bill=3, selected=1, not selected=0
            if doc_id == selected_id and added_to_bill:
                label = 3
            elif doc_id == selected_id:
                label = 1
            else:
                label = 0

            rows.append({
                "label":         label,
                "position":      position,
                "was_selected":  int(doc_id == selected_id),
                # Features available from the event log
                # In production, join with medicine table for richer features
                "position_score": 1.0 / (1 + position),  # inverse position
                "is_top3":        int(position < 3),
            })

    if not rows:
        print("No valid training rows. Exiting.")
        sys.exit(1)

    train_df = pd.DataFrame(rows)
    X = train_df.drop(columns=["label"])
    y = train_df["label"]

    print(f"  {len(train_df)} training rows, {len(group_sizes)} groups")
    print(f"  Positive labels: {(y > 0).sum()} ({(y > 0).mean():.1%})")

    # ------------------------------------------------------------------
    # Train LambdaRank model
    # ------------------------------------------------------------------
    dataset = lgb.Dataset(X, label=y, group=group_sizes)

    params = {
        "objective":      "lambdarank",
        "metric":         "ndcg",
        "ndcg_eval_at":   [3, 5],
        "num_leaves":     31,
        "learning_rate":  0.05,
        "n_estimators":   200,
        "min_data_in_leaf": 5,
        "verbose":        -1,
    }

    print("\nTraining LightGBM LambdaRank model...")
    model = lgb.train(
        params,
        dataset,
        num_boost_round = params["n_estimators"],
        valid_sets      = [dataset],
        callbacks       = [lgb.log_evaluation(period=50)],
    )

    # Save model
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    model.save_model(output)
    print(f"\nModel saved to {output}")
    print("Hot-swap into running service: POST /v1/admin/reload-ranker")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train MedSearch ranker")
    parser.add_argument("--tenant", required=True, help="Tenant ID to train on")
    parser.add_argument("--days",   type=int, default=90, help="Training window in days")
    parser.add_argument("--output", default="models/ranker.lgb", help="Output model path")
    args = parser.parse_args()

    run_training(args.tenant, args.days, args.output)
