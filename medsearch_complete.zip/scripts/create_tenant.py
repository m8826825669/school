"""
scripts/create_tenant.py

Provision a new tenant and generate its first API key.

Run this when onboarding a new pharmacy/clinic/app onto MedSearch.

Usage:
  python scripts/create_tenant.py \\
    --tenant-id   pharmacy_delhi_2 \\
    --name        "Delhi Pharmacy Branch 2" \\
    --indexes     medicines

Output:
  Tenant created: pharmacy_delhi_2
  API Key: ms_live_xxxxxxxxxxxxxxxxxxxxxxxx
  ⚠  Store this key now — it will not be shown again.

Then call build_index.py to seed the catalog, and give the API key
to the pharmacy application to include in X-API-Key headers.
"""

from __future__ import annotations

import argparse
import asyncio
import secrets
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


async def create_tenant(
    tenant_id:   str,
    name:        str,
    indexes:     list[str],
) -> None:
    from passlib.context import CryptContext

    from medsearch.core.domain.tenant import ApiKey, Tenant
    from medsearch.infra.cache.redis_store import RedisStore
    from medsearch.infra.db.engine import init_engine, get_session
    from medsearch.infra.db.repositories.tenant_repo import TenantRepository
    from medsearch.settings import get_settings

    settings   = get_settings()
    pwd_ctx    = CryptContext(schemes=["bcrypt"], deprecated="auto")
    raw_key    = f"ms_live_{secrets.token_urlsafe(32)}"
    hashed_key = pwd_ctx.hash(raw_key)

    tenant = Tenant(
        tenant_id       = tenant_id,
        display_name    = name,
        allowed_indexes = frozenset(indexes),
        is_active       = True,
    )
    api_key = ApiKey(
        key_id     = str(uuid.uuid4()),
        tenant_id  = tenant_id,
        hashed_key = hashed_key,
        is_active  = True,
        rate_limit = 300,
    )

    engine = init_engine(settings)
    from redis.asyncio import Redis
    redis  = Redis.from_url(settings.redis_url)
    cache  = RedisStore(redis)

    async with get_session() as session:
        repo = TenantRepository(session, cache)
        await repo.create_tenant(tenant)
        await repo.create_api_key(api_key)

    await engine.dispose()
    await redis.aclose()

    print(f"\nTenant created: {tenant_id}")
    print(f"Display name:   {name}")
    print(f"Allowed indexes: {', '.join(indexes)}\n")
    print(f"API Key: {raw_key}")
    print("\n⚠  Store this key now — it will not be shown again.")
    print("   Pass it as X-API-Key header in all MedSearch requests.\n")
    print("Next steps:")
    print(f"  python scripts/build_index.py --tenant {tenant_id} --source data/medicines.json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Create a MedSearch tenant")
    parser.add_argument("--tenant-id", required=True, help="Slug identifier (e.g. pharmacy_delhi_2)")
    parser.add_argument("--name",      required=True, help="Human-readable display name")
    parser.add_argument("--indexes",   nargs="+", default=["medicines"],
                        help="Allowed index names")
    args = parser.parse_args()

    asyncio.run(create_tenant(args.tenant_id, args.name, args.indexes))
