"""
scripts/build_index.py

Bulk-seeds the search indexes from a medicine data source.

Run this:
  - On first deployment (empty indexes)
  - After a large catalog import
  - When switching to a new tenant

Usage:
  python scripts/build_index.py \\
    --tenant pharmacy_mumbai_1 \\
    --index  medicines \\
    --source data/medicines.json    # or .csv

Input format (JSON array):
  [
    {
      "id":               "med_123",
      "name":             "Calpol 500mg",
      "generic_name":     "Paracetamol",
      "salt_composition": "Paracetamol 500mg",
      "indications":      "fever pain headache",
      "price":            45.0,
      "stock_qty":        100,
      "sales_30d":        250,
      "margin_pct":       18.5,
      "category":         "analgesic"
    },
    ...
  ]

The script:
  1. Creates Typesense collection if missing
  2. Creates Qdrant collection if missing
  3. Batch-upserts into Typesense  (500 docs/batch)
  4. Batch-embeds + upserts into Qdrant (64 docs/batch — GPU/CPU limited)
  5. Rebuilds Redis trie for autocomplete
  6. Saves SpellCorrector dictionary to models/symspell.pkl

Progress is shown with tqdm. Resumable — reruns are idempotent.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

# Add src to path so we can import medsearch without installing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import structlog

from medsearch.infra.cache.redis_trie import RedisTrie
from medsearch.infra.ml.embedder import SentenceEmbedder
from medsearch.infra.nlp.spell_corrector import SpellCorrector
from medsearch.infra.search.qdrant_engine import QdrantEngine
from medsearch.infra.search.typesense_engine import TypesenseEngine
from medsearch.settings import get_settings

log = structlog.get_logger(__name__)

TYPESENSE_BATCH = 500   # Typesense handles large batches well
QDRANT_BATCH    = 64    # Qdrant/embedding batch — CPU-limited


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def load_json(path: str) -> list[dict[str, Any]]:
    with open(path) as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    # Support {"medicines": [...]} envelope
    for key in ("medicines", "data", "items", "results"):
        if key in data:
            return data[key]
    raise ValueError(f"Cannot find a list in {path}. Expected JSON array or object with list.")


def load_csv(path: str) -> list[dict[str, Any]]:
    with open(path, newline="", encoding="utf-8") as f:
        return [row for row in csv.DictReader(f)]


def load_source(path: str) -> list[dict[str, Any]]:
    ext = Path(path).suffix.lower()
    if ext == ".json":
        return load_json(path)
    if ext == ".csv":
        return load_csv(path)
    raise ValueError(f"Unsupported format: {ext}. Use .json or .csv")


# ---------------------------------------------------------------------------
# Progress printer (no tqdm dependency required)
# ---------------------------------------------------------------------------

def progress(current: int, total: int, label: str = "") -> None:
    pct  = int(current / total * 100) if total else 0
    bar  = "#" * (pct // 5) + "." * (20 - pct // 5)
    print(f"\r  [{bar}] {pct:3d}%  {current}/{total}  {label}", end="", flush=True)
    if current >= total:
        print()


# ---------------------------------------------------------------------------
# Index builders
# ---------------------------------------------------------------------------

async def seed_typesense(
    engine:    TypesenseEngine,
    tenant_id: str,
    index:     str,
    docs:      list[dict[str, Any]],
) -> None:
    log.info("typesense.seeding", tenant_id=tenant_id, index=index, count=len(docs))
    await engine.create_index(tenant_id, index, {})

    for i in range(0, len(docs), TYPESENSE_BATCH):
        batch = docs[i : i + TYPESENSE_BATCH]
        for doc in batch:
            await engine.upsert(tenant_id, index, str(doc["id"]), doc)
        progress(min(i + TYPESENSE_BATCH, len(docs)), len(docs), "Typesense")

    log.info("typesense.seeded", count=len(docs))


async def seed_qdrant(
    engine:    QdrantEngine,
    embedder:  SentenceEmbedder,
    tenant_id: str,
    index:     str,
    docs:      list[dict[str, Any]],
) -> None:
    log.info("qdrant.seeding", tenant_id=tenant_id, index=index, count=len(docs))
    await engine.create_index(tenant_id, index, {})

    for i in range(0, len(docs), QDRANT_BATCH):
        batch = docs[i : i + QDRANT_BATCH]
        for doc in batch:
            await engine.upsert(tenant_id, index, str(doc["id"]), doc)
        progress(min(i + QDRANT_BATCH, len(docs)), len(docs), "Qdrant")

    log.info("qdrant.seeded", count=len(docs))


async def seed_trie(
    trie:      RedisTrie,
    tenant_id: str,
    index:     str,
    docs:      list[dict[str, Any]],
) -> None:
    log.info("trie.rebuilding", tenant_id=tenant_id, index=index)
    entries = [(doc["name"], str(doc["id"])) for doc in docs if doc.get("name")]
    await trie.rebuild(tenant_id, index, entries)
    log.info("trie.rebuilt", entries=len(entries))


def build_spellcheck(docs: list[dict[str, Any]]) -> None:
    log.info("spellcheck.building")
    wordlist: list[str] = []
    for doc in docs:
        for field in ("name", "generic_name", "salt_composition"):
            val = doc.get(field, "")
            if val:
                wordlist.append(str(val))

    corrector = SpellCorrector.load_or_build(wordlist)
    log.info("spellcheck.built", terms=len(wordlist))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main(tenant_id: str, index: str, source: str) -> None:
    t0       = time.monotonic()
    settings = get_settings()

    print(f"\nMedSearch — Index Builder")
    print(f"  tenant: {tenant_id}")
    print(f"  index:  {index}")
    print(f"  source: {source}\n")

    # Load data
    print("Loading data...")
    docs = load_source(source)
    print(f"  {len(docs)} documents loaded\n")

    # Initialise adapters
    from redis.asyncio import Redis
    redis    = Redis.from_url(settings.redis_url)
    trie     = RedisTrie(redis)
    embedder = SentenceEmbedder(settings.embedding_model, settings.embedding_batch_size).load()
    ts_engine = TypesenseEngine(settings)
    qd_engine  = QdrantEngine(settings, embedder)

    # Seed each index
    print("Seeding Typesense...")
    await seed_typesense(ts_engine, tenant_id, index, docs)

    print("Seeding Qdrant (includes embedding — this takes a while)...")
    await seed_qdrant(qd_engine, embedder, tenant_id, index, docs)

    print("Building Redis autocomplete trie...")
    await seed_trie(trie, tenant_id, index, docs)

    print("Building spell-correction dictionary...")
    build_spellcheck(docs)

    await redis.aclose()
    elapsed = int(time.monotonic() - t0)
    print(f"\nDone in {elapsed}s — {len(docs)} documents indexed.\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed MedSearch indexes")
    parser.add_argument("--tenant", required=True, help="Tenant ID")
    parser.add_argument("--index",  default="medicines", help="Index name")
    parser.add_argument("--source", required=True, help="Path to .json or .csv")
    args = parser.parse_args()

    asyncio.run(main(args.tenant, args.index, args.source))
