# MedSearch

Standalone medicine search microservice — multi-tenant, ML-powered, sub-10ms.

Built to serve any application (pharmacy, clinic, HRMS) through a single REST API.  
No framework lock-in. No fat files. Clean architecture.

---

## Architecture

```
api/          ← thin HTTP shell (FastAPI endpoints, schemas, middleware)
services/     ← orchestration pipeline (search, index, suggest, analytics)
core/         ← pure domain (value objects, port interfaces) — no I/O
infra/        ← adapters (Typesense, Qdrant, Redis, Postgres, ML models)
```

Dependency rule: `api → services → core ports ← infra`.  
The core never imports from infra. Swap any engine without touching services.

---

## Tech stack

| Layer         | Technology                        |
|---------------|-----------------------------------|
| API           | FastAPI + Pydantic v2             |
| Lexical search| Typesense 26                      |
| Vector search | Qdrant + pgvector (HNSW index)    |
| Embeddings    | sentence-transformers/all-MiniLM  |
| ML ranker     | LightGBM LambdaRank               |
| Cache         | Redis Stack (sorted sets + JSON)  |
| Analytics DB  | PostgreSQL 16 + pgvector          |
| Migrations    | Alembic                           |

---

## Quick start

```bash
# 1. Clone and set up
git clone https://github.com/your-org/medsearch
cd medsearch
make install          # installs deps + pre-commit hooks + copies .env.example

# 2. Configure environment
nano .env             # fill in SECRET_KEY at minimum

# 3. Start infra + app
make dev              # starts Docker services + uvicorn with --reload

# 4. Open API docs
open http://localhost:8001/docs
```

---

## Development commands

```bash
make test             # run all tests
make test-unit        # fast unit tests only (no Docker needed)
make test-cov         # tests + HTML coverage report
make lint             # ruff + mypy
make format           # auto-format with ruff
make migrate          # run DB migrations
make migrate-new msg="add search events table"
make build            # build production Docker image
make clean            # remove all caches
```

---

## API overview

```
POST /v1/search       — ranked medicine search
GET  /v1/suggest      — autocomplete prefix suggestions
POST /v1/index        — add/update a document
DELETE /v1/index/{id} — remove a document
GET  /health          — liveness + dependency health
GET  /metrics         — Prometheus metrics
```

All endpoints require `X-API-Key` header.

---

## Project structure

```
medsearch/
├── src/medsearch/
│   ├── main.py              # app factory
│   ├── settings.py          # pydantic-settings config
│   ├── core/                # pure domain — zero I/O
│   │   ├── domain/          # value objects
│   │   └── ports/           # Protocol interfaces
│   ├── infra/               # adapters implementing ports
│   │   ├── search/          # Typesense + Qdrant engines
│   │   ├── cache/           # Redis store + autocomplete trie
│   │   ├── ml/              # embedder + LightGBM ranker
│   │   └── nlp/             # spell corrector + phonetic
│   ├── services/            # orchestration (no I/O directly)
│   └── api/v1/              # FastAPI routes + schemas
├── tests/
│   ├── unit/                # mock-based, no external deps
│   ├── integration/         # real containers via pytest-docker
│   └── e2e/                 # httpx against live FastAPI
├── alembic/                 # DB migrations
├── scripts/                 # build_index.py, train_ranker.py
├── docker/                  # Dockerfile + docker-compose.yml
└── models/                  # ML model binaries (not in Git)
```

---

## Calling MedSearch from your Django app

```python
# pharmacy_app/services/search_client.py
import httpx

async def search_medicines(query: str, branch_id: int) -> list[dict]:
    async with httpx.AsyncClient(timeout=3.0) as client:
        r = await client.post(
            "http://medsearch:8001/v1/search",
            json={
                "query":     query,
                "tenant_id": f"pharmacy_branch_{branch_id}",
                "index":     "medicines",
                "filters":   {"stock_qty": {"gt": 0}},
                "language":  "hi-IN",
            },
            headers={"X-API-Key": settings.SEARCH_SERVICE_KEY},
        )
        return r.json()["hits"]
```
