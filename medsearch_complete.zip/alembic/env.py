"""
alembic/env.py

Alembic migration environment — configured for async SQLAlchemy.

Supports two modes:
  - Online (default): connects to the live DB and runs migrations
  - Offline: generates SQL scripts without a DB connection

The DB URL is pulled from medsearch settings (environment / .env file)
so migrations always run against the correct database.

Usage:
  alembic upgrade head          # apply all pending migrations
  alembic revision --autogenerate -m "add search events table"
  alembic downgrade -1          # roll back one migration
  alembic history               # list all migrations
"""

from __future__ import annotations

import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

# ---------------------------------------------------------------------------
# Import all models so Alembic's autogenerate sees the full schema
# ---------------------------------------------------------------------------
from medsearch.infra.db.models import Base  # noqa: F401 — registers all tables
from medsearch.settings import get_settings

# ---------------------------------------------------------------------------
# Alembic config object — reads alembic.ini
# ---------------------------------------------------------------------------
config = context.config

# Set up Python logging from alembic.ini [loggers] section
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Point Alembic at the SQLAlchemy metadata so autogenerate works
target_metadata = Base.metadata

# Override sqlalchemy.url from settings (ignores whatever is in alembic.ini)
settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url)


# ---------------------------------------------------------------------------
# Offline mode — generate SQL without connecting
# ---------------------------------------------------------------------------

def run_migrations_offline() -> None:
    """
    Run migrations in 'offline' mode.
    Generates a SQL script instead of executing against a live DB.
    Useful for reviewing migrations before applying them.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url                      = url,
        target_metadata          = target_metadata,
        literal_binds            = True,
        dialect_opts             = {"paramstyle": "named"},
        compare_type             = True,
        compare_server_default   = True,
    )
    with context.begin_transaction():
        context.run_migrations()


# ---------------------------------------------------------------------------
# Online mode — connect and run migrations
# ---------------------------------------------------------------------------

def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection               = connection,
        target_metadata          = target_metadata,
        compare_type             = True,
        compare_server_default   = True,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """Create an async engine and run migrations inside a sync adapter."""
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix       = "sqlalchemy.",
        poolclass    = pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
