"""Initial schema: tenants, api_keys, search_events

Revision ID: 0001
Revises:
Create Date: 2026-01-01 00:00:00
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import ARRAY, UUID

revision:       str                           = "0001"
down_revision:  Union[str, None]              = None
branch_labels:  Union[str, Sequence[str], None] = None
depends_on:     Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ------------------------------------------------------------------
    # Enable PostgreSQL extensions
    # ------------------------------------------------------------------
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

    # ------------------------------------------------------------------
    # tenants
    # ------------------------------------------------------------------
    op.create_table(
        "tenants",
        sa.Column("id",              UUID(as_uuid=False), primary_key=True),
        sa.Column("tenant_id",       sa.String(100),  nullable=False, unique=True),
        sa.Column("display_name",    sa.String(200),  nullable=False),
        sa.Column("allowed_indexes", ARRAY(sa.String), nullable=False, server_default="{}"),
        sa.Column("is_active",       sa.Boolean(),    nullable=False, server_default="true"),
        sa.Column("created_at",      sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.func.now()),
    )
    op.create_index("ix_tenants_tenant_id", "tenants", ["tenant_id"])

    # ------------------------------------------------------------------
    # api_keys
    # ------------------------------------------------------------------
    op.create_table(
        "api_keys",
        sa.Column("id",          UUID(as_uuid=False), primary_key=True),
        sa.Column("tenant_id",   sa.String(100),  nullable=False),
        sa.Column("hashed_key",  sa.String(200),  nullable=False, unique=True),
        sa.Column("is_active",   sa.Boolean(),    nullable=False, server_default="true"),
        sa.Column("rate_limit",  sa.Integer(),    nullable=False, server_default="300"),
        sa.Column("created_at",  sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.func.now()),
        sa.Column("expires_at",  sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_api_keys_hashed_key", "api_keys", ["hashed_key"])
    op.create_index("ix_api_keys_tenant_id",  "api_keys", ["tenant_id"])

    # ------------------------------------------------------------------
    # search_events  (ML training data + analytics)
    # ------------------------------------------------------------------
    op.create_table(
        "search_events",
        sa.Column("id",            sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id",     sa.String(100),  nullable=False),
        sa.Column("query",         sa.String(500),  nullable=False),
        sa.Column("corrected",     sa.String(500),  nullable=False),
        sa.Column("intent",        sa.String(20),   nullable=False),
        sa.Column("result_ids",    ARRAY(sa.String), nullable=False, server_default="{}"),
        sa.Column("selected_id",   sa.String(100),  nullable=True),
        sa.Column("added_to_bill", sa.Boolean(),    nullable=False, server_default="false"),
        sa.Column("latency_ms",    sa.Integer(),    nullable=False),
        sa.Column("zero_results",  sa.Boolean(),    nullable=False, server_default="false"),
        sa.Column("user_id",       sa.String(100),  nullable=True),
        sa.Column("branch_id",     sa.String(100),  nullable=True),
        sa.Column("occurred_at",   sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.func.now()),
    )
    op.create_index("ix_search_events_tenant_occurred",
                    "search_events", ["tenant_id", "occurred_at"])
    op.create_index("ix_search_events_zero_results",
                    "search_events", ["zero_results", "occurred_at"])
    op.create_index("ix_search_events_tenant_query",
                    "search_events", ["tenant_id", "query"])


def downgrade() -> None:
    op.drop_table("search_events")
    op.drop_table("api_keys")
    op.drop_table("tenants")
