"""
tests/e2e/conftest.py

Sets required env vars and patches heavy startup before any test runs.
"""
import os
from unittest.mock import patch, AsyncMock

# Seed env before any settings module is imported
os.environ.setdefault("SECRET_KEY",        "test-secret-key-32-characters-long!")
os.environ.setdefault("DATABASE_URL",      "postgresql+asyncpg://u:p@localhost/medsearch")
os.environ.setdefault("TYPESENSE_API_KEY", "test_key")
os.environ.setdefault("APP_ENV",           "development")
os.environ.setdefault("RANKER_ENABLED",    "false")

# Patch expensive singletons so lifespan never touches real services
patch("medsearch.api.dependencies.init_singletons", lambda s: None).start()
patch("medsearch.api.dependencies.shutdown_singletons", AsyncMock()).start()
