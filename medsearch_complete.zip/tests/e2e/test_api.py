"""
tests/e2e/test_api.py

End-to-end API tests using FastAPI's TestClient.

All infra adapters are overridden via FastAPI's dependency_overrides so
no real services (Redis, Typesense, Qdrant) are required.
These tests verify the complete HTTP → service → HTTP cycle:
  - Correct status codes
  - Response shape matches schemas
  - Validation rejects bad input
  - Error handlers return consistent JSON
  - Auth rejects requests without X-API-Key
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock
from fastapi.testclient import TestClient

from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse
from medsearch.core.domain.search_query import ParsedQuery
from medsearch.services.search_service import SearchService
from medsearch.services.index_service import IndexService
from medsearch.services.query_service import QueryService
from medsearch.services.suggest_service import SuggestService
from medsearch.services.analytics_service import AnalyticsService


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_hit(doc_id: str = "med_1") -> RankedHit:
    return RankedHit(
        hit=SearchHit(
            doc_id  = doc_id,
            score   = 0.9,
            payload = {"name": "Paracetamol", "price": 20.0, "stock_qty": 10},
            source  = "typesense",
        ),
        rank_score  = 0.9,
        rank_reason = "lgbm",
    )

def make_response(hits: list[RankedHit] | None = None) -> SearchResponse:
    return SearchResponse(
        hits            = hits or [make_hit()],
        total           = 1,
        corrected_query = None,
        latency_ms      = 8,
        tenant_id       = "test_tenant",
    )


# ---------------------------------------------------------------------------
# App fixture with all deps overridden
# ---------------------------------------------------------------------------

@pytest.fixture
def client():
    """
    Build a TestClient with all external dependencies mocked out.
    No real Redis, Typesense, or Qdrant connections are made.
    """
    from unittest.mock import patch
    # Patch init_singletons so the lifespan skips real service connections
    with patch("medsearch.api.dependencies.init_singletons"),          patch("medsearch.api.dependencies.shutdown_singletons"):
        from medsearch.settings import get_settings
        get_settings.cache_clear()

        from medsearch.main import create_app
        from medsearch.api import dependencies as deps

    app = create_app()

    # Mock services
    mock_search_svc   = AsyncMock(spec=SearchService)
    mock_search_svc.search.return_value = make_response()

    mock_index_svc    = AsyncMock(spec=IndexService)
    mock_index_svc.upsert = AsyncMock()
    mock_index_svc.delete = AsyncMock()

    mock_query_svc    = MagicMock(spec=QueryService)
    mock_query_svc.parse.return_value = ParsedQuery.passthrough("paracetamol")

    mock_suggest_svc  = AsyncMock(spec=SuggestService)
    mock_suggest_svc.suggest.return_value = ["paracetamol", "paracetamol 500mg"]

    mock_analytics    = MagicMock(spec=AnalyticsService)
    mock_analytics.log_search = MagicMock()
    mock_analytics.get_zero_result_summary = AsyncMock(return_value=[])

    # Cache + engines for health
    mock_cache  = AsyncMock()
    mock_cache.health.return_value = True
    mock_lexical = AsyncMock()
    mock_lexical.health.return_value = True
    mock_vector  = AsyncMock()
    mock_vector.health.return_value  = True

    # Corrector for query service
    mock_corrector = MagicMock()
    mock_corrector.correct.side_effect = lambda q: q

    # Override all dependencies
    from medsearch.api.dependencies import (
        get_search_service, get_index_service, get_query_service,
        get_suggest_service, get_analytics_service,
        get_cache, get_lexical_engine, get_vector_engine, get_corrector,
        verify_api_key,
    )

    app.dependency_overrides[get_search_service]   = lambda: mock_search_svc
    app.dependency_overrides[get_index_service]    = lambda: mock_index_svc
    app.dependency_overrides[get_query_service]    = lambda: mock_query_svc
    app.dependency_overrides[get_suggest_service]  = lambda: mock_suggest_svc
    app.dependency_overrides[get_analytics_service] = lambda: mock_analytics
    app.dependency_overrides[get_cache]            = lambda: mock_cache
    app.dependency_overrides[get_lexical_engine]   = lambda: mock_lexical
    app.dependency_overrides[get_vector_engine]    = lambda: mock_vector
    app.dependency_overrides[get_corrector]        = lambda: mock_corrector
    app.dependency_overrides[verify_api_key]       = lambda: "test_key"

    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


HEADERS = {"X-API-Key": "test_key"}


# ---------------------------------------------------------------------------
# POST /v1/search
# ---------------------------------------------------------------------------

class TestSearchEndpoint:
    def test_returns_200_with_hits(self, client):
        r = client.post("/v1/search", json={
            "query": "paracetamol", "tenant_id": "pharmacy_1",
        }, headers=HEADERS)
        assert r.status_code == 200
        data = r.json()
        assert "hits" in data
        assert "latency_ms" in data
        assert "total" in data

    def test_hits_have_required_fields(self, client):
        r = client.post("/v1/search", json={
            "query": "calpol", "tenant_id": "t1",
        }, headers=HEADERS)
        hit = r.json()["hits"][0]
        assert "doc_id"  in hit
        assert "score"   in hit
        assert "payload" in hit
        assert "source"  in hit

    def test_query_too_short_returns_422(self, client):
        r = client.post("/v1/search", json={
            "query": "p", "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.status_code == 422

    def test_missing_tenant_id_returns_422(self, client):
        r = client.post("/v1/search", json={"query": "calpol"}, headers=HEADERS)
        assert r.status_code == 422

    def test_limit_above_max_returns_422(self, client):
        r = client.post("/v1/search", json={
            "query": "para", "tenant_id": "t1", "limit": 999,
        }, headers=HEADERS)
        assert r.status_code == 422

    def test_missing_api_key_returns_403(self, client):
        # Remove the override — real auth check
        from medsearch.api.dependencies import verify_api_key
        del client.app.dependency_overrides[verify_api_key]
        r = client.post("/v1/search", json={
            "query": "para", "tenant_id": "t1",
        })
        assert r.status_code in (401, 403, 422)
        # Restore override for other tests
        client.app.dependency_overrides[verify_api_key] = lambda: "test_key"

    def test_error_response_has_consistent_shape(self, client):
        r = client.post("/v1/search", json={"query": "p", "tenant_id": "t1"}, headers=HEADERS)
        data = r.json()
        assert "error" in data
        assert "error_code" in data

    def test_with_filters(self, client):
        r = client.post("/v1/search", json={
            "query":     "amoxicillin",
            "tenant_id": "t1",
            "filters":   {"stock_qty": {"gt": 0}},
        }, headers=HEADERS)
        assert r.status_code == 200

    def test_language_field_accepted(self, client):
        r = client.post("/v1/search", json={
            "query": "bukhar", "tenant_id": "t1", "language": "hi-IN",
        }, headers=HEADERS)
        assert r.status_code == 200


# ---------------------------------------------------------------------------
# GET /v1/suggest
# ---------------------------------------------------------------------------

class TestSuggestEndpoint:
    def test_returns_200_with_suggestions(self, client):
        r = client.get("/v1/suggest", params={
            "q": "par", "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.status_code == 200
        data = r.json()
        assert "suggestions" in data
        assert "prefix" in data

    def test_prefix_echoed_in_response(self, client):
        r = client.get("/v1/suggest", params={
            "q": "cal", "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.json()["prefix"] == "cal"

    def test_too_short_prefix_returns_422(self, client):
        r = client.get("/v1/suggest", params={
            "q": "p", "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.status_code == 422

    def test_missing_tenant_id_returns_422(self, client):
        r = client.get("/v1/suggest", params={"q": "par"}, headers=HEADERS)
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# POST /v1/index
# ---------------------------------------------------------------------------

class TestIndexEndpoint:
    def test_upsert_returns_200_with_status(self, client):
        r = client.post("/v1/index", json={
            "tenant_id": "t1",
            "doc_id":    "med_1",
            "document":  {"name": "Calpol", "price": 45.0, "stock_qty": 10},
        }, headers=HEADERS)
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "indexed"
        assert data["doc_id"] == "med_1"

    def test_document_without_name_returns_422(self, client):
        r = client.post("/v1/index", json={
            "tenant_id": "t1",
            "doc_id":    "med_1",
            "document":  {"price": 45.0},   # missing 'name'
        }, headers=HEADERS)
        assert r.status_code == 422

    def test_delete_returns_200(self, client):
        r = client.delete("/v1/index/med_1", params={
            "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "deleted"
        assert data["doc_id"] == "med_1"


# ---------------------------------------------------------------------------
# GET /health
# ---------------------------------------------------------------------------

class TestHealthEndpoints:
    def test_root_health_returns_200(self, client):
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_liveness_returns_200(self, client):
        r = client.get("/v1/health/live")
        assert r.status_code == 200

    def test_readiness_returns_200_when_healthy(self, client):
        r = client.get("/v1/health/ready")
        assert r.status_code == 200

    def test_full_health_has_dependencies(self, client):
        r = client.get("/v1/health")
        assert r.status_code == 200
        data = r.json()
        assert "dependencies" in data
        assert "status" in data
        dep_names = [d["name"] for d in data["dependencies"]]
        assert "redis"     in dep_names
        assert "typesense" in dep_names
        assert "qdrant"    in dep_names


# ---------------------------------------------------------------------------
# Analytics
# ---------------------------------------------------------------------------

class TestAnalyticsEndpoints:
    def test_zero_results_returns_200(self, client):
        r = client.get("/v1/analytics/zero-results", params={
            "tenant_id": "t1",
        }, headers=HEADERS)
        assert r.status_code == 200
        data = r.json()
        assert "items"     in data
        assert "tenant_id" in data

    def test_selection_returns_200(self, client):
        r = client.post("/v1/analytics/select", json={
            "tenant_id":   "t1",
            "query":       "paracetamol",
            "selected_id": "med_1",
        }, headers=HEADERS)
        assert r.status_code == 200
        assert r.json()["status"] == "recorded"
