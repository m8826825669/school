"""
tests/unit/domain/test_events.py

Unit tests for the SearchEvent domain event.
"""

from medsearch.core.domain.events import SearchEvent


def make_event(**overrides) -> SearchEvent:
    defaults = dict(
        tenant_id="pharmacy_1",
        query="parace",
        corrected="paracetamol",
        intent="brand",
        result_ids=("med_1", "med_2", "med_3"),
        latency_ms=8,
    )
    defaults.update(overrides)
    return SearchEvent(**defaults)


class TestSearchEvent:
    def test_zero_results_false_with_hits(self):
        e = make_event(result_ids=("med_1",))
        assert e.zero_results is False

    def test_zero_results_true_when_empty(self):
        e = make_event(result_ids=())
        assert e.zero_results is True

    def test_position_of_selected_first(self):
        e = make_event(selected_id="med_1")
        assert e.position_of_selected == 1

    def test_position_of_selected_third(self):
        e = make_event(selected_id="med_3")
        assert e.position_of_selected == 3

    def test_position_none_when_no_selection(self):
        e = make_event(selected_id=None)
        assert e.position_of_selected is None

    def test_position_none_when_selection_not_in_results(self):
        e = make_event(selected_id="med_999")
        assert e.position_of_selected is None

    def test_was_first_result_selected_true(self):
        e = make_event(selected_id="med_1")
        assert e.was_first_result_selected is True

    def test_was_first_result_selected_false(self):
        e = make_event(selected_id="med_2")
        assert e.was_first_result_selected is False
