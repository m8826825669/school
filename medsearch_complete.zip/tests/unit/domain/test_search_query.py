"""
tests/unit/domain/test_search_query.py

Unit tests for ParsedQuery value object and QueryIntent enum.
No external dependencies — pure domain logic only.
"""

import pytest

from medsearch.core.domain.search_query import (
    ParsedQuery,
    QueryIntent,
    SearchLanguage,
)


# ---------------------------------------------------------------------------
# QueryIntent
# ---------------------------------------------------------------------------


class TestQueryIntent:
    def test_values_are_strings(self):
        assert QueryIntent.BARCODE == "barcode"
        assert QueryIntent.SYMPTOM == "symptom"

    def test_all_intents_present(self):
        intents = {i.value for i in QueryIntent}
        assert intents == {"barcode", "brand", "salt", "symptom", "generic"}


# ---------------------------------------------------------------------------
# ParsedQuery.build()
# ---------------------------------------------------------------------------


class TestParsedQueryBuild:
    def test_normalizes_original(self):
        pq = ParsedQuery.build(
            original="  Parace  ",
            corrected="paracetamol",
            intent=QueryIntent.BRAND,
        )
        assert pq.normalized == "parace"
        assert pq.original == "  Parace  "

    def test_corrected_lowercased(self):
        pq = ParsedQuery.build(
            original="Calpol",
            corrected="Calpol",
            intent=QueryIntent.BRAND,
        )
        assert pq.corrected == "calpol"

    def test_tokens_derived_from_corrected(self):
        pq = ParsedQuery.build(
            original="cold fever",
            corrected="cold fever",
            intent=QueryIntent.SYMPTOM,
        )
        assert pq.tokens == ("cold", "fever")

    def test_tokens_are_immutable_tuple(self):
        pq = ParsedQuery.build(
            original="para",
            corrected="paracetamol",
            intent=QueryIntent.BRAND,
        )
        assert isinstance(pq.tokens, tuple)

    def test_default_language_is_english(self):
        pq = ParsedQuery.build(
            original="para",
            corrected="para",
            intent=QueryIntent.BRAND,
        )
        assert pq.language == SearchLanguage.EN


# ---------------------------------------------------------------------------
# ParsedQuery.passthrough()
# ---------------------------------------------------------------------------


class TestParsedQueryPassthrough:
    def test_passthrough_sets_intent_brand(self):
        pq = ParsedQuery.passthrough("metformin")
        assert pq.intent == QueryIntent.BRAND

    def test_passthrough_no_correction(self):
        pq = ParsedQuery.passthrough("parace")
        assert pq.corrected == "parace"
        assert not pq.was_corrected

    def test_passthrough_strips_and_lowercases(self):
        pq = ParsedQuery.passthrough("  AMOX  ")
        assert pq.normalized == "amox"


# ---------------------------------------------------------------------------
# Derived properties
# ---------------------------------------------------------------------------


class TestParsedQueryProperties:
    def test_was_corrected_true(self):
        pq = ParsedQuery.build(
            original="calpoll",
            corrected="calpol",
            intent=QueryIntent.BRAND,
        )
        assert pq.was_corrected is True

    def test_was_corrected_false(self):
        pq = ParsedQuery.passthrough("calpol")
        assert pq.was_corrected is False

    def test_is_barcode(self):
        pq = ParsedQuery.build(
            original="8901234567890",
            corrected="8901234567890",
            intent=QueryIntent.BARCODE,
        )
        assert pq.is_barcode is True
        assert pq.is_symptom_query is False

    def test_is_symptom_query(self):
        pq = ParsedQuery.build(
            original="cold fever",
            corrected="cold fever",
            intent=QueryIntent.SYMPTOM,
        )
        assert pq.is_symptom_query is True
        assert pq.is_barcode is False

    def test_token_count(self):
        pq = ParsedQuery.build(
            original="cold fever cough",
            corrected="cold fever cough",
            intent=QueryIntent.SYMPTOM,
        )
        assert pq.token_count == 3
        assert pq.is_single_token is False

    def test_is_single_token_true(self):
        pq = ParsedQuery.passthrough("paracetamol")
        assert pq.is_single_token is True


# ---------------------------------------------------------------------------
# Immutability
# ---------------------------------------------------------------------------


class TestParsedQueryImmutability:
    def test_frozen_raises_on_attribute_set(self):
        pq = ParsedQuery.passthrough("para")
        with pytest.raises((AttributeError, TypeError)):
            pq.intent = QueryIntent.SALT  # type: ignore[misc]

    def test_tokens_tuple_is_immutable(self):
        pq = ParsedQuery.passthrough("cold fever")
        with pytest.raises(AttributeError):
            pq.tokens.append("cough")  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# __str__
# ---------------------------------------------------------------------------


class TestParsedQueryStr:
    def test_str_without_correction(self):
        pq = ParsedQuery.passthrough("paracetamol")
        assert "paracetamol" in str(pq)
        assert "brand" in str(pq)

    def test_str_with_correction(self):
        pq = ParsedQuery.build(
            original="calpoll",
            corrected="calpol",
            intent=QueryIntent.BRAND,
        )
        s = str(pq)
        assert "calpoll" in s
        assert "calpol" in s
