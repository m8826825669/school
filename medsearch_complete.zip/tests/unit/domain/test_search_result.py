"""
tests/unit/domain/test_search_result.py

Unit tests for SearchHit, RankedHit, and SearchResponse value objects.
"""

from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_hit(
    doc_id: str = "med_1",
    score: float = 0.9,
    stock: int = 10,
    price: float = 25.0,
    name: str = "Paracetamol",
) -> SearchHit:
    return SearchHit(
        doc_id=doc_id,
        score=score,
        payload={"name": name, "price": price, "stock_qty": stock},
        source="typesense",
    )


def make_ranked(hit: SearchHit | None = None, rank_score: float = 0.95) -> RankedHit:
    return RankedHit(hit=hit or make_hit(), rank_score=rank_score)


# ---------------------------------------------------------------------------
# SearchHit
# ---------------------------------------------------------------------------


class TestSearchHit:
    def test_payload_accessors(self):
        hit = make_hit(name="Calpol", price=45.0, stock=5)
        assert hit.name == "Calpol"
        assert hit.price == 45.0
        assert hit.stock_qty == 5

    def test_is_in_stock_true(self):
        assert make_hit(stock=1).is_in_stock is True

    def test_is_in_stock_false(self):
        assert make_hit(stock=0).is_in_stock is False

    def test_get_missing_key_returns_default(self):
        hit = make_hit()
        assert hit.get("nonexistent", "fallback") == "fallback"

    def test_get_existing_key(self):
        hit = make_hit(name="Dolo")
        assert hit.get("name") == "Dolo"

    def test_source_stored(self):
        hit = SearchHit(doc_id="1", score=0.5, source="qdrant")
        assert hit.source == "qdrant"

    def test_empty_payload_defaults(self):
        hit = SearchHit(doc_id="x", score=0.1)
        assert hit.name == ""
        assert hit.price == 0.0
        assert hit.stock_qty == 0
        assert hit.is_in_stock is False


# ---------------------------------------------------------------------------
# RankedHit
# ---------------------------------------------------------------------------


class TestRankedHit:
    def test_proxies_doc_id(self):
        hit = make_hit(doc_id="med_99")
        ranked = make_ranked(hit)
        assert ranked.doc_id == "med_99"

    def test_proxies_name(self):
        hit = make_hit(name="Amoxicillin")
        ranked = make_ranked(hit)
        assert ranked.name == "Amoxicillin"

    def test_proxies_is_in_stock(self):
        hit = make_hit(stock=0)
        ranked = make_ranked(hit)
        assert ranked.is_in_stock is False

    def test_to_dict_shape(self):
        ranked = make_ranked(rank_score=0.873456)
        d = ranked.to_dict()
        assert "doc_id" in d
        assert "score" in d
        assert "payload" in d
        assert "source" in d
        assert d["score"] == round(0.873456, 4)

    def test_to_dict_score_rounded(self):
        ranked = make_ranked(rank_score=0.123456789)
        assert ranked.to_dict()["score"] == 0.1235


# ---------------------------------------------------------------------------
# SearchResponse
# ---------------------------------------------------------------------------


class TestSearchResponse:
    def _make_response(self, hits: list[RankedHit] | None = None) -> SearchResponse:
        return SearchResponse(
            hits=hits or [make_ranked()],
            total=1,
            corrected_query=None,
            latency_ms=7,
            tenant_id="t1",
        )

    def test_is_empty_false_with_hits(self):
        assert self._make_response().is_empty is False

    def test_is_empty_true_with_no_hits(self):
        r = SearchResponse.empty("t1")
        assert r.is_empty is True

    def test_hit_count(self):
        hits = [make_ranked(), make_ranked(rank_score=0.8)]
        assert self._make_response(hits).hit_count == 2

    def test_top_hit_returns_first(self):
        h1 = make_ranked(rank_score=0.95)
        h2 = make_ranked(rank_score=0.70)
        r = self._make_response([h1, h2])
        assert r.top_hit is h1

    def test_top_hit_none_when_empty(self):
        r = SearchResponse.empty("t1")
        assert r.top_hit is None

    def test_to_dict_keys(self):
        d = self._make_response().to_dict()
        assert set(d.keys()) == {
            "hits", "total", "corrected_query", "latency_ms", "tenant_id"
        }

    def test_empty_factory(self):
        r = SearchResponse.empty("pharmacy_1", latency_ms=2)
        assert r.tenant_id == "pharmacy_1"
        assert r.total == 0
        assert r.corrected_query is None
        assert r.latency_ms == 2
        assert r.hits == []
