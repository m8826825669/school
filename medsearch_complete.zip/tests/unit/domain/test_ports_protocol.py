"""
tests/unit/domain/test_ports_protocol.py

Verify all port interfaces are runtime_checkable Protocols.

These tests act as a contract guard — if someone accidentally removes
@runtime_checkable from a port, this test catches it immediately.
They also serve as documentation: here is every method each adapter must implement.
"""

from medsearch.core.ports import (
    ICacheStore,
    IEmbedder,
    IEventStore,
    IRanker,
    ISearchEngine,
    ITenantStore,
)


class TestPortsAreProtocols:
    """Ensure all ports are inspectable at runtime via isinstance()."""

    def test_isearch_engine_is_protocol(self):
        # A class that doesn't implement the protocol
        class NotAnEngine:
            pass

        assert not isinstance(NotAnEngine(), ISearchEngine)

    def test_icache_store_is_protocol(self):
        class NotACache:
            pass

        assert not isinstance(NotACache(), ICacheStore)

    def test_iembedder_is_protocol(self):
        class NotAnEmbedder:
            pass

        assert not isinstance(NotAnEmbedder(), IEmbedder)

    def test_iranker_is_protocol(self):
        class NotARanker:
            pass

        assert not isinstance(NotARanker(), IRanker)

    def test_ievent_store_is_protocol(self):
        class NotAnEventStore:
            pass

        assert not isinstance(NotAnEventStore(), IEventStore)

    def test_itenant_store_is_protocol(self):
        class NotATenantStore:
            pass

        assert not isinstance(NotATenantStore(), ITenantStore)


class TestSearchEngineProtocolMethods:
    """Document the exact method signatures ISearchEngine requires."""

    def test_search_engine_requires_all_methods(self):
        import inspect
        methods = {
            name for name, _ in inspect.getmembers(ISearchEngine, predicate=inspect.isfunction)
        }
        assert "search"       in methods
        assert "upsert"       in methods
        assert "delete"       in methods
        assert "create_index" in methods
        assert "health"       in methods


class TestCacheStoreProtocolMethods:
    def test_cache_store_requires_all_methods(self):
        import inspect
        methods = {
            name for name, _ in inspect.getmembers(ICacheStore, predicate=inspect.isfunction)
        }
        assert "get"            in methods
        assert "set"            in methods
        assert "delete"         in methods
        assert "delete_pattern" in methods
        assert "get_json"       in methods
        assert "set_json"       in methods
        assert "health"         in methods
