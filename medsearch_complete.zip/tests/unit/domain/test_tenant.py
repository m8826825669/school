"""
tests/unit/domain/test_tenant.py

Unit tests for Tenant and ApiKey value objects.
"""

from datetime import datetime, timedelta, timezone

from medsearch.core.domain.tenant import ApiKey, Tenant


# ---------------------------------------------------------------------------
# Tenant
# ---------------------------------------------------------------------------


class TestTenant:
    def _make(self, allowed: set[str] | None = None) -> Tenant:
        return Tenant(
            tenant_id="pharmacy_1",
            display_name="Mumbai Pharmacy",
            allowed_indexes=frozenset(allowed or {"medicines"}),
        )

    def test_can_access_allowed_index(self):
        t = self._make({"medicines", "products"})
        assert t.can_access_index("medicines") is True

    def test_cannot_access_disallowed_index(self):
        t = self._make({"medicines"})
        assert t.can_access_index("employees") is False

    def test_empty_allowed_indexes_permits_all(self):
        t = Tenant(tenant_id="admin", display_name="Admin", allowed_indexes=frozenset())
        assert t.can_access_index("anything") is True

    def test_str_representation(self):
        t = self._make()
        assert "pharmacy_1" in str(t)

    def test_is_active_default_true(self):
        assert self._make().is_active is True


# ---------------------------------------------------------------------------
# ApiKey
# ---------------------------------------------------------------------------


class TestApiKey:
    def _make(self, active: bool = True, expires: datetime | None = None) -> ApiKey:
        return ApiKey(
            key_id="key-uuid-1",
            tenant_id="pharmacy_1",
            hashed_key="$2b$12$hashedvalue",
            is_active=active,
            expires_at=expires,
        )

    def test_valid_active_non_expiring(self):
        assert self._make().is_valid is True

    def test_invalid_when_inactive(self):
        assert self._make(active=False).is_valid is False

    def test_not_expired_when_no_expiry(self):
        assert self._make().is_expired is False

    def test_expired_when_past_expiry(self):
        past = datetime.now(timezone.utc) - timedelta(hours=1)
        key = self._make(expires=past)
        assert key.is_expired is True
        assert key.is_valid is False

    def test_not_expired_before_expiry(self):
        future = datetime.now(timezone.utc) + timedelta(days=30)
        key = self._make(expires=future)
        assert key.is_expired is False
        assert key.is_valid is True

    def test_inactive_and_not_expired_is_still_invalid(self):
        future = datetime.now(timezone.utc) + timedelta(days=1)
        key = self._make(active=False, expires=future)
        assert key.is_valid is False
