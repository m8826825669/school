"""
tests/unit/services/test_pharmacy_client.py

Unit tests for the MedSearch pharmacy client.
Uses httpx MockTransport — no real HTTP calls made.
"""

from __future__ import annotations

import json
import pytest
import httpx
from unittest.mock import AsyncMock

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from pharmacy_client.client import MedSearchClient, MedSearchError


# ---------------------------------------------------------------------------
# Mock transport helper
# ---------------------------------------------------------------------------

def make_transport(responses: dict[str, tuple[int, dict]]) -> httpx.MockTransport:
    """
    Build an httpx MockTransport that maps (method, path) → (status, body).

    responses = {
        "POST /v1/search": (200, {"hits": [...], "total": 1, "latency_ms": 5}),
        "GET /v1/suggest": (200, {"suggestions": ["paracetamol"], "prefix": "par"}),
    }
    """
    def handler(request: httpx.Request) -> httpx.Response:
        key = f"{request.method} {request.url.path}"
        if key in responses:
            status, body = responses[key]
            return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not found", "error_code": "NOT_FOUND"})

    return httpx.MockTransport(handler)


def make_client(responses: dict) -> MedSearchClient:
    transport = make_transport(responses)
    client    = MedSearchClient("http://test", "test_key")
    client._http = httpx.AsyncClient(
        base_url  = "http://test",
        headers   = {"X-API-Key": "test_key"},
        transport = transport,
    )
    return client


# ---------------------------------------------------------------------------
# search()
# ---------------------------------------------------------------------------

class TestMedSearchClientSearch:
    @pytest.mark.asyncio
    async def test_returns_hit_payloads(self):
        payload  = {"name": "Calpol", "price": 45.0, "stock_qty": 10}
        client   = make_client({
            "POST /v1/search": (200, {
                "hits":    [{"doc_id": "med_1", "score": 0.9, "payload": payload, "source": "typesense"}],
                "total":   1,
                "latency_ms": 5,
                "corrected_query": None,
            }),
        })
        results  = await client.search("calpol", "pharmacy_1")
        assert len(results) == 1
        assert results[0]["name"] == "Calpol"

    @pytest.mark.asyncio
    async def test_returns_empty_on_timeout(self):
        async def timeout_handler(request):
            raise httpx.TimeoutException("timeout")
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(timeout_handler))
        result = await client.search("calpol", "pharmacy_1")
        assert result == []

    @pytest.mark.asyncio
    async def test_returns_empty_on_connection_error(self):
        async def conn_error(request):
            raise httpx.ConnectError("refused")
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(conn_error))
        result = await client.search("calpol", "pharmacy_1")
        assert result == []

    @pytest.mark.asyncio
    async def test_raises_medsearch_error_on_400(self):
        client = make_client({
            "POST /v1/search": (422, {"error": "query too short", "error_code": "VALIDATION_ERROR"}),
        })
        with pytest.raises(MedSearchError) as exc_info:
            await client.search("p", "pharmacy_1")
        assert exc_info.value.status_code == 422

    @pytest.mark.asyncio
    async def test_default_filter_is_in_stock(self):
        """Verify the default filter is passed to the API."""
        captured = {}
        async def capture(request):
            captured["body"] = json.loads(request.content)
            payload = {"name": "Calpol", "stock_qty": 5}
            return httpx.Response(200, json={
                "hits": [{"doc_id": "1", "score": 0.9, "payload": payload, "source": "ts"}],
                "total": 1, "latency_ms": 3, "corrected_query": None,
            })
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(capture))
        await client.search("calpol", "pharmacy_1")
        assert captured["body"]["filters"] == {"stock_qty": {"gt": 0}}

    @pytest.mark.asyncio
    async def test_language_defaults_to_hi_in(self):
        captured = {}
        async def capture(request):
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={
                "hits": [], "total": 0, "latency_ms": 1, "corrected_query": None
            })
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(capture))
        await client.search("calpol", "t1")
        assert captured["body"]["language"] == "hi-IN"


# ---------------------------------------------------------------------------
# suggest()
# ---------------------------------------------------------------------------

class TestMedSearchClientSuggest:
    @pytest.mark.asyncio
    async def test_returns_suggestions(self):
        client = make_client({
            "GET /v1/suggest": (200, {"suggestions": ["paracetamol", "paracetamol 500mg"], "prefix": "par"}),
        })
        result = await client.suggest("par", "pharmacy_1")
        assert "paracetamol" in result

    @pytest.mark.asyncio
    async def test_returns_empty_on_network_error(self):
        async def fail(request):
            raise httpx.ConnectError("down")
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(fail))
        result = await client.suggest("par", "t1")
        assert result == []


# ---------------------------------------------------------------------------
# index()
# ---------------------------------------------------------------------------

class TestMedSearchClientIndex:
    @pytest.mark.asyncio
    async def test_returns_true_on_success(self):
        client = make_client({
            "POST /v1/index": (200, {"status": "indexed", "doc_id": "med_1", "tenant_id": "t1"}),
        })
        result = await client.index("t1", "med_1", {"name": "Calpol", "price": 45.0})
        assert result is True

    @pytest.mark.asyncio
    async def test_returns_false_on_error(self):
        client = make_client({
            "POST /v1/index": (500, {"error": "engine down", "error_code": "INTERNAL_ERROR"}),
        })
        result = await client.index("t1", "med_1", {"name": "Calpol"})
        assert result is False

    @pytest.mark.asyncio
    async def test_delete_returns_true_on_success(self):
        client = make_client({
            "DELETE /v1/index/med_1": (200, {"status": "deleted", "doc_id": "med_1", "tenant_id": "t1"}),
        })
        result = await client.delete("t1", "med_1")
        assert result is True


# ---------------------------------------------------------------------------
# is_healthy()
# ---------------------------------------------------------------------------

class TestMedSearchClientHealth:
    @pytest.mark.asyncio
    async def test_healthy_when_200(self):
        client = make_client({"GET /health": (200, {"status": "ok"})})
        assert await client.is_healthy() is True

    @pytest.mark.asyncio
    async def test_unhealthy_when_503(self):
        client = make_client({"GET /health": (503, {"status": "not_ready"})})
        assert await client.is_healthy() is False

    @pytest.mark.asyncio
    async def test_unhealthy_on_connection_error(self):
        async def fail(request):
            raise httpx.ConnectError("refused")
        client = MedSearchClient("http://test", "key")
        client._http = httpx.AsyncClient(transport=httpx.MockTransport(fail))
        assert await client.is_healthy() is False


# ---------------------------------------------------------------------------
# from_env()
# ---------------------------------------------------------------------------

class TestMedSearchClientFromEnv:
    def test_reads_from_environment(self, monkeypatch):
        monkeypatch.setenv("MEDSEARCH_URL",     "http://medsearch:8001")
        monkeypatch.setenv("MEDSEARCH_API_KEY", "my_key")
        monkeypatch.setenv("MEDSEARCH_TIMEOUT", "5.0")
        client = MedSearchClient.from_env()
        assert "medsearch:8001" in client._base_url
        assert client._timeout  == 5.0

    def test_default_url_when_env_not_set(self, monkeypatch):
        monkeypatch.delenv("MEDSEARCH_URL", raising=False)
        client = MedSearchClient.from_env()
        assert "localhost:8001" in client._base_url


# ---------------------------------------------------------------------------
# MedSearchError
# ---------------------------------------------------------------------------

class TestMedSearchError:
    def test_stores_status_code_and_detail(self):
        err = MedSearchError(422, "query too short")
        assert err.status_code == 422
        assert err.detail      == "query too short"
        assert "422" in str(err)
