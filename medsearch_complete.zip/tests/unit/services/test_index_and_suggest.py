"""
tests/unit/services/test_index_and_suggest.py

Unit tests for IndexService and SuggestService.
All external adapters are mocked.
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock

from medsearch.core.domain.search_result import SearchHit
from medsearch.services.index_service import IndexService
from medsearch.services.suggest_service import SuggestService


# ===========================================================================
# IndexService
# ===========================================================================

@pytest.fixture
def lexical_engine():
    m = AsyncMock()
    m.upsert = AsyncMock()
    m.delete = AsyncMock()
    m.create_index = AsyncMock()
    return m

@pytest.fixture
def vector_engine():
    m = AsyncMock()
    m.upsert = AsyncMock()
    m.delete = AsyncMock()
    m.create_index = AsyncMock()
    return m

@pytest.fixture
def cache():
    m = AsyncMock()
    m.delete_pattern = AsyncMock()
    return m

@pytest.fixture
def trie():
    m = AsyncMock()
    m.add    = AsyncMock()
    m.remove = AsyncMock()
    return m

@pytest.fixture
def index_svc(lexical_engine, vector_engine, cache, trie):
    return IndexService(lexical_engine, vector_engine, cache, trie)


class TestIndexServiceUpsert:
    @pytest.mark.asyncio
    async def test_upsert_calls_both_engines(self, index_svc, lexical_engine, vector_engine):
        await index_svc.upsert("t1", "medicines", "med_1", {"name": "Calpol", "price": 45.0})
        lexical_engine.upsert.assert_called_once()
        vector_engine.upsert.assert_called_once()

    @pytest.mark.asyncio
    async def test_upsert_updates_trie(self, index_svc, trie):
        await index_svc.upsert("t1", "medicines", "med_1", {"name": "Calpol"})
        trie.add.assert_called_once_with("t1", "medicines", "Calpol", "med_1")

    @pytest.mark.asyncio
    async def test_upsert_invalidates_cache(self, index_svc, cache):
        await index_svc.upsert("t1", "medicines", "med_1", {"name": "Calpol"})
        cache.delete_pattern.assert_called_once_with("t1:medicines:*")

    @pytest.mark.asyncio
    async def test_upsert_skips_trie_when_no_name(self, index_svc, trie):
        await index_svc.upsert("t1", "medicines", "med_1", {"price": 20.0})
        trie.add.assert_not_called()

    @pytest.mark.asyncio
    async def test_upsert_continues_when_one_engine_fails(
        self, index_svc, lexical_engine, vector_engine
    ):
        lexical_engine.upsert.side_effect = ConnectionError("Typesense down")
        # Should not raise — partial failure is logged and swallowed
        await index_svc.upsert("t1", "medicines", "med_1", {"name": "Calpol"})
        vector_engine.upsert.assert_called_once()   # vector still ran

    @pytest.mark.asyncio
    async def test_upsert_passes_correct_args_to_lexical(
        self, index_svc, lexical_engine
    ):
        doc = {"name": "Amoxicillin", "price": 30.0, "stock_qty": 5}
        await index_svc.upsert("pharmacy_1", "medicines", "med_99", doc)
        lexical_engine.upsert.assert_called_once_with(
            "pharmacy_1", "medicines", "med_99", doc
        )


class TestIndexServiceDelete:
    @pytest.mark.asyncio
    async def test_delete_calls_both_engines(self, index_svc, lexical_engine, vector_engine):
        await index_svc.delete("t1", "medicines", "med_1")
        lexical_engine.delete.assert_called_once_with("t1", "medicines", "med_1")
        vector_engine.delete.assert_called_once_with("t1", "medicines", "med_1")

    @pytest.mark.asyncio
    async def test_delete_removes_from_trie(self, index_svc, trie):
        await index_svc.delete("t1", "medicines", "med_1")
        trie.remove.assert_called_once_with("t1", "medicines", "med_1")

    @pytest.mark.asyncio
    async def test_delete_invalidates_cache(self, index_svc, cache):
        await index_svc.delete("t1", "medicines", "med_1")
        cache.delete_pattern.assert_called_once_with("t1:medicines:*")


class TestIndexServiceCreateIndex:
    @pytest.mark.asyncio
    async def test_create_index_calls_both_engines(
        self, index_svc, lexical_engine, vector_engine
    ):
        await index_svc.create_index("new_tenant", "medicines", {})
        lexical_engine.create_index.assert_called_once()
        vector_engine.create_index.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_index_tenant_and_index_passed(
        self, index_svc, lexical_engine
    ):
        schema = {"fields": [{"name": "name", "type": "string"}]}
        await index_svc.create_index("clinic_1", "doctors", schema)
        args = lexical_engine.create_index.call_args[0]
        assert args[0] == "clinic_1"
        assert args[1] == "doctors"


# ===========================================================================
# SuggestService
# ===========================================================================

@pytest.fixture
def suggest_trie():
    m = AsyncMock()
    m.suggest = AsyncMock(return_value=["paracetamol", "paracetamol 500mg"])
    return m

@pytest.fixture
def suggest_lexical():
    m = AsyncMock()
    m.search = AsyncMock(return_value=[
        SearchHit(doc_id="1", score=0.9,
                  payload={"name": "Paracetamol", "stock_qty": 5}, source="typesense"),
    ])
    return m

@pytest.fixture
def suggest_svc(suggest_trie, suggest_lexical):
    return SuggestService(suggest_trie, suggest_lexical)


class TestSuggestServiceTrieHit:
    @pytest.mark.asyncio
    async def test_returns_trie_suggestions(self, suggest_svc):
        result = await suggest_svc.suggest("par", "t1", "medicines")
        assert "paracetamol" in result

    @pytest.mark.asyncio
    async def test_trie_hit_skips_lexical(self, suggest_svc, suggest_lexical):
        await suggest_svc.suggest("par", "t1", "medicines")
        suggest_lexical.search.assert_not_called()

    @pytest.mark.asyncio
    async def test_short_prefix_returns_empty(self, suggest_svc):
        result = await suggest_svc.suggest("p", "t1", "medicines")
        assert result == []

    @pytest.mark.asyncio
    async def test_empty_prefix_returns_empty(self, suggest_svc):
        result = await suggest_svc.suggest("", "t1", "medicines")
        assert result == []

    @pytest.mark.asyncio
    async def test_whitespace_only_returns_empty(self, suggest_svc):
        result = await suggest_svc.suggest("  ", "t1", "medicines")
        assert result == []


class TestSuggestServiceLexicalFallback:
    @pytest.mark.asyncio
    async def test_falls_back_to_lexical_when_trie_empty(
        self, suggest_lexical, suggest_trie
    ):
        suggest_trie.suggest.return_value = []   # trie cold
        svc    = SuggestService(suggest_trie, suggest_lexical)
        result = await svc.suggest("par", "t1", "medicines")
        suggest_lexical.search.assert_called_once()
        assert "Paracetamol" in result

    @pytest.mark.asyncio
    async def test_lexical_fallback_extracts_name_field(self, suggest_lexical, suggest_trie):
        suggest_trie.suggest.return_value = []
        svc    = SuggestService(suggest_trie, suggest_lexical)
        result = await svc.suggest("par", "t1", "medicines")
        assert all(isinstance(r, str) for r in result)

    @pytest.mark.asyncio
    async def test_lexical_fallback_deduplicates(self, suggest_trie):
        # Lexical returns the same name twice (e.g. from different sources)
        lexical = AsyncMock()
        lexical.search.return_value = [
            SearchHit(doc_id="1", score=0.9,
                      payload={"name": "Calpol", "stock_qty": 5}, source="typesense"),
            SearchHit(doc_id="2", score=0.8,
                      payload={"name": "Calpol", "stock_qty": 3}, source="typesense"),
        ]
        suggest_trie.suggest.return_value = []
        svc    = SuggestService(suggest_trie, lexical)
        result = await svc.suggest("cal", "t1", "medicines")
        assert result.count("Calpol") == 1

    @pytest.mark.asyncio
    async def test_lexical_fallback_failure_returns_empty(self, suggest_trie):
        lexical = AsyncMock()
        lexical.search.side_effect = ConnectionError("Typesense down")
        suggest_trie.suggest.return_value = []
        svc    = SuggestService(suggest_trie, lexical)
        result = await svc.suggest("par", "t1", "medicines")
        assert result == []   # never raises


# ===========================================================================
# AnalyticsService
# ===========================================================================

class TestAnalyticsService:
    def _make_svc(self, store=None):
        from medsearch.services.analytics_service import AnalyticsService
        return AnalyticsService(store or AsyncMock())

    def _make_response(self, hits=None):
        from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse
        h = SearchHit(doc_id="med_1", score=0.9,
                      payload={"name": "Calpol", "stock_qty": 5}, source="typesense")
        return SearchResponse(
            hits=[RankedHit(hit=h, rank_score=0.9)] if hits is None else hits,
            total=1, corrected_query=None, latency_ms=8, tenant_id="t1",
        )

    def _make_query(self):
        from medsearch.core.domain.search_query import ParsedQuery
        return ParsedQuery.passthrough("calpol")

    @pytest.mark.asyncio
    async def test_log_search_does_not_raise(self):
        svc = self._make_svc()
        # Fire-and-forget — should never raise even if store fails
        svc.log_search(self._make_query(), self._make_response())

    @pytest.mark.asyncio
    async def test_get_zero_result_summary_returns_list(self):
        store = AsyncMock()
        store.get_zero_result_queries.return_value = [("amoxicilin", 5), ("calpoll", 3)]
        svc    = self._make_svc(store)
        result = await svc.get_zero_result_summary("t1")
        assert len(result) == 2
        assert result[0]["query"] == "amoxicilin"
        assert result[0]["count"] == 5

    @pytest.mark.asyncio
    async def test_get_zero_result_summary_empty_on_error(self):
        store = AsyncMock()
        store.get_zero_result_queries.side_effect = Exception("DB error")
        svc    = self._make_svc(store)
        result = await svc.get_zero_result_summary("t1")
        assert result == []    # never raises
