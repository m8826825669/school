"""
tests/unit/services/test_search_service.py

Unit tests for SearchService — the main search pipeline.

Uses AsyncMock for all port interfaces so no real services are needed.
Tests cover: cache hit, cache miss, parallel search, RRF merge,
engine failure isolation, empty results, and response shape.
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from medsearch.core.domain.search_query import ParsedQuery, QueryIntent
from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse
from medsearch.services.search_service import SearchService


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_hit(doc_id: str, score: float = 0.9, source: str = "typesense") -> SearchHit:
    return SearchHit(
        doc_id=doc_id, score=score,
        payload={"name": f"Med {doc_id}", "stock_qty": 10, "price": 20.0},
        source=source,
    )

def make_ranked(hit: SearchHit, score: float = 0.9) -> RankedHit:
    return RankedHit(hit=hit, rank_score=score)

def make_query(q: str = "paracetamol") -> ParsedQuery:
    return ParsedQuery.passthrough(q)


@pytest.fixture
def lexical():
    m = AsyncMock()
    m.search.return_value = [make_hit("med_1", 0.95), make_hit("med_2", 0.80)]
    return m

@pytest.fixture
def vector():
    m = AsyncMock()
    m.search.return_value = [make_hit("med_2", 0.85, "qdrant"), make_hit("med_3", 0.70, "qdrant")]
    return m

@pytest.fixture
def cache():
    m = AsyncMock()
    m.get_json.return_value = None        # cache miss by default
    m.set_json = AsyncMock()
    m.delete_pattern = AsyncMock()
    return m

@pytest.fixture
def ranker():
    m = MagicMock()
    m.rerank.side_effect = lambda q, hits, ctx: [
        make_ranked(h, score=h.score) for h in hits
    ]
    return m

@pytest.fixture
def svc(lexical, vector, cache, ranker):
    return SearchService(lexical, vector, cache, ranker)


# ---------------------------------------------------------------------------
# Cache hit
# ---------------------------------------------------------------------------

class TestCacheHit:
    @pytest.mark.asyncio
    async def test_returns_cached_response_immediately(self, svc, cache, lexical):
        cache.get_json.return_value = {
            "hits": [], "total": 0, "corrected_query": None,
            "latency_ms": 1, "tenant_id": "t1",
        }
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        assert isinstance(result, SearchResponse)
        lexical.search.assert_not_called()   # engines never fired

    @pytest.mark.asyncio
    async def test_cache_hit_returns_correct_tenant_id(self, svc, cache):
        cache.get_json.return_value = {
            "hits": [], "total": 0, "corrected_query": None,
            "latency_ms": 2, "tenant_id": "pharmacy_1",
        }
        result = await svc.search(make_query(), "pharmacy_1", "medicines", {}, {}, None, 10)
        assert result.tenant_id == "pharmacy_1"


# ---------------------------------------------------------------------------
# Cache miss → full pipeline
# ---------------------------------------------------------------------------

class TestCacheMiss:
    @pytest.mark.asyncio
    async def test_both_engines_called(self, svc, lexical, vector):
        await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        lexical.search.assert_called_once()
        vector.search.assert_called_once()

    @pytest.mark.asyncio
    async def test_response_is_search_response(self, svc):
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        assert isinstance(result, SearchResponse)

    @pytest.mark.asyncio
    async def test_hits_limited_to_limit_arg(self, svc):
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 1)
        assert result.hit_count <= 1

    @pytest.mark.asyncio
    async def test_ranker_receives_merged_candidates(self, svc, ranker):
        await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        ranker.rerank.assert_called_once()
        _, candidates, _ = ranker.rerank.call_args[0]
        # Both engines returned hits — all should be in the candidate pool
        doc_ids = [c.doc_id for c in candidates]
        assert "med_1" in doc_ids
        assert "med_3" in doc_ids

    @pytest.mark.asyncio
    async def test_corrected_query_set_when_corrected(self):
        corrected_query = ParsedQuery.build(
            original="paracetamul",
            corrected="paracetamol",
            intent=QueryIntent.BRAND,
        )
        lexical = AsyncMock()
        lexical.search.return_value = [make_hit("med_1")]
        vector  = AsyncMock()
        vector.search.return_value  = []
        cache   = AsyncMock()
        cache.get_json.return_value = None
        ranker  = MagicMock()
        ranker.rerank.return_value  = [make_ranked(make_hit("med_1"))]

        svc = SearchService(lexical, vector, cache, ranker)
        result = await svc.search(corrected_query, "t1", "medicines", {}, {}, None, 10)
        assert result.corrected_query == "paracetamol"

    @pytest.mark.asyncio
    async def test_no_corrected_query_when_not_corrected(self, svc):
        result = await svc.search(make_query("calpol"), "t1", "medicines", {}, {}, None, 10)
        assert result.corrected_query is None

    @pytest.mark.asyncio
    async def test_latency_ms_is_positive(self, svc):
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        assert result.latency_ms >= 0


# ---------------------------------------------------------------------------
# Engine failure isolation
# ---------------------------------------------------------------------------

class TestEngineFailureIsolation:
    @pytest.mark.asyncio
    async def test_lexical_failure_still_returns_vector_results(self, vector, cache, ranker):
        lexical = AsyncMock()
        lexical.search.side_effect = ConnectionError("Typesense down")
        svc = SearchService(lexical, vector, cache, ranker)
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        # Vector results should still come through
        assert isinstance(result, SearchResponse)
        assert result.hit_count > 0

    @pytest.mark.asyncio
    async def test_vector_failure_still_returns_lexical_results(self, lexical, cache, ranker):
        vector = AsyncMock()
        vector.search.side_effect = ConnectionError("Qdrant down")
        svc = SearchService(lexical, vector, cache, ranker)
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        assert isinstance(result, SearchResponse)
        assert result.hit_count > 0

    @pytest.mark.asyncio
    async def test_both_engines_fail_returns_empty(self, cache, ranker):
        lexical = AsyncMock()
        lexical.search.side_effect = ConnectionError("down")
        vector  = AsyncMock()
        vector.search.side_effect  = ConnectionError("down")
        ranker.rerank.return_value = []
        svc = SearchService(lexical, vector, cache, ranker)
        result = await svc.search(make_query(), "t1", "medicines", {}, {}, None, 10)
        assert result.is_empty is True


# ---------------------------------------------------------------------------
# RRF merge
# ---------------------------------------------------------------------------

class TestRRFMerge:
    def _svc(self):
        return SearchService(AsyncMock(), AsyncMock(), AsyncMock(), MagicMock())

    def test_duplicate_doc_deduped(self):
        svc  = self._svc()
        lex  = [make_hit("med_1", 0.9), make_hit("med_2", 0.7)]
        vec  = [make_hit("med_2", 0.8, "qdrant"), make_hit("med_3", 0.6, "qdrant")]
        merged = svc._rrf_merge([lex, vec])
        doc_ids = [h.doc_id for h in merged]
        # med_2 appears in both lists — should appear once
        assert doc_ids.count("med_2") == 1

    def test_doc_in_both_lists_ranks_higher(self):
        svc = self._svc()
        lex = [make_hit("med_unique_lex",  0.9), make_hit("med_in_both", 0.8)]
        vec = [make_hit("med_in_both",     0.9, "qdrant"), make_hit("med_unique_vec", 0.7, "qdrant")]
        merged = svc._rrf_merge([lex, vec])
        doc_ids = [h.doc_id for h in merged]
        # med_in_both appears in both → should rank above unique items
        assert doc_ids.index("med_in_both") < doc_ids.index("med_unique_lex") or \
               doc_ids.index("med_in_both") < doc_ids.index("med_unique_vec")

    def test_empty_lists_returns_empty(self):
        svc    = self._svc()
        merged = svc._rrf_merge([[], []])
        assert merged == []

    def test_single_list_preserves_order(self):
        svc  = self._svc()
        hits = [make_hit("a", 0.9), make_hit("b", 0.7), make_hit("c", 0.5)]
        merged = svc._rrf_merge([hits, []])
        assert [h.doc_id for h in merged] == ["a", "b", "c"]

    def test_cache_key_format(self):
        svc = self._svc()
        key = svc._cache_key("pharmacy_1", "medicines", "paracetamol")
        assert key == "pharmacy_1:medicines:paracetamol"

    def test_cache_key_uses_normalized_query(self):
        svc  = self._svc()
        key1 = svc._cache_key("t1", "medicines", "para")
        key2 = svc._cache_key("t1", "medicines", "para")
        assert key1 == key2
