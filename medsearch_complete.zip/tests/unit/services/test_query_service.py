"""
tests/unit/services/test_query_service.py

Unit tests for QueryService — the NLP pipeline.

All tests use a mock SpellCorrector that returns input unchanged,
so we test classification logic in isolation from spell correction.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from medsearch.core.domain.search_query import QueryIntent, SearchLanguage
from medsearch.services.query_service import QueryService


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def corrector():
    """SpellCorrector that returns input unchanged."""
    mock = MagicMock()
    mock.correct.side_effect = lambda q: q   # passthrough
    return mock

@pytest.fixture
def svc(corrector):
    return QueryService(corrector)


# ---------------------------------------------------------------------------
# is_valid
# ---------------------------------------------------------------------------

class TestIsValid:
    def test_short_query_invalid(self, svc):
        assert svc.is_valid("p") is False

    def test_two_char_query_valid(self, svc):
        assert svc.is_valid("pa") is True

    def test_whitespace_only_invalid(self, svc):
        assert svc.is_valid("   ") is False


# ---------------------------------------------------------------------------
# Barcode detection
# ---------------------------------------------------------------------------

class TestBarcodeDetection:
    def test_8_digit_barcode(self, svc):
        pq = svc.parse("12345678")
        assert pq.intent == QueryIntent.BARCODE

    def test_13_digit_barcode(self, svc):
        pq = svc.parse("8901234567890")
        assert pq.intent == QueryIntent.BARCODE

    def test_14_digit_barcode(self, svc):
        pq = svc.parse("12345678901234")
        assert pq.intent == QueryIntent.BARCODE

    def test_7_digits_not_barcode(self, svc):
        pq = svc.parse("1234567")
        assert pq.intent != QueryIntent.BARCODE

    def test_barcode_skips_spell_correction(self, svc, corrector):
        svc.parse("8901234567890")
        corrector.correct.assert_not_called()


# ---------------------------------------------------------------------------
# Salt / strength intent
# ---------------------------------------------------------------------------

class TestSaltIntent:
    def test_mg_strength(self, svc):
        assert svc.parse("paracetamol 500mg").intent == QueryIntent.SALT

    def test_ml_strength(self, svc):
        assert svc.parse("amoxicillin 125ml").intent == QueryIntent.SALT

    def test_mcg_strength(self, svc):
        assert svc.parse("thyroxine 25mcg").intent == QueryIntent.SALT

    def test_percentage(self, svc):
        assert svc.parse("hydrogen peroxide 3%").intent == QueryIntent.SALT

    def test_hcl_suffix(self, svc):
        assert svc.parse("metformin hcl").intent == QueryIntent.SALT

    def test_hydrochloride(self, svc):
        assert svc.parse("cetirizine hydrochloride").intent == QueryIntent.SALT

    def test_no_strength_not_salt(self, svc):
        assert svc.parse("paracetamol").intent != QueryIntent.SALT


# ---------------------------------------------------------------------------
# Symptom intent
# ---------------------------------------------------------------------------

class TestSymptomIntent:
    def test_fever(self, svc):
        assert svc.parse("fever tablet").intent == QueryIntent.SYMPTOM

    def test_pain(self, svc):
        assert svc.parse("pain relief").intent == QueryIntent.SYMPTOM

    def test_cold_cough(self, svc):
        assert svc.parse("cold cough medicine").intent == QueryIntent.SYMPTOM

    def test_hinglish_bukhar(self, svc):
        pq = svc.parse("bukhar ki dawa", SearchLanguage.HI_IN)
        assert pq.intent == QueryIntent.SYMPTOM

    def test_hinglish_dard(self, svc):
        assert svc.parse("sar dard").intent == QueryIntent.SYMPTOM

    def test_acidity(self, svc):
        assert svc.parse("acidity gas").intent == QueryIntent.SYMPTOM

    def test_diabetes(self, svc):
        assert svc.parse("diabetes medicine").intent == QueryIntent.SYMPTOM

    def test_bp_abbreviation(self, svc):
        assert svc.parse("bp tablet").intent == QueryIntent.SYMPTOM


# ---------------------------------------------------------------------------
# Generic name intent
# ---------------------------------------------------------------------------

class TestGenericIntent:
    def test_statin_suffix(self, svc):
        assert svc.parse("rosuvastatin").intent == QueryIntent.GENERIC

    def test_pril_suffix(self, svc):
        assert svc.parse("enalapril").intent == QueryIntent.GENERIC

    def test_sartan_suffix(self, svc):
        assert svc.parse("losartan").intent == QueryIntent.GENERIC

    def test_zole_suffix(self, svc):
        assert svc.parse("omeprazole").intent == QueryIntent.GENERIC

    def test_oxacin_suffix(self, svc):
        assert svc.parse("ciprofloxacin").intent == QueryIntent.GENERIC

    def test_mab_suffix(self, svc):
        assert svc.parse("adalimumab").intent == QueryIntent.GENERIC


# ---------------------------------------------------------------------------
# Brand intent (default)
# ---------------------------------------------------------------------------

class TestBrandIntent:
    def test_brand_name(self, svc):
        assert svc.parse("calpol").intent == QueryIntent.BRAND

    def test_brand_with_numbers_not_strength(self, svc):
        # "crocin" has no mg/ml — should be BRAND
        assert svc.parse("crocin").intent == QueryIntent.BRAND

    def test_partial_name(self, svc):
        assert svc.parse("para").intent == QueryIntent.BRAND


# ---------------------------------------------------------------------------
# ParsedQuery fields
# ---------------------------------------------------------------------------

class TestParsedQueryFields:
    def test_original_preserved(self, svc):
        pq = svc.parse("  Paracetamol  ")
        assert pq.original == "  Paracetamol  "

    def test_normalized_stripped_lowercase(self, svc):
        pq = svc.parse("  Paracetamol  ")
        assert pq.normalized == "paracetamol"

    def test_tokens_from_corrected(self, svc):
        pq = svc.parse("cold fever")
        assert "cold" in pq.tokens
        assert "fever" in pq.tokens

    def test_language_passed_through(self, svc):
        pq = svc.parse("test", SearchLanguage.HI_IN)
        assert pq.language == SearchLanguage.HI_IN

    def test_spell_corrector_called_for_non_barcode(self, svc, corrector):
        svc.parse("parace")
        corrector.correct.assert_called_once_with("parace")

    def test_never_raises_on_bad_input(self, svc):
        # Even an empty string should not raise — returns passthrough
        pq = svc.parse("")
        assert pq is not None

    def test_salt_takes_priority_over_symptom(self, svc):
        # "fever 500mg" — salt pattern wins over symptom word
        pq = svc.parse("fever 500mg")
        assert pq.intent == QueryIntent.SALT


# ---------------------------------------------------------------------------
# Spell corrector integration
# ---------------------------------------------------------------------------

class TestSpellCorrectorIntegration:
    def test_corrected_field_reflects_correction(self):
        corrector = MagicMock()
        corrector.correct.return_value = "paracetamol"
        svc = QueryService(corrector)
        pq  = svc.parse("paracetamul")
        assert pq.corrected  == "paracetamol"
        assert pq.normalized == "paracetamul"
        assert pq.was_corrected is True

    def test_no_correction_was_corrected_false(self):
        corrector = MagicMock()
        corrector.correct.side_effect = lambda q: q
        svc = QueryService(corrector)
        pq  = svc.parse("calpol")
        assert pq.was_corrected is False
