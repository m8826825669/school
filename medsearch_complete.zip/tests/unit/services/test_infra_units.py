"""
tests/unit/services/test_infra_units.py

Unit tests for infra adapters.

All external dependencies (Redis, Typesense, Qdrant, LightGBM) are mocked.
These tests verify the adapter logic — filter building, response mapping,
error handling, fallback behaviour — without needing real services.
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from medsearch.core.domain.search_query import ParsedQuery, QueryIntent, SearchLanguage
from medsearch.core.domain.search_result import SearchHit, RankedHit


# ===========================================================================
# TypesenseEngine tests
# ===========================================================================

class TestTypesenseEngineFilters:
    """Test filter building logic — no network calls."""

    def _make_engine(self):
        from medsearch.infra.search.typesense_engine import TypesenseEngine
        settings = MagicMock()
        settings.typesense_host     = "localhost"
        settings.typesense_port     = "8108"
        settings.typesense_protocol = "http"
        settings.typesense_api_key  = "test"
        settings.typesense_connection_timeout = 2

        with patch("medsearch.infra.search.typesense_engine.typesense.Client"):
            return TypesenseEngine(settings)

    def test_build_filter_gt(self):
        engine = self._make_engine()
        result = engine._build_filter({"stock_qty": {"gt": 0}})
        assert result == "stock_qty:>0"

    def test_build_filter_eq(self):
        engine = self._make_engine()
        result = engine._build_filter({"category": {"eq": "antibiotic"}})
        assert result == "category:=antibiotic"

    def test_build_filter_multiple(self):
        engine = self._make_engine()
        result = engine._build_filter({"stock_qty": {"gt": 0}, "category": "tablet"})
        assert "stock_qty:>0" in result
        assert "category:=tablet" in result

    def test_build_filter_empty(self):
        engine = self._make_engine()
        assert engine._build_filter({}) == ""

    def test_collection_name_convention(self):
        engine = self._make_engine()
        assert engine._collection_name("pharmacy_1", "medicines") == "pharmacy_1__medicines"

    def test_normalize_score_caps_at_one(self):
        engine = self._make_engine()
        assert engine._normalize_score(2_000_000_000) == 1.0

    def test_normalize_score_zero(self):
        engine = self._make_engine()
        assert engine._normalize_score(0) == 0.0

    def test_to_hits_maps_correctly(self):
        engine = self._make_engine()
        raw = [{
            "document": {"id": "med_1", "name": "Paracetamol", "stock_qty": 10},
            "text_match": 500_000_000,
        }]
        hits = engine._to_hits(raw)
        assert len(hits) == 1
        assert hits[0].doc_id == "med_1"
        assert hits[0].source == "typesense"
        assert 0 < hits[0].score <= 1.0

    def test_barcode_query_triggers_barcode_search(self):
        engine = self._make_engine()
        pq = ParsedQuery.build(
            original="8901234567890",
            corrected="8901234567890",
            intent=QueryIntent.BARCODE,
        )
        assert pq.is_barcode is True


# ===========================================================================
# QdrantEngine tests
# ===========================================================================

class TestQdrantEngine:
    def _make_engine(self):
        from medsearch.infra.search.qdrant_engine import QdrantEngine
        settings = MagicMock()
        settings.qdrant_url           = "http://localhost:6333"
        settings.similarity_threshold = 0.35
        settings.embedding_dimensions = 384
        settings.qdrant_collection_hnsw_m        = 16
        settings.qdrant_collection_ef_construct  = 128

        embedder = AsyncMock()
        embedder.embed_one = AsyncMock(return_value=[0.1] * 384)

        with patch("medsearch.infra.search.qdrant_engine.AsyncQdrantClient"):
            return QdrantEngine(settings, embedder)

    def test_collection_name_convention(self):
        engine = self._make_engine()
        assert engine._collection_name("clinic_1", "doctors") == "clinic_1__doctors"

    def test_build_filter_gt(self):
        engine = self._make_engine()
        from qdrant_client.models import Filter
        result = engine._build_filter({"stock_qty": {"gt": 0}})
        assert isinstance(result, Filter)

    def test_build_filter_empty_returns_none(self):
        engine = self._make_engine()
        assert engine._build_filter({}) is None

    def test_doc_id_numeric_extracted(self):
        engine = self._make_engine()
        assert engine._doc_id_to_int("med_123") == 123

    def test_doc_id_hash_for_non_numeric(self):
        engine = self._make_engine()
        result = engine._doc_id_to_int("uuid-abc-def")
        assert isinstance(result, int)
        assert result >= 0

    def test_build_embed_text_combines_fields(self):
        engine = self._make_engine()
        doc    = {"name": "Calpol", "generic_name": "Paracetamol", "indications": "fever"}
        text   = engine._build_embed_text(doc)
        assert "Calpol" in text
        assert "Paracetamol" in text
        assert "fever" in text

    def test_build_embed_text_skips_empty_fields(self):
        engine = self._make_engine()
        doc    = {"name": "Calpol", "generic_name": "", "indications": None}
        text   = engine._build_embed_text(doc)
        assert text == "Calpol"

    def test_barcode_query_returns_empty(self):
        engine = self._make_engine()
        # Qdrant search is skipped for barcodes — verified via is_barcode flag
        pq = ParsedQuery.build(
            original="1234567890123",
            corrected="1234567890123",
            intent=QueryIntent.BARCODE,
        )
        assert pq.is_barcode is True


# ===========================================================================
# RedisStore tests
# ===========================================================================

class TestRedisStore:
    def _make_store(self):
        from medsearch.infra.cache.redis_store import RedisStore
        redis = AsyncMock()
        redis.ping.return_value = True
        return RedisStore(redis), redis

    @pytest.mark.asyncio
    async def test_get_returns_none_on_miss(self):
        store, redis = self._make_store()
        redis.get.return_value = None
        result = await store.get("missing_key")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_json_returns_dict(self):
        import json
        store, redis = self._make_store()
        redis.get.return_value = json.dumps({"name": "Calpol"}).encode()
        result = await store.get_json("key")
        assert result == {"name": "Calpol"}

    @pytest.mark.asyncio
    async def test_get_json_none_on_miss(self):
        store, redis = self._make_store()
        redis.get.return_value = None
        result = await store.get_json("missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_json_calls_setex(self):
        store, redis = self._make_store()
        await store.set_json("key", {"x": 1}, ttl=60)
        redis.setex.assert_called_once()
        args = redis.setex.call_args[0]
        assert args[0] == "key"
        assert args[1] == 60

    @pytest.mark.asyncio
    async def test_get_does_not_raise_on_redis_error(self):
        store, redis = self._make_store()
        redis.get.side_effect = ConnectionError("Redis down")
        result = await store.get("key")
        assert result is None  # swallowed, never propagated

    @pytest.mark.asyncio
    async def test_health_returns_true(self):
        store, _ = self._make_store()
        assert await store.health() is True

    @pytest.mark.asyncio
    async def test_health_returns_false_on_error(self):
        store, redis = self._make_store()
        redis.ping.side_effect = ConnectionError
        assert await store.health() is False

    @pytest.mark.asyncio
    async def test_delete_pattern_uses_scan(self):
        store, redis = self._make_store()
        redis.scan.return_value = (0, [b"key1", b"key2"])
        await store.delete_pattern("pharmacy_1__medicines:*")
        redis.scan.assert_called_once()
        redis.delete.assert_called_once()


# ===========================================================================
# LGBMRanker tests
# ===========================================================================

class TestLGBMRanker:
    def _make_hit(self, doc_id: str = "med_1", score: float = 0.9, stock: int = 5) -> SearchHit:
        return SearchHit(
            doc_id=doc_id, score=score,
            payload={"name": "Paracetamol", "stock_qty": stock, "price": 20.0},
            source="typesense",
        )

    def _make_query(self) -> ParsedQuery:
        return ParsedQuery.passthrough("paracetamol")

    def test_is_ready_false_without_model_file(self, tmp_path):
        from medsearch.infra.ml.lgbm_ranker import LGBMRanker
        ranker = LGBMRanker(str(tmp_path / "nonexistent.lgb"))
        assert ranker.is_ready is False

    def test_rerank_passthrough_when_not_ready(self, tmp_path):
        from medsearch.infra.ml.lgbm_ranker import LGBMRanker
        ranker = LGBMRanker(str(tmp_path / "nonexistent.lgb"))
        hits   = [self._make_hit("1", 0.9), self._make_hit("2", 0.7)]
        result = ranker.rerank(self._make_query(), hits, {})
        assert len(result) == 2
        assert all(isinstance(r, RankedHit) for r in result)
        assert result[0].rank_reason == "rrf_fallback"

    def test_rerank_empty_returns_empty(self, tmp_path):
        from medsearch.infra.ml.lgbm_ranker import LGBMRanker
        ranker = LGBMRanker(str(tmp_path / "nonexistent.lgb"))
        result = ranker.rerank(self._make_query(), [], {})
        assert result == []

    def test_feature_matrix_shape(self, tmp_path):
        from medsearch.infra.ml.lgbm_ranker import LGBMRanker, _FEATURE_COLS
        ranker = LGBMRanker(str(tmp_path / "nonexistent.lgb"))
        hits   = [self._make_hit("1"), self._make_hit("2")]
        matrix = ranker._build_features(self._make_query(), hits, {})
        assert matrix.shape == (2, len(_FEATURE_COLS))

    def test_exact_name_match_feature(self, tmp_path):
        from medsearch.infra.ml.lgbm_ranker import LGBMRanker, _FEATURE_COLS
        ranker   = LGBMRanker(str(tmp_path / "nonexistent.lgb"))
        hit      = SearchHit(doc_id="1", score=0.9,
                             payload={"name": "paracetamol", "stock_qty": 5, "price": 10.0},
                             source="typesense")
        query    = ParsedQuery.passthrough("paracetamol")
        matrix   = ranker._build_features(query, [hit], {})
        exact_idx = _FEATURE_COLS.index("exact_name_match")
        assert matrix[0, exact_idx] == 1.0


# ===========================================================================
# PhoneticMatcher tests
# ===========================================================================

class TestPhoneticMatcher:
    def _matcher_with_data(self):
        from medsearch.infra.nlp.phonetic import PhoneticMatcher
        m = PhoneticMatcher()
        try:
            m.build([("Calpol", "med_1"), ("Crocin", "med_2"), ("Amoxicillin", "med_3")])
        except ImportError:
            pytest.skip("jellyfish not installed")
        return m

    def test_build_populates_index(self):
        m = self._matcher_with_data()
        assert len(m._index) > 0

    def test_find_matches_phonetic_variant(self):
        m = self._matcher_with_data()
        results = m.find_matches("Kalpol")   # phonetic variant of Calpol
        # May or may not match depending on Metaphone encoding — just verify no crash
        assert isinstance(results, list)

    def test_remove_clears_doc_id(self):
        m = self._matcher_with_data()
        m.remove("med_1")
        for entries in m._index.values():
            for _, doc_id in entries:
                assert doc_id != "med_1"

    def test_find_matches_returns_list_on_no_match(self):
        m = self._matcher_with_data()
        results = m.find_matches("zzzzxxx999")
        assert isinstance(results, list)


# ===========================================================================
# SpellCorrector tests
# ===========================================================================

class TestSpellCorrector:
    def _corrector(self):
        from medsearch.infra.nlp.spell_corrector import SpellCorrector
        try:
            return SpellCorrector.build_from_wordlist(
                ["paracetamol", "amoxicillin", "calpol", "metformin", "omeprazole"]
            )
        except ImportError:
            pytest.skip("symspellpy not installed")

    def test_correct_known_word_unchanged(self):
        c = self._corrector()
        assert c.correct("paracetamol") == "paracetamol"

    def test_correct_short_tokens_unchanged(self):
        c = self._corrector()
        assert c.correct("OD") == "od"  # normalised to lowercase, not corrected

    def test_correct_returns_string(self):
        c = self._corrector()
        result = c.correct("amoxicilin")
        assert isinstance(result, str)

    def test_correct_empty_string(self):
        c = self._corrector()
        assert c.correct("") == ""

    def test_add_word_does_not_raise(self):
        c = self._corrector()
        c.add_word("newmedicine500mg")  # should not raise
