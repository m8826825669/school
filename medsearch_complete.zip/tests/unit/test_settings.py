"""
tests/unit/test_settings.py

Tests for Settings — the only test that's allowed to care about
environment variables. All other tests get settings injected.
"""

import pytest
from pydantic import ValidationError

from medsearch.settings import Settings


def _base_env() -> dict:
    """Minimum valid environment."""
    return {
        "secret_key": "a" * 32,
        "database_url": "postgresql+asyncpg://u:p@localhost/db",
        "typesense_api_key": "test_key",
    }


def test_settings_loads_with_minimum_env(monkeypatch):
    env = _base_env()
    for k, v in env.items():
        monkeypatch.setenv(k.upper(), v)

    s = Settings()
    assert s.app_env == "development"
    assert s.app_port == 8001
    assert s.embedding_dimensions == 384


def test_settings_rejects_short_secret_key(monkeypatch):
    env = _base_env()
    env["secret_key"] = "tooshort"
    for k, v in env.items():
        monkeypatch.setenv(k.upper(), v)

    with pytest.raises(ValidationError, match="secret_key"):
        Settings()


def test_is_production_flag(monkeypatch):
    env = _base_env()
    env["app_env"] = "production"
    for k, v in env.items():
        monkeypatch.setenv(k.upper(), v)

    s = Settings()
    assert s.is_production is True
    assert s.is_development is False


def test_cors_origins_parsed_from_comma_string(monkeypatch):
    env = _base_env()
    env["cors_origins"] = "http://localhost:3000,http://localhost:8000"
    for k, v in env.items():
        monkeypatch.setenv(k.upper(), v)

    s = Settings()
    assert "http://localhost:3000" in s.cors_origins_list
    assert len(s.cors_origins_list) == 2


def test_typesense_host_extracted_correctly(monkeypatch):
    env = _base_env()
    env["typesense_url"] = "http://typesense:8108"
    for k, v in env.items():
        monkeypatch.setenv(k.upper(), v)

    s = Settings()
    assert s.typesense_host == "typesense"
    assert s.typesense_port == "8108"
    assert s.typesense_protocol == "http"
