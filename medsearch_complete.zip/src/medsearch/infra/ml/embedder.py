"""
infra/ml/embedder.py

Sentence-transformers embedding adapter — implements IEmbedder.

The model is CPU-bound. We run it inside asyncio's default thread pool
via run_in_executor so it never blocks the event loop.

Model choice (all-MiniLM-L6-v2):
  - 384 dimensions — small enough for fast ANN search
  - 80MB on disk — loads in < 2 seconds at startup
  - 5ms per query encoding on CPU — acceptable for our latency budget
  - Strong multilingual base — handles Hinglish better than domain-specific models
"""

from __future__ import annotations

import asyncio
import functools
import structlog
from typing import Any

log = structlog.get_logger(__name__)


class SentenceEmbedder:
    """
    Embedding adapter backed by sentence-transformers.
    Satisfies IEmbedder protocol — no explicit inheritance needed.

    Loaded once at application startup via the dependency container.
    The model object is shared across all requests — it's stateless.
    """

    def __init__(self, model_name: str, batch_size: int = 64) -> None:
        self._model_name = model_name
        self._batch_size = batch_size
        self._model: Any = None
        self._dims: int  = 384  # default; updated after model loads

    def load(self) -> "SentenceEmbedder":
        """
        Load the model from disk (or HuggingFace cache).
        Called once at startup — blocks until model is ready.
        Returns self for chaining: embedder = SentenceEmbedder(...).load()
        """
        # Import here so the module loads fast even if sentence-transformers
        # is not installed (allows tests to mock this class without the dep)
        from sentence_transformers import SentenceTransformer  # type: ignore[import]

        log.info("embedder.loading", model=self._model_name)
        self._model = SentenceTransformer(self._model_name)
        self._dims  = self._model.get_sentence_embedding_dimension()
        log.info("embedder.ready", model=self._model_name, dimensions=self._dims)
        return self

    # -------------------------------------------------------------------------
    # IEmbedder: embed
    # -------------------------------------------------------------------------

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Encode a batch of texts.

        Runs sentence-transformers encode() in the default thread pool
        so the event loop is never blocked during encoding.
        """
        if not texts:
            return []

        loop = asyncio.get_running_loop()
        encode_fn = functools.partial(
            self._model.encode,
            texts,
            batch_size   = self._batch_size,
            show_progress_bar = False,
            convert_to_numpy  = True,
        )
        vectors = await loop.run_in_executor(None, encode_fn)
        return [v.tolist() for v in vectors]

    # -------------------------------------------------------------------------
    # IEmbedder: embed_one
    # -------------------------------------------------------------------------

    async def embed_one(self, text: str) -> list[float]:
        """Encode a single text — used for query encoding at search time."""
        results = await self.embed([text])
        return results[0]

    # -------------------------------------------------------------------------
    # IEmbedder: dimensions property
    # -------------------------------------------------------------------------

    @property
    def dimensions(self) -> int:
        return self._dims

    @property
    def is_loaded(self) -> bool:
        return self._model is not None
