"""
infra/ml/lgbm_ranker.py

LightGBM LambdaRank re-ranker — implements IRanker.

Responsibilities (this file only):
  - Load a pre-trained LightGBM model from disk
  - Build a feature matrix from candidates + context
  - Score and reorder candidates into RankedHit objects
  - Fall back to RRF score ordering if model not loaded

Feature engineering is in _build_features(). Adding a new ranking signal
means adding one column here — no other files change.

The model is retrained weekly via scripts/train_ranker.py using SearchEvent
logs. The new model is hot-swapped via LGBMRanker.reload() without restart.
"""

from __future__ import annotations

import os
import time
import structlog
from datetime import datetime, timezone
from typing import Any

import numpy as np

from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import RankedHit, SearchHit

log = structlog.get_logger(__name__)

# Feature column names — must stay in sync with training script
_FEATURE_COLS = [
    # Relevance signals (from search engines)
    "bm25_score",
    "vector_score",
    "is_typesense_hit",
    "is_qdrant_hit",
    "exact_name_match",
    "prefix_match",
    # Inventory signals
    "stock_qty_capped",
    "is_in_stock",
    # Sales velocity
    "sales_7d",
    "sales_30d",
    # Business signals
    "margin_pct",
    "price_log",
    # Context signals
    "hour_of_day",
    "user_prev_selected",
]


class LGBMRanker:
    """
    ML re-ranker backed by LightGBM.
    Satisfies IRanker protocol — no explicit inheritance needed.

    The model is loaded once at startup. If the model file is missing
    (e.g. fresh dev environment), is_ready returns False and the ranker
    returns candidates ordered by their RRF score unchanged.
    """

    def __init__(self, model_path: str) -> None:
        self._model_path = model_path
        self._model: Any = None
        self._loaded_at: datetime | None = None

    @classmethod
    def load(cls, model_path: str) -> "LGBMRanker":
        """Factory that loads the model immediately."""
        ranker = cls(model_path)
        ranker._try_load()
        return ranker

    def _try_load(self) -> None:
        if not os.path.exists(self._model_path):
            log.warning(
                "ranker.model_not_found",
                path=self._model_path,
                fallback="rrf_score_order",
            )
            return
        try:
            import lightgbm as lgb  # type: ignore[import]
            self._model    = lgb.Booster(model_file=self._model_path)
            self._loaded_at = datetime.now(timezone.utc)
            log.info("ranker.loaded", path=self._model_path)
        except Exception as exc:
            log.error("ranker.load_failed", error=str(exc))

    def reload(self) -> None:
        """Hot-swap the model file without restarting the process."""
        log.info("ranker.reloading", path=self._model_path)
        self._model = None
        self._try_load()

    # -------------------------------------------------------------------------
    # IRanker: rerank
    # -------------------------------------------------------------------------

    def rerank(
        self,
        query:      ParsedQuery,
        candidates: list[SearchHit],
        context:    dict[str, Any],
    ) -> list[RankedHit]:
        if not candidates:
            return []

        # No model → passthrough with hit score as rank_score
        if not self.is_ready:
            return [
                RankedHit(hit=h, rank_score=h.score, rank_reason="rrf_fallback")
                for h in candidates
            ]

        try:
            features = self._build_features(query, candidates, context)
            scores   = self._model.predict(features)

            ranked = sorted(
                zip(candidates, scores),
                key    = lambda x: x[1],
                reverse= True,
            )
            return [
                RankedHit(hit=hit, rank_score=float(score), rank_reason="lgbm")
                for hit, score in ranked
            ]
        except Exception as exc:
            log.error("ranker.rerank_failed", error=str(exc))
            # Safe fallback — never raise
            return [
                RankedHit(hit=h, rank_score=h.score, rank_reason="error_fallback")
                for h in candidates
            ]

    # -------------------------------------------------------------------------
    # IRanker: is_ready property
    # -------------------------------------------------------------------------

    @property
    def is_ready(self) -> bool:
        return self._model is not None

    # -------------------------------------------------------------------------
    # Feature engineering
    # -------------------------------------------------------------------------

    def _build_features(
        self,
        query:      ParsedQuery,
        candidates: list[SearchHit],
        context:    dict[str, Any],
    ) -> np.ndarray:
        """
        Build [n_candidates × n_features] matrix for LightGBM inference.

        Each row is one candidate hit. Feature values are all numeric.
        New ranking signals should be added as new columns here and
        retrained in scripts/train_ranker.py.
        """
        hour        = context.get("hour", datetime.now(timezone.utc).hour)
        prev_ids    = set(context.get("user_prev_selected_ids", []))
        query_lower = query.corrected.lower()
        boost       = context.get("boost", {})

        rows: list[list[float]] = []
        for hit in candidates:
            name       = hit.name.lower()
            stock      = hit.stock_qty
            sales_7d   = float(hit.get("sales_7d",   0))
            sales_30d  = float(hit.get("sales_30d",  0))
            margin     = float(hit.get("margin_pct", 0))
            price      = float(hit.price)

            row = [
                # --- Relevance signals ---
                hit.score if hit.source == "typesense" else 0.0,  # bm25_score
                hit.score if hit.source == "qdrant"    else 0.0,  # vector_score
                1.0 if hit.source == "typesense"       else 0.0,  # is_typesense_hit
                1.0 if hit.source == "qdrant"          else 0.0,  # is_qdrant_hit
                1.0 if name == query_lower             else 0.0,  # exact_name_match
                1.0 if name.startswith(query_lower)    else 0.0,  # prefix_match

                # --- Inventory ---
                min(float(stock), 1000.0),                        # stock_qty_capped
                1.0 if stock > 0                       else 0.0,  # is_in_stock

                # --- Sales velocity ---
                min(sales_7d,  500.0),                            # sales_7d
                min(sales_30d, 2000.0),                           # sales_30d

                # --- Business ---
                min(margin, 100.0),                               # margin_pct
                float(np.log1p(price)),                           # price_log

                # --- Context ---
                float(hour),                                      # hour_of_day
                1.0 if hit.doc_id in prev_ids          else 0.0,  # user_prev_selected
            ]

            # Apply caller-specified boosts
            for field, multiplier in boost.items():
                val = hit.get(field)
                if val is not None:
                    row[0] *= float(multiplier)  # boost bm25 score column

            rows.append(row)

        return np.array(rows, dtype=np.float32)
