"""
infra/nlp/phonetic.py

Phonetic matching adapter using Metaphone + Jaro-Winkler similarity.

Why phonetic matching for a pharmacy?
  Indian pharmacists often transliterate medicine names from Hindi pronunciation:
    "Calpol"  → typed as "Kalpol"
    "Omez"    → typed as "Omej"
    "Combiflam" → typed as "Kombiplam"

  Standard spell correction handles simple typos but misses phonetic variants.
  This adapter catches them with:
    1. Metaphone encoding  → groups phonetically similar words
    2. Jaro-Winkler score  → fuzzy string similarity (good for short medical names)

The phonetic index is built in-memory from the medicine catalog at startup.
It's fast enough (< 500K medicines → < 50MB) and avoids a Redis roundtrip.
"""

from __future__ import annotations

import structlog
from collections import defaultdict
from typing import Any

log = structlog.get_logger(__name__)

_JW_THRESHOLD = 0.85  # minimum Jaro-Winkler score to consider a match


class PhoneticMatcher:
    """
    In-memory phonetic index over medicine names.

    Built once at startup. Lookup is O(1) on Metaphone key + O(M) Jaro-Winkler
    where M is the number of words sharing the same Metaphone code (usually < 20).
    """

    def __init__(self) -> None:
        # metaphone_key → list of (original_name, doc_id)
        self._index: dict[str, list[tuple[str, str]]] = defaultdict(list)
        self._name_to_id: dict[str, str] = {}

    # -------------------------------------------------------------------------
    # Build
    # -------------------------------------------------------------------------

    def build(self, entries: list[tuple[str, str]]) -> None:
        """
        Build the phonetic index from (name, doc_id) pairs.
        Called by IndexService during initial seeding and tenant onboarding.
        """
        self._index.clear()
        self._name_to_id.clear()

        for name, doc_id in entries:
            self._add_entry(name, doc_id)

        log.info("phonetic.index_built", entries=len(entries))

    def add(self, name: str, doc_id: str) -> None:
        """Add one entry (called on each medicine upsert)."""
        self._add_entry(name, doc_id)

    def remove(self, doc_id: str) -> None:
        """Remove all entries for a given doc_id."""
        for key in list(self._index.keys()):
            self._index[key] = [
                (n, d) for n, d in self._index[key] if d != doc_id
            ]
        self._name_to_id = {n: d for n, d in self._name_to_id.items() if d != doc_id}

    # -------------------------------------------------------------------------
    # Lookup
    # -------------------------------------------------------------------------

    def find_matches(self, query: str, limit: int = 10) -> list[str]:
        """
        Return doc_ids whose names are phonetically similar to query.

        Two-stage:
          1. Exact Metaphone key match (very fast)
          2. Jaro-Winkler similarity on all candidates from stage 1
        """
        try:
            import jellyfish  # type: ignore[import]
        except ImportError:
            log.warning("phonetic.jellyfish_not_installed")
            return []

        query_clean = query.strip().lower()
        query_meta  = self._safe_metaphone(query_clean, jellyfish)

        # Stage 1: Metaphone key lookup
        candidates  = self._index.get(query_meta, [])

        # Stage 2: Jaro-Winkler filter + sort by similarity
        scored: list[tuple[float, str]] = []
        for name, doc_id in candidates:
            sim = jellyfish.jaro_winkler_similarity(query_clean, name.lower())
            if sim >= _JW_THRESHOLD:
                scored.append((sim, doc_id))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc_id for _, doc_id in scored[:limit]]

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _add_entry(self, name: str, doc_id: str) -> None:
        try:
            import jellyfish  # type: ignore[import]
        except ImportError:
            return

        name_lc = name.strip().lower()
        meta    = self._safe_metaphone(name_lc, jellyfish)
        self._index[meta].append((name_lc, doc_id))
        self._name_to_id[name_lc] = doc_id

    def _safe_metaphone(self, text: str, jellyfish: Any) -> str:
        """Return Metaphone code or the original text on failure."""
        try:
            return jellyfish.metaphone(text) or text
        except Exception:
            return text
