"""
infra/nlp/spell_corrector.py

SymSpell spell corrector for medicine query terms.

Why SymSpell over Levenshtein or difflib?
  - O(1) lookup regardless of dictionary size — 1000x faster than Levenshtein
  - Handles up to edit distance 2 (covers most medical typos)
  - Custom dictionary built from your medicine catalog
    → "amoxicilin" → "amoxicillin"  (not a generic English correction)

The corrector is initialised once at startup by loading a persisted
pickle or rebuilding from the medicine catalog.
The dictionary is a superset: standard English terms + all medicine names,
generic names, and salt compositions from the DB.
"""

from __future__ import annotations

import os
import pickle
import structlog
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from symspellpy import SymSpell  # type: ignore[import]

log = structlog.get_logger(__name__)

_CACHE_PATH     = "models/symspell.pkl"
_MAX_EDIT_DIST  = 2
_PREFIX_LEN     = 7


class SpellCorrector:
    """
    Spell correction adapter backed by SymSpell.

    Usage:
        corrector = SpellCorrector.build_from_wordlist(["paracetamol", "amoxicillin", ...])
        corrected = corrector.correct("amoxicilin")  # → "amoxicillin"
    """

    def __init__(self) -> None:
        self._sym: "SymSpell | None" = None

    # -------------------------------------------------------------------------
    # Factories
    # -------------------------------------------------------------------------

    @classmethod
    def load_or_build(cls, wordlist: list[str]) -> "SpellCorrector":
        """
        Load from cache file if it exists, otherwise build from wordlist.
        Saves to cache after building.
        """
        corrector = cls()
        if os.path.exists(_CACHE_PATH):
            try:
                corrector._load_from_cache()
                return corrector
            except Exception as exc:
                log.warning("spellcheck.cache_load_failed", error=str(exc))

        corrector._build_from_wordlist(wordlist)
        corrector._save_to_cache()
        return corrector

    @classmethod
    def build_from_wordlist(cls, wordlist: list[str]) -> "SpellCorrector":
        """Build fresh without cache — useful in tests."""
        corrector = cls()
        corrector._build_from_wordlist(wordlist)
        return corrector

    # -------------------------------------------------------------------------
    # Core correction
    # -------------------------------------------------------------------------

    def correct(self, query: str) -> str:
        """
        Correct a full query string word-by-word.

        Each token is corrected independently. Tokens that are already
        in the dictionary pass through unchanged. Unknown short tokens
        (< 4 chars) are not corrected to avoid false positives.

        Returns the corrected query or the original on any failure.
        """
        if self._sym is None:
            return query

        try:
            tokens    = query.strip().lower().split()
            corrected = [self._correct_token(tok) for tok in tokens]
            return " ".join(corrected)
        except Exception as exc:
            log.warning("spellcheck.correct_failed", query=query, error=str(exc))
            return query

    def _correct_token(self, token: str) -> str:
        """Correct a single token. Short tokens pass through unchanged."""
        # Don't correct: barcodes, numbers, very short words
        if len(token) < 4 or token.isdigit():
            return token

        from symspellpy import Verbosity  # type: ignore[import]

        suggestions = self._sym.lookup(  # type: ignore[union-attr]
            token,
            Verbosity.CLOSEST,
            max_edit_distance=_MAX_EDIT_DIST,
        )
        if suggestions:
            return suggestions[0].term
        return token

    def add_word(self, word: str) -> None:
        """
        Add a word to the dictionary at runtime.
        Used when a new medicine is added to the catalog.
        """
        if self._sym and word.strip():
            self._sym.create_dictionary_entry(word.strip().lower(), 1)

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _build_from_wordlist(self, wordlist: list[str]) -> None:
        from symspellpy import SymSpell  # type: ignore[import]

        self._sym = SymSpell(
            max_dictionary_edit_distance=_MAX_EDIT_DIST,
            prefix_length=_PREFIX_LEN,
        )
        # Load standard English dictionary first
        try:
            from importlib.resources import files  # Python 3.9+
            dict_path = str(
                files("symspellpy").joinpath("frequency_dictionary_en_82_765.txt")
            )
            self._sym.load_dictionary(dict_path, term_index=0, count_index=1)
        except Exception:
            pass  # Standard dict not critical — medicine terms are enough

        # Add every medicine name, generic, salt as domain terms
        added = 0
        for word in wordlist:
            if not word:
                continue
            for part in word.lower().split():
                if len(part) >= 3:
                    self._sym.create_dictionary_entry(part, 1)
                    added += 1

        log.info("spellcheck.built", terms=added)

    def _save_to_cache(self) -> None:
        os.makedirs(os.path.dirname(_CACHE_PATH), exist_ok=True)
        try:
            with open(_CACHE_PATH, "wb") as f:
                pickle.dump(self._sym, f)
            log.info("spellcheck.cache_saved", path=_CACHE_PATH)
        except Exception as exc:
            log.warning("spellcheck.cache_save_failed", error=str(exc))

    def _load_from_cache(self) -> None:
        with open(_CACHE_PATH, "rb") as f:
            self._sym = pickle.load(f)  # noqa: S301
        log.info("spellcheck.cache_loaded", path=_CACHE_PATH)
