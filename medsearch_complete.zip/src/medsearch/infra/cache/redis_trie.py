"""
infra/cache/redis_trie.py

Autocomplete adapter using Redis Sorted Sets as a prefix trie.

How it works:
  - All prefixes of every medicine name are inserted into a sorted set
    with score 0 (lexicographic ordering does the work).
  - At query time, ZRANGEBYLEX finds all members starting with the prefix
    in O(log N) — no DB touch needed.
  - Full names are stored as "name|doc_id" entries so results carry IDs.

Example (after indexing "paracetamol|med_1"):
  Set key:  "pharmacy_1__medicines:autocomplete"
  Members:  "pa", "par", "para", "parac", ..., "paracetamol", "paracetamol|med_1"

Query "para" → all members in ["para", "parb") → ["para", "parac", ..., "paracetamol|med_1"]
Filter for entries containing "|" → ["paracetamol|med_1"]
"""

from __future__ import annotations

import structlog
from redis.asyncio import Redis

log = structlog.get_logger(__name__)

_SEPARATOR = "|"


class RedisTrie:
    """Prefix-based autocomplete using Redis sorted sets."""

    def __init__(self, redis: Redis, ttl: int = 86400) -> None:
        self._redis = redis
        self._ttl   = ttl  # seconds before the trie key expires

    def _key(self, tenant_id: str, index: str) -> str:
        return f"{tenant_id}__{index}:autocomplete"

    # -------------------------------------------------------------------------
    # Build / update
    # -------------------------------------------------------------------------

    async def add(self, tenant_id: str, index: str, name: str, doc_id: str) -> None:
        """
        Add one medicine name to the autocomplete trie.
        Called by IndexService after every upsert.
        """
        key      = self._key(tenant_id, index)
        name_lc  = name.strip().lower()
        members: dict[str, float] = {}

        # All prefixes of this name (min length 2)
        for i in range(2, len(name_lc) + 1):
            members[name_lc[:i]] = 0

        # Full name with doc_id reference
        members[f"{name_lc}{_SEPARATOR}{doc_id}"] = 0

        try:
            await self._redis.zadd(key, members)
            await self._redis.expire(key, self._ttl)
        except Exception as exc:
            log.warning("trie.add_failed", name=name, error=str(exc))

    async def remove(self, tenant_id: str, index: str, doc_id: str) -> None:
        """Remove all entries associated with a doc_id."""
        key = self._key(tenant_id, index)
        try:
            # Scan for members containing the doc_id
            cursor: int = 0
            to_remove: list[str] = []
            while True:
                cursor, members = await self._redis.zscan(
                    key, cursor=cursor, match=f"*{_SEPARATOR}{doc_id}"
                )
                to_remove.extend(m.decode() if isinstance(m, bytes) else m
                                 for m, _ in members)
                if cursor == 0:
                    break
            if to_remove:
                await self._redis.zrem(key, *to_remove)
        except Exception as exc:
            log.warning("trie.remove_failed", doc_id=doc_id, error=str(exc))

    async def rebuild(
        self,
        tenant_id: str,
        index:     str,
        entries:   list[tuple[str, str]],   # [(name, doc_id), ...]
    ) -> None:
        """
        Full rebuild of the autocomplete index.
        Called by scripts/build_index.py during initial seeding.
        Deletes existing key first to avoid stale entries.
        """
        key = self._key(tenant_id, index)
        await self._redis.delete(key)

        # Batch in chunks of 500 to avoid huge pipeline
        chunk_size = 500
        for i in range(0, len(entries), chunk_size):
            chunk   = entries[i : i + chunk_size]
            members: dict[str, float] = {}

            for name, doc_id in chunk:
                name_lc = name.strip().lower()
                for j in range(2, len(name_lc) + 1):
                    members[name_lc[:j]] = 0
                members[f"{name_lc}{_SEPARATOR}{doc_id}"] = 0

            try:
                await self._redis.zadd(key, members)
            except Exception as exc:
                log.error("trie.rebuild_chunk_failed", error=str(exc))

        await self._redis.expire(key, self._ttl)
        log.info("trie.rebuilt", tenant_id=tenant_id, index=index, entries=len(entries))

    # -------------------------------------------------------------------------
    # Query
    # -------------------------------------------------------------------------

    async def suggest(
        self,
        tenant_id: str,
        index:     str,
        prefix:    str,
        limit:     int = 8,
    ) -> list[str]:
        """
        Return up to `limit` medicine names starting with `prefix`.

        Redis ZRANGEBYLEX returns members in lexicographic order between
        [prefix and (next_prefix (exclusive upper bound).

        Returns list of names (without the "|doc_id" suffix).
        """
        key        = self._key(tenant_id, index)
        prefix_lc  = prefix.strip().lower()
        # Upper bound: replace last char with next unicode char
        upper      = prefix_lc[:-1] + chr(ord(prefix_lc[-1]) + 1)

        try:
            raw: list[bytes] = await self._redis.zrangebylex(
                key,
                f"[{prefix_lc}",
                f"({upper}",
                offset=0,
                count=limit * 10,  # oversample; filter below
            )
        except Exception as exc:
            log.warning("trie.suggest_failed", prefix=prefix, error=str(exc))
            return []

        # Keep only full-name entries (those containing the separator)
        suggestions: list[str] = []
        for member in raw:
            text = member.decode() if isinstance(member, bytes) else member
            if _SEPARATOR in text:
                name = text.split(_SEPARATOR)[0]
                if name not in suggestions:
                    suggestions.append(name)
            if len(suggestions) >= limit:
                break

        return suggestions
