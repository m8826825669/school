"""
infra/cache/redis_store.py

Redis cache adapter — implements ICacheStore.

Responsibilities (this file only):
  - Raw bytes get/set/delete with TTL
  - JSON serialisation convenience wrappers
  - Pattern-based key deletion for invalidation
  - Health check

The search_service uses set_json / get_json exclusively.
Raw bytes methods exist for lower-level callers (e.g. session tokens).
"""

from __future__ import annotations

import json
import structlog
from typing import Any

from redis.asyncio import Redis

log = structlog.get_logger(__name__)


class RedisStore:
    """
    Cache adapter backed by Redis.
    Satisfies ICacheStore protocol — no explicit inheritance needed.
    """

    def __init__(self, redis: Redis) -> None:
        self._redis = redis

    # -------------------------------------------------------------------------
    # ICacheStore: raw bytes
    # -------------------------------------------------------------------------

    async def get(self, key: str) -> bytes | None:
        try:
            return await self._redis.get(key)
        except Exception as exc:
            log.warning("redis.get_failed", key=key, error=str(exc))
            return None

    async def set(self, key: str, value: bytes, ttl: int = 120) -> None:
        try:
            await self._redis.setex(key, ttl, value)
        except Exception as exc:
            log.warning("redis.set_failed", key=key, error=str(exc))

    async def delete(self, key: str) -> None:
        try:
            await self._redis.delete(key)
        except Exception as exc:
            log.warning("redis.delete_failed", key=key, error=str(exc))

    async def delete_pattern(self, pattern: str) -> None:
        """
        Scan + delete all keys matching the glob pattern.

        Uses SCAN (not KEYS) to avoid blocking Redis on large key sets.
        Called on medicine upsert to invalidate tenant search caches.

        Example patterns:
          "pharmacy_1__medicines:*"  — all medicine searches for tenant
          "clinic_1__doctors:*"      — all doctor searches for tenant
        """
        try:
            cursor: int = 0
            deleted  = 0
            while True:
                cursor, keys = await self._redis.scan(
                    cursor=cursor, match=pattern, count=100
                )
                if keys:
                    await self._redis.delete(*keys)
                    deleted += len(keys)
                if cursor == 0:
                    break
            if deleted:
                log.debug("redis.pattern_deleted", pattern=pattern, count=deleted)
        except Exception as exc:
            log.warning("redis.delete_pattern_failed", pattern=pattern, error=str(exc))

    # -------------------------------------------------------------------------
    # ICacheStore: JSON helpers
    # -------------------------------------------------------------------------

    async def get_json(self, key: str) -> dict[str, Any] | None:
        raw = await self.get(key)
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            log.warning("redis.json_decode_failed", key=key, error=str(exc))
            await self.delete(key)  # remove corrupt entry
            return None

    async def set_json(
        self,
        key:   str,
        value: dict[str, Any],
        ttl:   int = 120,
    ) -> None:
        try:
            encoded = json.dumps(value, default=str).encode()
            await self.set(key, encoded, ttl)
        except (TypeError, ValueError) as exc:
            log.warning("redis.json_encode_failed", key=key, error=str(exc))

    # -------------------------------------------------------------------------
    # ICacheStore: health
    # -------------------------------------------------------------------------

    async def health(self) -> bool:
        try:
            return await self._redis.ping()
        except Exception:
            return False
