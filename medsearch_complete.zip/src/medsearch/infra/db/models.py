"""
infra/db/models.py

SQLAlchemy ORM table definitions.

Tables:
  tenants       — one row per client application / pharmacy branch
  api_keys      — credentials for authenticating to the search API
  search_events — one row per search request (ML training data)

Design decisions:
  - UUID primary keys for tenants and api_keys (no sequential ID leakage)
  - search_events uses BIGINT auto-increment (high volume, never exposed)
  - Indexes on the hot lookup paths: api_key_hash, tenant_id+created_at
  - No ForeignKey cascade on search_events.tenant_id — analytics should
    survive tenant deletion
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Float,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Tenant
# ---------------------------------------------------------------------------

class TenantModel(Base):
    __tablename__ = "tenants"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    tenant_id:       Mapped[str]  = mapped_column(String(100), nullable=False, unique=True)
    display_name:    Mapped[str]  = mapped_column(String(200), nullable=False)
    allowed_indexes: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    is_active:       Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at:      Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False,
        server_default=func.now(),
    )

    __table_args__ = (
        Index("ix_tenants_tenant_id", "tenant_id"),
    )


# ---------------------------------------------------------------------------
# API Key
# ---------------------------------------------------------------------------

class ApiKeyModel(Base):
    __tablename__ = "api_keys"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    tenant_id:   Mapped[str]  = mapped_column(String(100), nullable=False)
    hashed_key:  Mapped[str]  = mapped_column(String(200), nullable=False, unique=True)
    is_active:   Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    rate_limit:  Mapped[int]  = mapped_column(Integer, nullable=False, default=300)
    created_at:  Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False,
        server_default=func.now(),
    )
    expires_at:  Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_api_keys_hashed_key", "hashed_key"),
        Index("ix_api_keys_tenant_id",  "tenant_id"),
    )


# ---------------------------------------------------------------------------
# Search Event (analytics + ML training data)
# ---------------------------------------------------------------------------

class SearchEventModel(Base):
    __tablename__ = "search_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)

    tenant_id:     Mapped[str]  = mapped_column(String(100), nullable=False)
    query:         Mapped[str]  = mapped_column(String(500), nullable=False)
    corrected:     Mapped[str]  = mapped_column(String(500), nullable=False)
    intent:        Mapped[str]  = mapped_column(String(20),  nullable=False)

    # Ordered list of doc_ids shown to the user
    result_ids:    Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)

    # Which result the pharmacist selected (None = no selection)
    selected_id:   Mapped[str | None] = mapped_column(String(100), nullable=True)
    added_to_bill: Mapped[bool]       = mapped_column(Boolean, nullable=False, default=False)

    latency_ms:    Mapped[int]        = mapped_column(Integer, nullable=False)
    zero_results:  Mapped[bool]       = mapped_column(Boolean, nullable=False, default=False)

    user_id:       Mapped[str | None] = mapped_column(String(100), nullable=True)
    branch_id:     Mapped[str | None] = mapped_column(String(100), nullable=True)

    occurred_at:   Mapped[datetime]   = mapped_column(
        DateTime(timezone=True), nullable=False,
        server_default=func.now(),
    )

    __table_args__ = (
        # Hot analytics queries
        Index("ix_search_events_tenant_occurred", "tenant_id", "occurred_at"),
        Index("ix_search_events_zero_results",    "zero_results", "occurred_at"),
        Index("ix_search_events_tenant_query",    "tenant_id", "query"),
    )
