"""
infra/db/engine.py

Async SQLAlchemy engine and session factory.

One engine per process, created at application startup via the
async context manager in main.py lifespan.

All repositories receive an AsyncSession injected via FastAPI Depends —
they never create sessions themselves.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

import structlog
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from medsearch.settings import Settings

log = structlog.get_logger(__name__)

# Module-level singletons — set once during app startup
_engine:         AsyncEngine | None         = None
_session_factory: async_sessionmaker | None = None


def init_engine(settings: Settings) -> AsyncEngine:
    """
    Create and configure the async SQLAlchemy engine.
    Called once from main.py lifespan on startup.
    """
    global _engine, _session_factory

    _engine = create_async_engine(
        settings.database_url,
        pool_size     = settings.database_pool_size,
        max_overflow  = settings.database_max_overflow,
        pool_pre_ping = True,   # verify connections before use
        echo          = settings.is_development,  # log SQL in dev only
    )
    _session_factory = async_sessionmaker(
        _engine,
        class_       = AsyncSession,
        expire_on_commit = False,   # prevents lazy-load errors after commit
    )
    log.info("db.engine_ready", pool_size=settings.database_pool_size)
    return _engine


async def close_engine() -> None:
    """Dispose the engine on shutdown. Called from main.py lifespan cleanup."""
    global _engine
    if _engine:
        await _engine.dispose()
        log.info("db.engine_closed")


@asynccontextmanager
async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Async context manager that yields one session per request.

    Usage in repositories:
        async with get_session() as session:
            result = await session.execute(...)

    Used directly in FastAPI Depends:
        async def endpoint(session: AsyncSession = Depends(get_db)):
            ...
    """
    if _session_factory is None:
        raise RuntimeError("Database engine not initialised. Call init_engine() first.")

    async with _session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI Depends-compatible generator wrapping get_session."""
    async with get_session() as session:
        yield session
