"""
infra/db/repositories/event_repo.py

Search event persistence — implements IEventStore.

SearchEvent rows are the training data for the ML ranker.
Writes are fire-and-forget (called via asyncio.create_task).
Reads are used by analytics endpoints and the training script.
"""

from __future__ import annotations

import structlog
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from medsearch.core.domain.events import SearchEvent
from medsearch.infra.db.models import SearchEventModel

log = structlog.get_logger(__name__)


class EventRepository:
    """
    Repository for SearchEvent analytics persistence.
    Satisfies IEventStore protocol — no explicit inheritance needed.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # -------------------------------------------------------------------------
    # IEventStore: append
    # -------------------------------------------------------------------------

    async def append(self, event: SearchEvent) -> None:
        """
        Persist one search event.
        Called via asyncio.create_task — exceptions are logged, not raised.
        """
        try:
            row = SearchEventModel(
                tenant_id    = event.tenant_id,
                query        = event.query,
                corrected    = event.corrected,
                intent       = event.intent,
                result_ids   = list(event.result_ids),
                selected_id  = event.selected_id,
                added_to_bill= event.added_to_bill,
                latency_ms   = event.latency_ms,
                zero_results = event.zero_results,
                user_id      = event.user_id,
                branch_id    = event.branch_id,
                occurred_at  = event.occurred_at,
            )
            self._session.add(row)
            await self._session.commit()
        except Exception as exc:
            log.error("event_repo.append_failed", error=str(exc))

    # -------------------------------------------------------------------------
    # IEventStore: get_zero_result_queries
    # -------------------------------------------------------------------------

    async def get_zero_result_queries(
        self,
        tenant_id: str,
        limit:     int = 50,
    ) -> list[tuple[str, int]]:
        """
        Return (query, count) for queries that returned zero results.
        Ordered by frequency descending — highest-gap queries first.
        """
        stmt = (
            select(
                SearchEventModel.query,
                func.count(SearchEventModel.id).label("freq"),
            )
            .where(
                SearchEventModel.tenant_id   == tenant_id,
                SearchEventModel.zero_results == True,  # noqa: E712
            )
            .group_by(SearchEventModel.query)
            .order_by(text("freq DESC"))
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        return [(row.query, row.freq) for row in result]
