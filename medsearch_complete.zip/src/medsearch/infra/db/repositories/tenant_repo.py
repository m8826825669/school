"""
infra/db/repositories/tenant_repo.py

Tenant and API key data access — implements ITenantStore.

Hot path: get_api_key() is called on every request.
  - First checks a Redis cache (60s TTL) to avoid a DB hit per search
  - Falls back to DB on cache miss, then repopulates cache

Cold path: create_tenant(), create_api_key(), revoke_api_key()
  - Direct DB writes, no caching needed
"""

from __future__ import annotations

import json
import structlog
from datetime import datetime, timezone
from typing import Any

from passlib.context import CryptContext
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from medsearch.core.domain.tenant import ApiKey, Tenant
from medsearch.infra.db.models import ApiKeyModel, TenantModel
from medsearch.infra.cache.redis_store import RedisStore

log = structlog.get_logger(__name__)

_pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
_KEY_CACHE_TTL = 60   # seconds to cache a validated API key in Redis
_KEY_PREFIX    = "apikey:"


class TenantRepository:
    """
    Repository for Tenant and ApiKey persistence.
    Satisfies ITenantStore protocol — no explicit inheritance needed.
    """

    def __init__(self, session: AsyncSession, cache: RedisStore) -> None:
        self._session = session
        self._cache   = cache

    # -------------------------------------------------------------------------
    # ITenantStore: get_tenant
    # -------------------------------------------------------------------------

    async def get_tenant(self, tenant_id: str) -> Tenant | None:
        stmt   = select(TenantModel).where(TenantModel.tenant_id == tenant_id)
        result = await self._session.execute(stmt)
        row    = result.scalar_one_or_none()
        return self._to_tenant(row) if row else None

    # -------------------------------------------------------------------------
    # ITenantStore: get_api_key  (hot path — Redis cached)
    # -------------------------------------------------------------------------

    async def get_api_key(self, raw_key: str) -> ApiKey | None:
        # 1. Check Redis cache
        cache_key = f"{_KEY_PREFIX}{raw_key[:16]}"  # only prefix as cache key
        cached    = await self._cache.get_json(cache_key)
        if cached:
            return self._dict_to_api_key(cached)

        # 2. DB lookup: compare bcrypt hash
        stmt   = select(ApiKeyModel).where(ApiKeyModel.is_active == True)  # noqa: E712
        result = await self._session.execute(stmt)
        rows   = result.scalars().all()

        for row in rows:
            if _pwd_ctx.verify(raw_key, row.hashed_key):
                api_key = self._to_api_key(row)
                if not api_key.is_valid:
                    return None
                # Populate cache for next request
                await self._cache.set_json(
                    cache_key,
                    self._api_key_to_dict(api_key),
                    ttl=_KEY_CACHE_TTL,
                )
                return api_key

        return None

    # -------------------------------------------------------------------------
    # ITenantStore: create_tenant
    # -------------------------------------------------------------------------

    async def create_tenant(self, tenant: Tenant) -> None:
        row = TenantModel(
            tenant_id       = tenant.tenant_id,
            display_name    = tenant.display_name,
            allowed_indexes = list(tenant.allowed_indexes),
            is_active       = tenant.is_active,
        )
        self._session.add(row)

    # -------------------------------------------------------------------------
    # ITenantStore: create_api_key
    # -------------------------------------------------------------------------

    async def create_api_key(self, api_key: ApiKey) -> None:
        row = ApiKeyModel(
            id          = api_key.key_id,
            tenant_id   = api_key.tenant_id,
            hashed_key  = api_key.hashed_key,
            is_active   = api_key.is_active,
            rate_limit  = api_key.rate_limit,
            expires_at  = api_key.expires_at,
        )
        self._session.add(row)

    # -------------------------------------------------------------------------
    # ITenantStore: revoke_api_key
    # -------------------------------------------------------------------------

    async def revoke_api_key(self, key_id: str) -> None:
        stmt   = select(ApiKeyModel).where(ApiKeyModel.id == key_id)
        result = await self._session.execute(stmt)
        row    = result.scalar_one_or_none()
        if row:
            row.is_active = False
            # Invalidate any cached entry (we don't know the raw key prefix here
            # so we can't target the exact cache key; it will expire within 60s)

    # -------------------------------------------------------------------------
    # Private: domain object mappers
    # -------------------------------------------------------------------------

    def _to_tenant(self, row: TenantModel) -> Tenant:
        return Tenant(
            tenant_id       = row.tenant_id,
            display_name    = row.display_name,
            allowed_indexes = frozenset(row.allowed_indexes or []),
            is_active       = row.is_active,
            created_at      = row.created_at,
        )

    def _to_api_key(self, row: ApiKeyModel) -> ApiKey:
        return ApiKey(
            key_id     = str(row.id),
            tenant_id  = row.tenant_id,
            hashed_key = row.hashed_key,
            is_active  = row.is_active,
            rate_limit = row.rate_limit,
            created_at = row.created_at,
            expires_at = row.expires_at,
        )

    def _api_key_to_dict(self, key: ApiKey) -> dict[str, Any]:
        return {
            "key_id":     key.key_id,
            "tenant_id":  key.tenant_id,
            "hashed_key": key.hashed_key,
            "is_active":  key.is_active,
            "rate_limit": key.rate_limit,
            "created_at": key.created_at.isoformat(),
            "expires_at": key.expires_at.isoformat() if key.expires_at else None,
        }

    def _dict_to_api_key(self, d: dict[str, Any]) -> ApiKey:
        return ApiKey(
            key_id     = d["key_id"],
            tenant_id  = d["tenant_id"],
            hashed_key = d["hashed_key"],
            is_active  = d["is_active"],
            rate_limit = d["rate_limit"],
            created_at = datetime.fromisoformat(d["created_at"]),
            expires_at = datetime.fromisoformat(d["expires_at"]) if d["expires_at"] else None,
        )
