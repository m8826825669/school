"""
infra/search/qdrant_engine.py

Qdrant adapter — implements ISearchEngine for vector / semantic search.

Responsibilities (this file only):
  - Embed query text via injected IEmbedder
  - Execute ANN search against Qdrant collection
  - Translate Qdrant hits → SearchHit domain objects
  - Handle collection naming "{tenant_id}__{index}"

Qdrant is chosen for vector search because:
  - HNSW index gives sub-10ms ANN at 500K+ vectors
  - Payload filtering (stock_qty > 0) runs inside the ANN pass
  - Native async client
  - Per-collection HNSW tuning (m, ef_construct)
"""

from __future__ import annotations

import structlog
from typing import Any

from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance,
    FieldCondition,
    Filter,
    HnswConfigDiff,
    PointStruct,
    Range,
    SearchRequest,
    VectorParams,
    MatchValue,
)

from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import SearchHit
from medsearch.core.ports.embedder_port import IEmbedder
from medsearch.settings import Settings

log = structlog.get_logger(__name__)


class QdrantEngine:
    """
    Vector search adapter backed by Qdrant.
    Satisfies ISearchEngine protocol — no explicit inheritance needed.

    Requires an IEmbedder to convert query text to a vector before searching.
    The embedder is injected, keeping I/O concerns separate from this adapter.
    """

    def __init__(self, settings: Settings, embedder: IEmbedder) -> None:
        self._settings = settings
        self._embedder = embedder
        self._client   = AsyncQdrantClient(url=settings.qdrant_url)

    # -------------------------------------------------------------------------
    # ISearchEngine: search
    # -------------------------------------------------------------------------

    async def search(
        self,
        query:     ParsedQuery,
        tenant_id: str,
        index:     str,
        filters:   dict[str, Any],
        limit:     int,
    ) -> list[SearchHit]:
        # Vector search is most useful for symptom/semantic queries.
        # For barcode lookups it adds noise — skip it.
        if query.is_barcode:
            return []

        collection   = self._collection_name(tenant_id, index)
        query_vector = await self._embedder.embed_one(query.corrected)
        qdrant_filter = self._build_filter(filters)

        try:
            results = await self._client.search(
                collection_name = collection,
                query_vector    = query_vector,
                query_filter    = qdrant_filter,
                score_threshold = self._settings.similarity_threshold,
                with_payload    = True,
                limit           = limit,
            )
            return self._to_hits(results)
        except Exception as exc:
            log.error(
                "qdrant.search_failed",
                error      = str(exc),
                collection = collection,
                query      = query.corrected,
            )
            return []

    # -------------------------------------------------------------------------
    # ISearchEngine: upsert
    # -------------------------------------------------------------------------

    async def upsert(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
        document:  dict[str, Any],
    ) -> None:
        """
        Embed the document text and upsert the vector + payload into Qdrant.
        The embedding text combines name + generic_name + indications to give
        the vector maximum semantic signal.
        """
        collection  = self._collection_name(tenant_id, index)
        embed_text  = self._build_embed_text(document)
        vector      = await self._embedder.embed_one(embed_text)

        try:
            await self._client.upsert(
                collection_name = collection,
                points = [PointStruct(
                    id      = self._doc_id_to_int(doc_id),
                    vector  = vector,
                    payload = {**document, "_doc_id": doc_id},
                )],
            )
        except Exception as exc:
            log.error("qdrant.upsert_failed", error=str(exc), doc_id=doc_id)

    # -------------------------------------------------------------------------
    # ISearchEngine: delete
    # -------------------------------------------------------------------------

    async def delete(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
    ) -> None:
        collection = self._collection_name(tenant_id, index)
        try:
            await self._client.delete(
                collection_name = collection,
                points_selector = [self._doc_id_to_int(doc_id)],
            )
        except Exception as exc:
            log.error("qdrant.delete_failed", error=str(exc), doc_id=doc_id)

    # -------------------------------------------------------------------------
    # ISearchEngine: create_index
    # -------------------------------------------------------------------------

    async def create_index(
        self,
        tenant_id: str,
        index:     str,
        schema:    dict[str, Any],
    ) -> None:
        collection = self._collection_name(tenant_id, index)
        s          = self._settings

        try:
            await self._client.create_collection(
                collection_name = collection,
                vectors_config  = VectorParams(
                    size     = s.embedding_dimensions,
                    distance = Distance.COSINE,
                ),
                hnsw_config = HnswConfigDiff(
                    m               = s.qdrant_collection_hnsw_m,
                    ef_construct    = s.qdrant_collection_ef_construct,
                    on_disk         = False,
                ),
            )
            log.info("qdrant.collection_created", collection=collection)
        except Exception as exc:
            # Collection already exists — not an error
            if "already exists" in str(exc).lower():
                log.debug("qdrant.collection_exists", collection=collection)
            else:
                log.error("qdrant.create_collection_failed", error=str(exc))
                raise

    # -------------------------------------------------------------------------
    # ISearchEngine: health
    # -------------------------------------------------------------------------

    async def health(self) -> bool:
        try:
            info = await self._client.get_collections()
            return info is not None
        except Exception:
            return False

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _collection_name(self, tenant_id: str, index: str) -> str:
        return f"{tenant_id}__{index}"

    def _build_filter(self, filters: dict[str, Any]) -> Filter | None:
        """
        Convert filter dict to a Qdrant Filter object.

        Input:  {"stock_qty": {"gt": 0}, "category": {"eq": "antibiotic"}}
        Output: Filter(must=[FieldCondition(...), FieldCondition(...)])
        """
        conditions: list[FieldCondition] = []

        for field, condition in filters.items():
            if isinstance(condition, dict):
                op  = next(iter(condition))
                val = condition[op]

                if op in ("gt", "gte", "lt", "lte"):
                    range_kwargs: dict[str, Any] = {}
                    if op == "gt":  range_kwargs["gt"]  = val
                    if op == "gte": range_kwargs["gte"] = val
                    if op == "lt":  range_kwargs["lt"]  = val
                    if op == "lte": range_kwargs["lte"] = val
                    conditions.append(
                        FieldCondition(key=field, range=Range(**range_kwargs))
                    )
                elif op == "eq":
                    conditions.append(
                        FieldCondition(key=field, match=MatchValue(value=val))
                    )
            else:
                conditions.append(
                    FieldCondition(key=field, match=MatchValue(value=condition))
                )

        return Filter(must=conditions) if conditions else None

    def _to_hits(self, results: list[Any]) -> list[SearchHit]:
        """Map Qdrant ScoredPoint objects to SearchHit domain objects."""
        hits: list[SearchHit] = []
        for point in results:
            payload = dict(point.payload or {})
            doc_id  = payload.pop("_doc_id", str(point.id))
            hits.append(SearchHit(
                doc_id  = doc_id,
                score   = float(point.score),
                payload = payload,
                source  = "qdrant",
            ))
        return hits

    def _build_embed_text(self, document: dict[str, Any]) -> str:
        """
        Concatenate the most semantically rich fields for embedding.
        More context = better vector representation.
        """
        parts = [
            document.get("name", ""),
            document.get("generic_name", ""),
            document.get("salt_composition", ""),
            document.get("indications", ""),
            document.get("category", ""),
        ]
        return " ".join(p for p in parts if p).strip()

    def _doc_id_to_int(self, doc_id: str) -> int:
        """
        Qdrant point IDs must be unsigned integers or UUIDs.
        Strip any non-numeric prefix (e.g. "med_123" → 123).
        For UUID-style IDs, use hash % 2^63.
        """
        numeric = "".join(c for c in doc_id if c.isdigit())
        if numeric:
            return int(numeric)
        return abs(hash(doc_id)) % (2 ** 63)
