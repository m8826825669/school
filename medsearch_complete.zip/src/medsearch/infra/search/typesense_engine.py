"""
infra/search/typesense_engine.py

Typesense adapter — implements ISearchEngine for lexical / BM25 search.

Responsibilities (this file only):
  - Translate ParsedQuery → Typesense search parameters
  - Translate Typesense hits → SearchHit domain objects
  - Handle collection naming convention  "{tenant_id}__{index}"
  - Swallow engine errors and return empty list (never propagate)

Typesense is chosen for lexical search because:
  - Built-in typo tolerance (num_typos: 2)
  - Prefix search without extra config
  - Field-weighted scoring out of the box
  - Sub-5ms for 100K documents
"""

from __future__ import annotations

import structlog
import typesense
import typesense.exceptions
from typing import Any

from medsearch.core.domain.search_query import ParsedQuery, QueryIntent
from medsearch.core.domain.search_result import SearchHit
from medsearch.settings import Settings

log = structlog.get_logger(__name__)

# Field weights: name is most important, then generic_name, salt, indications
_QUERY_BY        = "name,generic_name,salt_composition,indications,brand_synonyms"
_QUERY_BY_WEIGHTS = "5,4,3,2,1"

# Intent → field weight overrides so SALT queries rank salt_composition higher
_INTENT_WEIGHTS: dict[QueryIntent, str] = {
    QueryIntent.SALT:    "2,3,5,2,1",
    QueryIntent.SYMPTOM: "2,2,2,5,1",
    QueryIntent.GENERIC: "2,5,3,2,1",
    QueryIntent.BRAND:   "5,4,3,2,1",
    QueryIntent.BARCODE: "1,1,1,1,1",  # barcode path skips this engine
}

# Default medicine collection schema — used by create_index()
_MEDICINE_SCHEMA_FIELDS: list[dict[str, Any]] = [
    {"name": "name",             "type": "string"},
    {"name": "generic_name",     "type": "string", "optional": True},
    {"name": "salt_composition", "type": "string", "optional": True},
    {"name": "indications",      "type": "string", "optional": True},
    {"name": "brand_synonyms",   "type": "string", "optional": True},
    {"name": "price",            "type": "float"},
    {"name": "stock_qty",        "type": "int32"},
    {"name": "sales_30d",        "type": "int32",  "optional": True},
    {"name": "margin_pct",       "type": "float",  "optional": True},
    {"name": "category",         "type": "string", "optional": True, "facet": True},
    {"name": "barcode",          "type": "string", "optional": True},
]


class TypesenseEngine:
    """
    Lexical search adapter backed by Typesense.
    Satisfies ISearchEngine protocol — no explicit inheritance needed.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._client = typesense.Client({
            "nodes": [{
                "host":     settings.typesense_host,
                "port":     settings.typesense_port,
                "protocol": settings.typesense_protocol,
            }],
            "api_key":                  settings.typesense_api_key,
            "connection_timeout_seconds": settings.typesense_connection_timeout,
        })

    # -------------------------------------------------------------------------
    # ISearchEngine: search
    # -------------------------------------------------------------------------

    async def search(
        self,
        query:     ParsedQuery,
        tenant_id: str,
        index:     str,
        filters:   dict[str, Any],
        limit:     int,
    ) -> list[SearchHit]:
        # Barcode queries skip lexical search — handled by barcode_lookup
        if query.is_barcode:
            return await self._barcode_search(query.corrected, tenant_id, index)

        collection = self._collection_name(tenant_id, index)
        weights    = _INTENT_WEIGHTS.get(query.intent, _QUERY_BY_WEIGHTS)

        params: dict[str, Any] = {
            "q":                query.corrected,
            "query_by":         _QUERY_BY,
            "query_by_weights": weights,
            "num_typos":        2,
            "typo_tokens_threshold": 1,
            "prefix":           True,
            "per_page":         limit,
            "filter_by":        self._build_filter(filters),
            "sort_by":          "_text_match:desc,stock_qty:desc",
        }

        try:
            result = self._client.collections[collection].documents.search(params)
            return self._to_hits(result["hits"])
        except typesense.exceptions.ObjectNotFound:
            log.warning("typesense.collection_not_found", collection=collection)
            return []
        except Exception as exc:
            log.error("typesense.search_failed", error=str(exc), query=query.corrected)
            return []

    # -------------------------------------------------------------------------
    # ISearchEngine: upsert
    # -------------------------------------------------------------------------

    async def upsert(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
        document:  dict[str, Any],
    ) -> None:
        collection = self._collection_name(tenant_id, index)
        try:
            self._client.collections[collection].documents.upsert(
                {"id": doc_id, **document}
            )
        except typesense.exceptions.ObjectNotFound:
            log.warning(
                "typesense.upsert_collection_missing",
                collection=collection,
                doc_id=doc_id,
            )
        except Exception as exc:
            log.error("typesense.upsert_failed", error=str(exc), doc_id=doc_id)

    # -------------------------------------------------------------------------
    # ISearchEngine: delete
    # -------------------------------------------------------------------------

    async def delete(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
    ) -> None:
        collection = self._collection_name(tenant_id, index)
        try:
            self._client.collections[collection].documents[doc_id].delete()
        except typesense.exceptions.ObjectNotFound:
            pass  # already gone — idempotent
        except Exception as exc:
            log.error("typesense.delete_failed", error=str(exc), doc_id=doc_id)

    # -------------------------------------------------------------------------
    # ISearchEngine: create_index
    # -------------------------------------------------------------------------

    async def create_index(
        self,
        tenant_id: str,
        index:     str,
        schema:    dict[str, Any],
    ) -> None:
        collection = self._collection_name(tenant_id, index)
        fields     = schema.get("fields", _MEDICINE_SCHEMA_FIELDS)

        try:
            self._client.collections.create({
                "name":                 collection,
                "fields":               fields,
                "default_sorting_field": "stock_qty",
            })
            log.info("typesense.index_created", collection=collection)
        except typesense.exceptions.ObjectAlreadyExists:
            log.debug("typesense.index_exists", collection=collection)
        except Exception as exc:
            log.error("typesense.create_index_failed", error=str(exc))
            raise

    # -------------------------------------------------------------------------
    # ISearchEngine: health
    # -------------------------------------------------------------------------

    async def health(self) -> bool:
        try:
            result = self._client.operations.is_healthy()
            return bool(result)
        except Exception:
            return False

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _collection_name(self, tenant_id: str, index: str) -> str:
        """Deterministic collection name: pharmacy_1__medicines"""
        return f"{tenant_id}__{index}"

    def _build_filter(self, filters: dict[str, Any]) -> str:
        """
        Convert filter dict to Typesense filter_by string.

        Input:  {"stock_qty": {"gt": 0}, "category": {"eq": "antibiotic"}}
        Output: "stock_qty:>0 && category:=antibiotic"
        """
        _op_map = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<=", "eq": "="}
        parts: list[str] = []

        for field, condition in filters.items():
            if isinstance(condition, dict):
                for op, val in condition.items():
                    operator = _op_map.get(op, "=")
                    parts.append(f"{field}:{operator}{val}")
            else:
                # Simple equality: {"category": "antibiotic"}
                parts.append(f"{field}:={condition}")

        return " && ".join(parts)

    def _to_hits(self, raw_hits: list[dict[str, Any]]) -> list[SearchHit]:
        """Map raw Typesense hits to SearchHit domain objects."""
        hits: list[SearchHit] = []
        for raw in raw_hits:
            doc   = raw.get("document", {})
            score = raw.get("text_match", 0)
            hits.append(SearchHit(
                doc_id  = str(doc.get("id", "")),
                score   = self._normalize_score(score),
                payload = doc,
                source  = "typesense",
            ))
        return hits

    def _normalize_score(self, text_match: int) -> float:
        """
        Typesense text_match is a large integer (e.g. 578730123).
        Normalise to [0.0, 1.0] by dividing by the known max value.
        """
        _MAX_SCORE = 1_000_000_000
        return min(float(text_match) / _MAX_SCORE, 1.0)

    async def _barcode_search(
        self,
        barcode:   str,
        tenant_id: str,
        index:     str,
    ) -> list[SearchHit]:
        """Exact match on barcode field — bypass text scoring entirely."""
        collection = self._collection_name(tenant_id, index)
        try:
            result = self._client.collections[collection].documents.search({
                "q":         barcode,
                "query_by":  "barcode",
                "num_typos": 0,
                "per_page":  1,
            })
            return self._to_hits(result["hits"])
        except Exception as exc:
            log.error("typesense.barcode_search_failed", error=str(exc))
            return []
