"""
api/dependencies.py

Dependency injection wiring — the single place where concrete adapters
are assembled into service objects.

All FastAPI endpoints receive their services via Depends() — they never
instantiate anything directly. This makes every endpoint trivially testable
by overriding these dependencies in tests.

Singleton pattern:
  Expensive objects (models, DB engines, Redis connections) are created once
  at application startup and reused across all requests via module-level
  singletons set by the lifespan context manager in main.py.

  Request-scoped objects (DB sessions) are created per-request and yielded
  by async generators.
"""

from __future__ import annotations

from typing import Annotated

import structlog
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader
from redis.asyncio import Redis

from medsearch.core.ports.cache_port import ICacheStore
from medsearch.core.ports.search_port import ISearchEngine
from medsearch.infra.cache.redis_store import RedisStore
from medsearch.infra.cache.redis_trie import RedisTrie
from medsearch.infra.ml.embedder import SentenceEmbedder
from medsearch.infra.ml.lgbm_ranker import LGBMRanker
from medsearch.infra.nlp.phonetic import PhoneticMatcher
from medsearch.infra.nlp.spell_corrector import SpellCorrector
from medsearch.infra.search.qdrant_engine import QdrantEngine
from medsearch.infra.search.typesense_engine import TypesenseEngine
from medsearch.services.analytics_service import AnalyticsService
from medsearch.services.index_service import IndexService
from medsearch.services.query_service import QueryService
from medsearch.services.search_service import SearchService
from medsearch.services.suggest_service import SuggestService
from medsearch.settings import Settings, get_settings

log = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Module-level singletons — set once by lifespan in main.py
# ---------------------------------------------------------------------------
# These are declared here so that tests can patch them directly.

_redis:          Redis | None              = None
_embedder:       SentenceEmbedder | None   = None
_ranker:         LGBMRanker | None         = None
_corrector:      SpellCorrector | None     = None
_phonetic:       PhoneticMatcher | None    = None
_lexical_engine: TypesenseEngine | None    = None
_vector_engine:  QdrantEngine | None       = None
_cache:          RedisStore | None         = None
_trie:           RedisTrie | None          = None

# ---------------------------------------------------------------------------
# API key security scheme
# ---------------------------------------------------------------------------

_api_key_scheme = APIKeyHeader(name="X-API-Key", auto_error=True)


async def verify_api_key(
    raw_key:  str      = Security(_api_key_scheme),
    settings: Settings = Depends(get_settings),
) -> str:
    """
    Validate the X-API-Key header.

    In production this checks against the tenant_repo (DB + Redis cache).
    For Phase 5 we validate against a single master key from settings,
    which is enough to gate every endpoint. Phase 6 (multi-tenant) will
    replace this with per-key lookup.
    """
    if not raw_key or raw_key != settings.secret_key:
        raise HTTPException(
            status_code = status.HTTP_401_UNAUTHORIZED,
            detail      = "Invalid or missing API key.",
            headers     = {"WWW-Authenticate": "ApiKey"},
        )
    return raw_key

# ---------------------------------------------------------------------------
# Infrastructure singletons (returned directly — no per-request creation)
# ---------------------------------------------------------------------------


def get_cache() -> ICacheStore:
    if _cache is None:
        raise RuntimeError("Cache not initialised. Is lifespan running?")
    return _cache


def get_lexical_engine() -> ISearchEngine:
    if _lexical_engine is None:
        raise RuntimeError("Lexical engine not initialised.")
    return _lexical_engine


def get_vector_engine() -> ISearchEngine:
    if _vector_engine is None:
        raise RuntimeError("Vector engine not initialised.")
    return _vector_engine


def get_trie() -> RedisTrie:
    if _trie is None:
        raise RuntimeError("Trie not initialised.")
    return _trie


def get_ranker() -> LGBMRanker:
    if _ranker is None:
        raise RuntimeError("Ranker not initialised.")
    return _ranker


def get_corrector() -> SpellCorrector:
    if _corrector is None:
        raise RuntimeError("SpellCorrector not initialised.")
    return _corrector

# ---------------------------------------------------------------------------
# Service factories (assembled per-request from singletons — cheap)
# ---------------------------------------------------------------------------


def get_query_service(
    corrector: SpellCorrector = Depends(get_corrector),
) -> QueryService:
    return QueryService(corrector)


def get_search_service(
    lexical: ISearchEngine = Depends(get_lexical_engine),
    vector:  ISearchEngine = Depends(get_vector_engine),
    cache:   ICacheStore   = Depends(get_cache),
    ranker:  LGBMRanker    = Depends(get_ranker),
) -> SearchService:
    return SearchService(lexical, vector, cache, ranker)


def get_index_service(
    lexical: ISearchEngine = Depends(get_lexical_engine),
    vector:  ISearchEngine = Depends(get_vector_engine),
    cache:   ICacheStore   = Depends(get_cache),
    trie:    RedisTrie     = Depends(get_trie),
) -> IndexService:
    return IndexService(lexical, vector, cache, trie)


def get_suggest_service(
    trie:    RedisTrie     = Depends(get_trie),
    lexical: ISearchEngine = Depends(get_lexical_engine),
) -> SuggestService:
    return SuggestService(trie, lexical)


def get_analytics_service() -> AnalyticsService:
    """
    Returns AnalyticsService with a no-op event store for Phase 5.
    Phase 6 will inject EventRepository backed by PostgreSQL.
    """
    from unittest.mock import AsyncMock
    noop_store = AsyncMock()
    noop_store.append = AsyncMock()
    noop_store.get_zero_result_queries = AsyncMock(return_value=[])
    return AnalyticsService(noop_store)

# ---------------------------------------------------------------------------
# Startup / shutdown helpers (called from main.py lifespan)
# ---------------------------------------------------------------------------


def init_singletons(settings: Settings) -> None:
    """
    Instantiate all expensive singletons.
    Called once from main.py lifespan on startup.
    Must complete before the first request arrives.
    """
    global _redis, _embedder, _ranker, _corrector, _phonetic
    global _lexical_engine, _vector_engine, _cache, _trie

    log.info("startup.initialising_singletons")

    # Redis
    _redis = Redis.from_url(settings.redis_url, decode_responses=False)
    _cache = RedisStore(_redis)
    _trie  = RedisTrie(_redis, ttl=settings.redis_autocomplete_ttl)

    # Search engines
    _lexical_engine = TypesenseEngine(settings)

    # Embedder — load model (blocks ~2s on first run)
    _embedder = SentenceEmbedder(
        model_name = settings.embedding_model,
        batch_size = settings.embedding_batch_size,
    ).load()
    _vector_engine = QdrantEngine(settings, _embedder)

    # ML ranker — load model if present
    _ranker = LGBMRanker.load(settings.ranker_model_path)

    # NLP tools — build from empty wordlist initially;
    # IndexService.rebuild() will repopulate after catalog is loaded
    _corrector = SpellCorrector.build_from_wordlist([])
    _phonetic  = PhoneticMatcher()

    log.info("startup.singletons_ready")


async def shutdown_singletons() -> None:
    """Clean up connections on shutdown."""
    global _redis
    if _redis:
        await _redis.aclose()
        log.info("shutdown.redis_closed")
