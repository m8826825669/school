"""
api/middleware.py

Application middleware — applied to every request in order.

Middleware stack (outermost to innermost):
  1. CORSMiddleware     — Allow cross-origin requests from configured origins
  2. RequestIDMiddleware— Inject a unique X-Request-ID into every request/response
  3. LoggingMiddleware  — Structured access log after every request

All middleware is registered via register_middleware(app) called from main.py.
Nothing here is business logic — pure cross-cutting concerns.
"""

from __future__ import annotations

import time
import uuid

import structlog
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.types import ASGIApp

from medsearch.settings import get_settings

log = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Request ID middleware
# ---------------------------------------------------------------------------


class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Injects a unique request ID into every request and response.

    - Reads X-Request-ID from incoming header if provided by upstream proxy
    - Generates a new UUID4 if none is present
    - Adds the ID to response headers so clients can correlate logs
    - Binds the ID to structlog context so it appears in every log line
      emitted during this request
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())

        # Bind to structlog context for this request
        structlog.contextvars.bind_contextvars(request_id=request_id)

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id

        # Clear context after request to avoid leaking between requests
        structlog.contextvars.clear_contextvars()
        return response


# ---------------------------------------------------------------------------
# Access logging middleware
# ---------------------------------------------------------------------------


class LoggingMiddleware(BaseHTTPMiddleware):
    """
    Emits one structured log line per request with:
      method, path, status_code, latency_ms, content_length
    """

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        t0       = time.monotonic()
        response = await call_next(request)
        latency  = int((time.monotonic() - t0) * 1000)

        log.info(
            "http.request",
            method      = request.method,
            path        = request.url.path,
            status      = response.status_code,
            latency_ms  = latency,
            client      = request.client.host if request.client else "unknown",
        )
        return response


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_middleware(app: FastAPI) -> None:
    """
    Register all middleware on the FastAPI application.
    Called once from main.py create_app().

    Order matters: middleware registered last runs outermost (first to see request).
    We want: CORS → RequestID → Logging (innermost — sees final response).
    """
    settings = get_settings()

    # Innermost: logging (registered first = runs last in chain)
    app.add_middleware(LoggingMiddleware)

    # Middle: request ID
    app.add_middleware(RequestIDMiddleware)

    # Outermost: CORS (registered last = runs first in chain)
    app.add_middleware(
        CORSMiddleware,
        allow_origins     = settings.cors_origins_list,
        allow_credentials = True,
        allow_methods     = ["GET", "POST", "DELETE"],
        allow_headers     = ["*"],
    )
