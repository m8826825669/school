"""
api/v1/router.py

Aggregates all v1 endpoint routers into a single router.
Included in main.py with prefix="/v1".

Adding a new endpoint group:
  1. Create api/v1/endpoints/my_feature.py with router = APIRouter()
  2. Import and include it here with its prefix
  3. Nothing else changes
"""

from __future__ import annotations

from fastapi import APIRouter

from medsearch.api.v1.endpoints import analytics, health, index, search, suggest

router = APIRouter()

router.include_router(
    search.router,
    prefix="/search",
    tags=["search"],
)
router.include_router(
    suggest.router,
    prefix="/suggest",
    tags=["suggest"],
)
router.include_router(
    index.router,
    prefix="/index",
    tags=["index"],
)
router.include_router(
    health.router,
    prefix="/health",
    tags=["health"],
)
router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["analytics"],
)
