"""
api/v1/endpoints/search.py

POST /v1/search — main search endpoint.

This file is intentionally thin:
  1. Validate request (Pydantic does this automatically)
  2. Parse the query via QueryService
  3. Execute search via SearchService
  4. Log the event via AnalyticsService (fire-and-forget)
  5. Serialise and return

No business logic lives here. Any logic needed for a new feature
goes into a service, not this file.
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends

from medsearch.api.dependencies import (
    get_analytics_service,
    get_query_service,
    get_search_service,
    verify_api_key,
)
from medsearch.api.v1.schemas import HitSchema, SearchRequest, SearchResponse
from medsearch.core.domain.search_query import SearchLanguage
from medsearch.services.analytics_service import AnalyticsService
from medsearch.services.query_service import QueryService
from medsearch.services.search_service import SearchService

router = APIRouter()


@router.post(
    "",
    response_model=SearchResponse,
    summary="Search for medicines or any indexed document",
    description=(
        "Executes the full search pipeline: spell correction → parallel lexical "
        "and vector search → RRF merge → ML re-ranking. Returns ranked results "
        "in under 50ms for typical pharmacy catalogs."
    ),
)
async def search(
    req:       SearchRequest,
    _api_key:  str              = Depends(verify_api_key),
    query_svc: QueryService     = Depends(get_query_service),
    search_svc: SearchService   = Depends(get_search_service),
    analytics:  AnalyticsService = Depends(get_analytics_service),
) -> SearchResponse:
    # Step 1: Understand the query
    parsed = query_svc.parse(req.query, SearchLanguage(req.language))

    # Step 2: Execute search pipeline
    result = await search_svc.search(
        query     = parsed,
        tenant_id = req.tenant_id,
        index     = req.index,
        filters   = req.filters,
        boost     = req.boost,
        user_id   = req.user_id,
        limit     = req.limit,
    )

    # Step 3: Log event asynchronously (never blocks the response)
    analytics.log_search(parsed, result, user_id=req.user_id)

    # Step 4: Build API response
    return SearchResponse(
        hits=[
            HitSchema(
                doc_id  = h.doc_id,
                score   = round(h.rank_score, 4),
                payload = h.payload,
                source  = h.source,
            )
            for h in result.hits
        ],
        total           = result.total,
        corrected_query = result.corrected_query,
        latency_ms      = result.latency_ms,
    )
