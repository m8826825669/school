"""
api/v1/endpoints/index.py

Document management endpoints.

POST   /v1/index              — upsert one document
DELETE /v1/index/{doc_id}     — remove one document
POST   /v1/index/batch        — upsert multiple documents (bulk ingestion)

Called by client applications (Django pharmacy app) via post_save signals.
These are low-frequency writes compared to search reads, so no special
rate limiting beyond the standard API key limit.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Path, Query
from typing import Any

from medsearch.api.dependencies import get_index_service, verify_api_key
from medsearch.api.v1.schemas import DeleteResponse, IndexRequest, IndexResponse
from medsearch.services.index_service import IndexService

router = APIRouter()


@router.post(
    "",
    response_model=IndexResponse,
    status_code=200,
    summary="Upsert a document into the search index",
    description=(
        "Inserts or updates a document across all search engines "
        "(Typesense + Qdrant) and rebuilds the autocomplete trie entry. "
        "Invalidates cached results for the affected tenant+index."
    ),
)
async def upsert_document(
    req:       IndexRequest,
    _api_key:  str          = Depends(verify_api_key),
    index_svc: IndexService = Depends(get_index_service),
) -> IndexResponse:
    await index_svc.upsert(
        tenant_id = req.tenant_id,
        index     = req.index,
        doc_id    = req.doc_id,
        document  = req.document,
    )
    return IndexResponse(
        status    = "indexed",
        doc_id    = req.doc_id,
        tenant_id = req.tenant_id,
    )


@router.delete(
    "/{doc_id}",
    response_model=DeleteResponse,
    summary="Remove a document from the search index",
)
async def delete_document(
    doc_id:    str = Path(min_length=1, max_length=100),
    tenant_id: str = Query(min_length=1, max_length=100),
    index:     str = Query(default="medicines", max_length=50),
    _api_key:  str = Depends(verify_api_key),
    index_svc: IndexService = Depends(get_index_service),
) -> DeleteResponse:
    await index_svc.delete(
        tenant_id = tenant_id,
        index     = index,
        doc_id    = doc_id,
    )
    return DeleteResponse(
        status    = "deleted",
        doc_id    = doc_id,
        tenant_id = tenant_id,
    )


@router.post(
    "/batch",
    response_model=dict[str, Any],
    summary="Bulk upsert documents (initial seeding or re-sync)",
)
async def batch_upsert(
    tenant_id:  str                  = Query(min_length=1, max_length=100),
    index:      str                  = Query(default="medicines", max_length=50),
    documents:  list[dict[str, Any]] = ...,
    _api_key:   str                  = Depends(verify_api_key),
    index_svc:  IndexService         = Depends(get_index_service),
) -> dict[str, Any]:
    success = 0
    failed  = 0
    for doc in documents:
        doc_id = doc.get("id") or doc.get("doc_id")
        if not doc_id:
            failed += 1
            continue
        try:
            await index_svc.upsert(
                tenant_id = tenant_id,
                index     = index,
                doc_id    = str(doc_id),
                document  = doc,
            )
            success += 1
        except Exception:
            failed += 1

    return {
        "status":    "batch_complete",
        "total":     len(documents),
        "succeeded": success,
        "failed":    failed,
    }
