"""
api/v1/endpoints/health.py

Health check endpoints — used by Docker, load balancers, and monitoring.

GET /health        — full dependency health (Typesense, Qdrant, Redis, DB)
GET /health/live   — liveness probe (always 200 if process is running)
GET /health/ready  — readiness probe (200 only if all critical deps are healthy)

Kubernetes convention:
  livenessProbe  → /health/live   (restart pod if fails)
  readinessProbe → /health/ready  (stop sending traffic if fails)
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Response, status

from medsearch.api.dependencies import (
    get_cache,
    get_lexical_engine,
    get_vector_engine,
)
from medsearch.api.v1.schemas import DependencyStatus, HealthResponse
from fastapi import Depends

from medsearch.core.ports.cache_port import ICacheStore
from medsearch.core.ports.search_port import ISearchEngine

router = APIRouter()


@router.get(
    "/live",
    summary="Liveness probe — is the process running?",
    status_code=200,
)
async def liveness() -> dict:
    """Always returns 200 while the process is alive."""
    return {"status": "alive"}


@router.get(
    "/ready",
    summary="Readiness probe — are all critical dependencies healthy?",
)
async def readiness(
    response:       Response,
    cache:          ICacheStore   = Depends(get_cache),
    lexical_engine: ISearchEngine = Depends(get_lexical_engine),
) -> dict:
    """
    Returns 200 if Redis and Typesense are reachable.
    Returns 503 if either is down — stops load balancer from routing traffic.
    Qdrant is not checked here (degraded search is better than no search).
    """
    redis_ok    = await cache.health()
    typesense_ok = await lexical_engine.health()
    all_healthy  = redis_ok and typesense_ok

    if not all_healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE

    return {
        "status": "ready" if all_healthy else "not_ready",
        "redis":     redis_ok,
        "typesense": typesense_ok,
    }


@router.get(
    "",
    response_model=HealthResponse,
    summary="Full dependency health check",
)
async def health(
    cache:          ICacheStore   = Depends(get_cache),
    lexical_engine: ISearchEngine = Depends(get_lexical_engine),
    vector_engine:  ISearchEngine = Depends(get_vector_engine),
) -> HealthResponse:
    """
    Checks all dependencies concurrently.
    Returns 'ok' if all healthy, 'degraded' if any dependency is down.
    Does not return 503 — informational only (don't kill the pod for Qdrant issues).
    """
    redis_ok, typesense_ok, qdrant_ok = await asyncio.gather(
        cache.health(),
        lexical_engine.health(),
        vector_engine.health(),
    )

    deps = [
        DependencyStatus(name="redis",     healthy=redis_ok),
        DependencyStatus(name="typesense", healthy=typesense_ok),
        DependencyStatus(name="qdrant",    healthy=qdrant_ok),
    ]
    overall = "ok" if all(d.healthy for d in deps) else "degraded"
    return HealthResponse(status=overall, dependencies=deps)
