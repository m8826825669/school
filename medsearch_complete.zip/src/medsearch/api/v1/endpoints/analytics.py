"""
api/v1/endpoints/analytics.py

Analytics endpoints — expose search quality metrics and record selections.

GET  /v1/analytics/zero-results  — queries with no results (catalog gaps)
POST /v1/select                  — record which result a pharmacist selected
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from medsearch.api.dependencies import get_analytics_service, verify_api_key
from medsearch.api.v1.schemas import (
    SelectionRequest,
    ZeroResultItem,
    ZeroResultResponse,
)
from medsearch.services.analytics_service import AnalyticsService

router = APIRouter()


@router.get(
    "/zero-results",
    response_model=ZeroResultResponse,
    summary="Queries that returned no results",
    description=(
        "Returns the most frequent search queries that returned zero results. "
        "Use this to identify medicines missing from your catalog."
    ),
)
async def zero_results(
    tenant_id:  str = Query(min_length=1, max_length=100),
    limit:      int = Query(default=50, ge=1, le=200),
    _api_key:   str = Depends(verify_api_key),
    analytics:  AnalyticsService = Depends(get_analytics_service),
) -> ZeroResultResponse:
    items = await analytics.get_zero_result_summary(tenant_id, limit)
    return ZeroResultResponse(
        tenant_id = tenant_id,
        items     = [ZeroResultItem(**item) for item in items],
    )


@router.post(
    "/select",
    summary="Record which search result was selected",
    description=(
        "Call this when a pharmacist picks a medicine from the search results. "
        "Selection signals are the primary training data for the ML ranker."
    ),
)
async def record_selection(
    req:        SelectionRequest,
    _api_key:   str = Depends(verify_api_key),
    analytics:  AnalyticsService = Depends(get_analytics_service),
) -> dict:
    await analytics.record_selection(
        tenant_id     = req.tenant_id,
        query         = req.query,
        selected_id   = req.selected_id,
        added_to_bill = req.added_to_bill,
    )
    return {"status": "recorded"}
