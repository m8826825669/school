"""
api/v1/endpoints/suggest.py

GET /v1/suggest — autocomplete prefix suggestions.

Called on every keystroke from the billing UI (debounced to 150ms).
Must return in < 2ms for the typing experience to feel instant.
The SuggestService handles the trie/fallback logic.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from medsearch.api.dependencies import get_suggest_service, verify_api_key
from medsearch.api.v1.schemas import SuggestResponse
from medsearch.services.suggest_service import SuggestService

router = APIRouter()


@router.get(
    "",
    response_model=SuggestResponse,
    summary="Autocomplete prefix suggestions",
    description=(
        "Returns medicine names starting with the given prefix. "
        "Uses Redis sorted-set trie for sub-millisecond lookup."
    ),
)
async def suggest(
    q:           str = Query(min_length=2, max_length=50, description="Prefix typed by user"),
    tenant_id:   str = Query(min_length=1, max_length=100),
    index:       str = Query(default="medicines", max_length=50),
    limit:       int = Query(default=8, ge=1, le=20),
    _api_key:    str = Depends(verify_api_key),
    suggest_svc: SuggestService = Depends(get_suggest_service),
) -> SuggestResponse:
    suggestions = await suggest_svc.suggest(
        prefix    = q,
        tenant_id = tenant_id,
        index     = index,
        limit     = limit,
    )
    return SuggestResponse(suggestions=suggestions, prefix=q)
