"""
api/v1/schemas.py

Pydantic v2 request and response schemas for the MedSearch API.

All schemas live in this one file — the API surface is small enough that
splitting them across files would create more navigation overhead than value.

Naming convention:
  *Request  — incoming HTTP body (validated on receipt)
  *Response — outgoing HTTP body (serialised before sending)

Design decisions:
  - Response models use model_config with from_attributes=True so they can be
    constructed directly from domain objects via model_validate()
  - All monetary values are float to avoid Decimal serialisation issues
  - doc_id is str so it works for both integer (Django PK) and UUID identifiers
  - Field constraints (min_length, ge, le) are expressed here, not in services,
    so validation errors become 422 responses before any business logic runs
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class SearchRequest(BaseModel):
    """POST /v1/search — body."""

    query:      str  = Field(min_length=2, max_length=200,
                             description="The search string typed by the user.")
    tenant_id:  str  = Field(min_length=1, max_length=100,
                             description="Tenant identifier (e.g. 'pharmacy_branch_3').")
    index:      str  = Field(default="medicines", max_length=50,
                             description="Collection to search within.")
    filters:    dict[str, Any] = Field(
                             default_factory=dict,
                             description="Field filters (e.g. {'stock_qty': {'gt': 0}}).")
    boost:      dict[str, float] = Field(
                             default_factory=dict,
                             description="Per-field score multipliers.")
    user_id:    str | None = Field(default=None, max_length=100,
                             description="Pharmacist ID for personalisation.")
    limit:      int  = Field(default=15, ge=1, le=50,
                             description="Maximum results to return.")
    language:   str  = Field(default="en", max_length=10,
                             description="Query language/locale (en or hi-IN).")


class HitSchema(BaseModel):
    """Single search result included in SearchResponse."""

    model_config = {"from_attributes": True}

    doc_id:  str
    score:   float          = Field(ge=0.0, le=1.0)
    payload: dict[str, Any]
    source:  str            = Field(description="Which engine returned this hit.")


class SearchResponse(BaseModel):
    """POST /v1/search — response."""

    hits:            list[HitSchema]
    total:           int   = Field(ge=0, description="Total candidates before limit.")
    corrected_query: str | None = Field(
                             default=None,
                             description="Spell-corrected query if it differed from input.")
    latency_ms:      int   = Field(ge=0, description="End-to-end pipeline latency.")


# ---------------------------------------------------------------------------
# Suggest (autocomplete)
# ---------------------------------------------------------------------------


class SuggestResponse(BaseModel):
    """GET /v1/suggest — response."""

    suggestions: list[str]
    prefix:      str


# ---------------------------------------------------------------------------
# Index (document management)
# ---------------------------------------------------------------------------


class IndexRequest(BaseModel):
    """POST /v1/index — body."""

    tenant_id: str          = Field(min_length=1, max_length=100)
    index:     str          = Field(default="medicines", max_length=50)
    doc_id:    str          = Field(min_length=1, max_length=100)
    document:  dict[str, Any]

    @model_validator(mode="after")
    def document_must_have_name(self) -> "IndexRequest":
        if "name" not in self.document:
            raise ValueError("document must contain a 'name' field")
        return self


class IndexResponse(BaseModel):
    """POST /v1/index — response."""

    status:   str
    doc_id:   str
    tenant_id: str


class DeleteResponse(BaseModel):
    """DELETE /v1/index/{doc_id} — response."""

    status:    str
    doc_id:    str
    tenant_id: str


# ---------------------------------------------------------------------------
# Analytics
# ---------------------------------------------------------------------------


class SelectionRequest(BaseModel):
    """POST /v1/select — record which result was chosen."""

    tenant_id:     str  = Field(min_length=1, max_length=100)
    query:         str  = Field(min_length=1, max_length=200)
    selected_id:   str  = Field(min_length=1, max_length=100)
    added_to_bill: bool = False


class ZeroResultItem(BaseModel):
    query: str
    count: int


class ZeroResultResponse(BaseModel):
    """GET /v1/analytics/zero-results — response."""

    tenant_id: str
    items:     list[ZeroResultItem]


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class DependencyStatus(BaseModel):
    name:    str
    healthy: bool


class HealthResponse(BaseModel):
    """GET /health — response."""

    status:       str        = Field(description="'ok' or 'degraded'")
    dependencies: list[DependencyStatus]
    version:      str        = "1.0.0"
