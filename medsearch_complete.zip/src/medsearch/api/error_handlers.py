"""
api/error_handlers.py

Global exception handlers — map Python exceptions to structured HTTP responses.

Registered via register_error_handlers(app) in main.py.
Every unhandled exception ends up here before reaching the client.

Response format for all errors:
    {
        "error":      "human-readable message",
        "error_code": "MACHINE_READABLE_CODE",
        "request_id": "uuid from X-Request-ID header"
    }

This consistent shape lets client SDKs parse error responses without
inspecting status codes.
"""

from __future__ import annotations

import structlog
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import ValidationError

log = structlog.get_logger(__name__)


def _error_body(
    message:    str,
    code:       str,
    request_id: str = "",
) -> dict:
    return {
        "error":      message,
        "error_code": code,
        "request_id": request_id,
    }


def _request_id(request: Request) -> str:
    return request.headers.get("X-Request-ID", "")


# ---------------------------------------------------------------------------
# Handler functions
# ---------------------------------------------------------------------------


async def validation_error_handler(
    request: Request,
    exc:     RequestValidationError,
) -> JSONResponse:
    """422 — request body or query param failed Pydantic validation."""
    errors = exc.errors()
    # Build a human-readable summary of the first validation error
    first  = errors[0] if errors else {}
    field  = " → ".join(str(loc) for loc in first.get("loc", []))
    msg    = first.get("msg", "Validation error")
    detail = f"{field}: {msg}" if field else msg

    log.warning("api.validation_error", path=str(request.url), detail=detail)

    return JSONResponse(
        status_code = status.HTTP_422_UNPROCESSABLE_ENTITY,
        content     = _error_body(detail, "VALIDATION_ERROR", _request_id(request)),
    )


async def http_exception_handler(
    request: Request,
    exc:     Exception,
) -> JSONResponse:
    """Forward FastAPI HTTPException with our error shape."""
    from fastapi import HTTPException
    assert isinstance(exc, HTTPException)

    return JSONResponse(
        status_code = exc.status_code,
        content     = _error_body(
            str(exc.detail),
            "HTTP_ERROR",
            _request_id(request),
        ),
    )


async def unhandled_exception_handler(
    request: Request,
    exc:     Exception,
) -> JSONResponse:
    """
    500 — catch-all for any exception that escaped the endpoint.

    Logs the full traceback with structlog (goes to your log aggregator)
    but returns only a generic message to the client (no stack trace leakage).
    """
    log.exception(
        "api.unhandled_exception",
        path  = str(request.url),
        error = str(exc),
    )
    return JSONResponse(
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR,
        content     = _error_body(
            "An internal error occurred. Please try again.",
            "INTERNAL_ERROR",
            _request_id(request),
        ),
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_error_handlers(app: FastAPI) -> None:
    """Register all exception handlers on the FastAPI application."""
    from fastapi import HTTPException
    from fastapi.exceptions import RequestValidationError

    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)
