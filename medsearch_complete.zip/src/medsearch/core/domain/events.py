"""
core/domain/events.py

Domain events — facts that happened, used for analytics and ML training.

SearchEvent is logged after every search request. Over time this table
becomes the training dataset for the LightGBM ranker.

Design decisions:
  - Immutable dataclass (frozen=True) — events are facts, never mutated
  - No ORM decorators — infra/db/models.py handles persistence
  - result_ids is a tuple (ordered, immutable) representing ranked order shown
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass(frozen=True, slots=True)
class SearchEvent:
    """
    Represents one search interaction.

    Created by AnalyticsService after every /v1/search request.
    Persisted asynchronously so it never blocks the search response.

    Attributes:
        tenant_id:      Which tenant made the request.
        query:          The original raw query string.
        corrected:      Spell-corrected query (same as query if no correction).
        intent:         Classified intent (brand/salt/symptom/barcode/generic).
        result_ids:     Ordered tuple of doc_ids shown to the user (position matters).
        selected_id:    doc_id the user actually selected (None if no selection yet).
        added_to_bill:  True if the selected result was added to a pharmacy bill.
        latency_ms:     End-to-end search latency.
        zero_results:   True if result_ids is empty.
        user_id:        Optional pharmacist/user identifier for personalisation.
        branch_id:      Optional branch for per-branch analytics.
        occurred_at:    UTC timestamp of the search.
    """

    tenant_id:     str
    query:         str
    corrected:     str
    intent:        str
    result_ids:    tuple[str, ...]
    latency_ms:    int
    occurred_at:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    selected_id:   str | None = None
    added_to_bill: bool = False
    user_id:       str | None = None
    branch_id:     str | None = None

    @property
    def zero_results(self) -> bool:
        return len(self.result_ids) == 0

    @property
    def position_of_selected(self) -> int | None:
        """
        1-based position of the selected result in the shown list.
        Returns None if nothing was selected or selection not in list.
        Used as the primary training signal for the ML ranker.
        """
        if self.selected_id is None:
            return None
        try:
            return self.result_ids.index(self.selected_id) + 1
        except ValueError:
            return None

    @property
    def was_first_result_selected(self) -> bool:
        return self.position_of_selected == 1
