"""
core/domain/search_query.py

ParsedQuery is the central value object that flows through the entire
search pipeline. Created once by QueryService, read everywhere else.

Design decisions:
  - frozen=True  → immutable after creation; safe to pass across async tasks
  - StrEnum      → values serialize to plain strings in JSON logs
  - No imports from infra or services → pure domain, zero I/O
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class QueryIntent(StrEnum):
    """
    What the user is searching for.

    Determines which search engines are prioritised:
      BARCODE  → direct DB/cache lookup, skip text engines
      BRAND    → lexical engine weighted heavily on name field
      SALT     → lexical engine weighted on salt_composition field
      SYMPTOM  → vector engine weighted heavily (semantic intent)
      GENERIC  → lexical engine weighted on generic_name field
    """

    BARCODE = "barcode"
    BRAND   = "brand"
    SALT    = "salt"
    SYMPTOM = "symptom"
    GENERIC = "generic"


class SearchLanguage(StrEnum):
    """
    Language/locale of the incoming query.
    Used by the spell corrector and phonetic matcher to load
    the correct dictionary.
    """

    EN    = "en"
    HI_IN = "hi-IN"   # Hinglish — Hindi written in Latin script


# ---------------------------------------------------------------------------
# Value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ParsedQuery:
    """
    Immutable value object representing a fully understood search query.

    Created by QueryService.parse() after the full NLP pipeline:
      raw input → normalise → spell-correct → classify intent → tokenise

    All downstream services receive a ParsedQuery, never a raw string.
    This ensures every consumer works with validated, normalised data.

    Attributes:
        original:   The exact string the user typed (preserved for display).
        normalized: Lowercased, stripped — used as the cache key base.
        corrected:  Spell-corrected version sent to search engines.
                    Equals normalized when no correction was made.
        intent:     Classified search intent — drives engine routing.
        tokens:     Immutable tuple of whitespace-split corrected tokens.
        language:   Detected or declared language/locale.
    """

    original:   str
    normalized: str
    corrected:  str
    intent:     QueryIntent
    tokens:     tuple[str, ...]
    language:   SearchLanguage = SearchLanguage.EN

    # -------------------------------------------------------------------------
    # Derived properties (computed, not stored)
    # -------------------------------------------------------------------------

    @property
    def was_corrected(self) -> bool:
        """True when the spell corrector changed the query."""
        return self.corrected != self.normalized

    @property
    def is_barcode(self) -> bool:
        return self.intent is QueryIntent.BARCODE

    @property
    def is_symptom_query(self) -> bool:
        return self.intent is QueryIntent.SYMPTOM

    @property
    def is_salt_query(self) -> bool:
        return self.intent is QueryIntent.SALT

    @property
    def token_count(self) -> int:
        return len(self.tokens)

    @property
    def is_single_token(self) -> bool:
        return self.token_count == 1

    # -------------------------------------------------------------------------
    # Factory helpers
    # -------------------------------------------------------------------------

    @classmethod
    def build(
        cls,
        *,
        original: str,
        corrected: str,
        intent: QueryIntent,
        language: SearchLanguage = SearchLanguage.EN,
    ) -> "ParsedQuery":
        """
        Preferred factory used by QueryService.
        Derives normalized and tokens automatically so callers
        never compute them separately.
        """
        normalized = original.strip().lower()
        return cls(
            original=original,
            normalized=normalized,
            corrected=corrected.strip().lower(),
            intent=intent,
            tokens=tuple(corrected.strip().lower().split()),
            language=language,
        )

    @classmethod
    def passthrough(
        cls,
        raw: str,
        language: SearchLanguage = SearchLanguage.EN,
    ) -> "ParsedQuery":
        """
        Minimal factory for tests and fallback paths.
        No spell correction, intent defaults to BRAND.
        """
        normalized = raw.strip().lower()
        return cls(
            original=raw,
            normalized=normalized,
            corrected=normalized,
            intent=QueryIntent.BRAND,
            tokens=tuple(normalized.split()),
            language=language,
        )

    # -------------------------------------------------------------------------
    # Representation
    # -------------------------------------------------------------------------

    def __str__(self) -> str:
        correction = f' → "{self.corrected}"' if self.was_corrected else ""
        return f'ParsedQuery("{self.original}"{correction} [{self.intent}])'
