"""
core/domain/tenant.py

Tenant and ApiKey value objects.

A Tenant represents one client application (pharmacy branch, clinic, HRMS).
An ApiKey is the credential that client uses to authenticate requests.

Design decisions:
  - Value objects, not entities → identified by their values, not a mutable ID
  - No ORM decorators here → infra/db/models.py handles persistence
  - ApiKey.raw_key is never stored — only the hashed form persists in the DB
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# ApiKey
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ApiKey:
    """
    Represents a validated API key credential.

    Attributes:
        key_id:       Unique identifier (UUID stored in DB).
        tenant_id:    The tenant this key belongs to.
        hashed_key:   Bcrypt hash of the raw key (raw is never stored).
        is_active:    False if key has been revoked.
        rate_limit:   Requests per minute allowed for this key.
        created_at:   UTC timestamp of key creation.
        expires_at:   Optional expiry; None means non-expiring.
    """

    key_id:      str
    tenant_id:   str
    hashed_key:  str
    is_active:   bool = True
    rate_limit:  int  = 300
    created_at:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at:  datetime | None = None

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    @property
    def is_valid(self) -> bool:
        return self.is_active and not self.is_expired


# ---------------------------------------------------------------------------
# Tenant
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Tenant:
    """
    Represents one client of the MedSearch service.

    Examples:
      - "pharmacy_mumbai_branch_3"  → PharmEasy clone, branch 3
      - "clinic_delhi_1"            → clinic management system
      - "hrms_cultus"               → Cultus HRMS system

    Attributes:
        tenant_id:      Slug-style unique identifier (used as key prefix).
        display_name:   Human-readable name for dashboards / logs.
        allowed_indexes: Indexes this tenant is allowed to search/index.
                         E.g. ["medicines"] for pharmacy, ["doctors"] for clinic.
        is_active:      False if tenant account is suspended.
        created_at:     UTC timestamp.
    """

    tenant_id:       str
    display_name:    str
    allowed_indexes: frozenset[str] = field(default_factory=frozenset)
    is_active:       bool = True
    created_at:      datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def can_access_index(self, index: str) -> bool:
        """
        Returns True if this tenant is permitted to search/index the
        given index. An empty allowed_indexes set means all indexes allowed
        (useful for superadmin tenants).
        """
        if not self.allowed_indexes:
            return True
        return index in self.allowed_indexes

    def __str__(self) -> str:
        return f"Tenant({self.tenant_id})"
