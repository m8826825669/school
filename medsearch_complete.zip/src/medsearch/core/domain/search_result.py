"""
core/domain/search_result.py

Result value objects produced by SearchService and consumed by the API layer.

Design decisions:
  - frozen=True → immutable; results don't change after ranking
  - SearchHit is engine-agnostic — the API layer never knows whether a result
    came from Typesense or Qdrant
  - RankedHit extends SearchHit with ML ranker score, used post-rerank
  - SearchResponse is the final envelope returned to callers
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Hit — single result item from one search engine
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SearchHit:
    """
    One result from a search engine, before re-ranking.

    Attributes:
        doc_id:  Tenant-scoped document identifier (e.g. "med_123").
        score:   Normalised relevance score in [0.0, 1.0].
                 BM25 scores are normalised by TypesenseEngine.
                 Cosine similarity is already in [0, 1] from Qdrant.
        payload: Raw document fields returned by the engine.
                 Contains name, price, stock_qty, etc.
        source:  Which engine produced this hit.
                 Values: "typesense" | "qdrant" | "phonetic" | "cache"
    """

    doc_id:  str
    score:   float
    payload: dict[str, Any] = field(default_factory=dict)
    source:  str = "unknown"

    def get(self, key: str, default: Any = None) -> Any:
        """Convenience accessor for payload fields."""
        return self.payload.get(key, default)

    @property
    def name(self) -> str:
        return str(self.payload.get("name", ""))

    @property
    def price(self) -> float:
        return float(self.payload.get("price", 0.0))

    @property
    def stock_qty(self) -> int:
        return int(self.payload.get("stock_qty", 0))

    @property
    def is_in_stock(self) -> bool:
        return self.stock_qty > 0


# ---------------------------------------------------------------------------
# RankedHit — hit after ML re-ranking
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RankedHit:
    """
    SearchHit annotated with the ML ranker's final score.

    Produced by IRanker.rerank() and used directly in SearchResponse.

    Attributes:
        hit:          Original SearchHit from the merge step.
        rank_score:   Score assigned by the ML ranker (higher = better).
        rank_reason:  Optional human-readable explanation (useful for debug).
    """

    hit:          SearchHit
    rank_score:   float
    rank_reason:  str = ""

    # Proxy the most-used hit attributes so callers don't chain .hit.x
    @property
    def doc_id(self) -> str:
        return self.hit.doc_id

    @property
    def payload(self) -> dict[str, Any]:
        return self.hit.payload

    @property
    def source(self) -> str:
        return self.hit.source

    @property
    def name(self) -> str:
        return self.hit.name

    @property
    def is_in_stock(self) -> bool:
        return self.hit.is_in_stock

    def to_dict(self) -> dict[str, Any]:
        """Serialise for JSON response."""
        return {
            "doc_id":     self.doc_id,
            "score":      round(self.rank_score, 4),
            "payload":    self.payload,
            "source":     self.source,
        }


# ---------------------------------------------------------------------------
# SearchResponse — final envelope returned to API layer
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SearchResponse:
    """
    Complete search response returned by SearchService.

    Attributes:
        hits:            Ordered list of ranked results (best first).
        total:           Total candidate count before limit was applied.
        corrected_query: Spell-corrected query if it differed from input,
                         else None. Displayed as "Did you mean …?" in UI.
        latency_ms:      End-to-end pipeline latency in milliseconds.
        tenant_id:       Echoed back so clients can correlate responses.
    """

    hits:            list[RankedHit]
    total:           int
    corrected_query: str | None
    latency_ms:      int
    tenant_id:       str

    # -------------------------------------------------------------------------
    # Derived helpers
    # -------------------------------------------------------------------------

    @property
    def is_empty(self) -> bool:
        return len(self.hits) == 0

    @property
    def hit_count(self) -> int:
        return len(self.hits)

    @property
    def top_hit(self) -> RankedHit | None:
        return self.hits[0] if self.hits else None

    # -------------------------------------------------------------------------
    # Serialisation (used by RedisStore.set_json and API schema)
    # -------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "hits":            [h.to_dict() for h in self.hits],
            "total":           self.total,
            "corrected_query": self.corrected_query,
            "latency_ms":      self.latency_ms,
            "tenant_id":       self.tenant_id,
        }

    @classmethod
    def empty(cls, tenant_id: str, latency_ms: int = 0) -> "SearchResponse":
        """Factory for no-results responses — avoids scattered empty literals."""
        return cls(
            hits=[],
            total=0,
            corrected_query=None,
            latency_ms=latency_ms,
            tenant_id=tenant_id,
        )
