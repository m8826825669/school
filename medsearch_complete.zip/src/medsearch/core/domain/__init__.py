"""
core/domain/__init__.py

Public surface of the domain layer.
Import from here, not from individual modules:

    from medsearch.core.domain import ParsedQuery, QueryIntent, SearchResponse
"""

from medsearch.core.domain.events import SearchEvent
from medsearch.core.domain.search_query import ParsedQuery, QueryIntent, SearchLanguage
from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse
from medsearch.core.domain.tenant import ApiKey, Tenant

__all__ = [
    # Search query
    "ParsedQuery",
    "QueryIntent",
    "SearchLanguage",
    # Search result
    "SearchHit",
    "RankedHit",
    "SearchResponse",
    # Tenant
    "Tenant",
    "ApiKey",
    # Events
    "SearchEvent",
]
