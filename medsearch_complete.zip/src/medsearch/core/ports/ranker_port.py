"""
core/ports/ranker_port.py

IRanker — abstract contract for the ML re-ranking model.

Implementation (infra/ml/lgbm_ranker.py): LightGBM LambdaRank model
trained on pharmacist click data from SearchEvent logs.

The ranker receives the merged candidate pool from RRF (up to 30 hits)
and returns them reordered by learned relevance, taking into account:
  - query-document text match scores
  - stock level and availability
  - sales velocity (30d / 7d)
  - profit margin
  - user history (which medicines this pharmacist tends to pick)
  - time of day patterns
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import RankedHit, SearchHit


@runtime_checkable
class IRanker(Protocol):
    """
    Re-ranks a list of candidate hits using a learned model.

    The ranker is the last step before results are returned to the caller.
    It is synchronous because LightGBM inference is CPU-bound and fast
    (< 3ms for 30 candidates) — no need for async.
    """

    def rerank(
        self,
        query:      ParsedQuery,
        candidates: list[SearchHit],
        context:    dict[str, Any],
    ) -> list[RankedHit]:
        """
        Re-rank candidates and return them as RankedHit objects.

        Args:
            query:      The parsed query (provides intent, tokens, language).
            candidates: Merged pool from RRF (typically 20–30 hits).
            context:    Runtime context passed from the API request:
                          - "user_id":       str | None  (for personalisation)
                          - "boost":         dict        (caller-specified field boosts)
                          - "hour":          int         (0–23, hour of day)
                          - "tenant_id":     str

        Returns:
            RankedHit list ordered best-first, same length as candidates.
            Never raises — falls back to RRF score order on model failure.
        """
        ...

    @property
    def is_ready(self) -> bool:
        """
        True if the model is loaded and ready to score.
        SearchService checks this at startup and falls back to
        score-based ordering when False (e.g. model file missing in dev).
        """
        ...
