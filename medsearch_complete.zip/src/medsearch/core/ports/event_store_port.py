"""
core/ports/event_store_port.py

IEventStore — abstract contract for persisting SearchEvent domain events.

Implementation (infra/db/repositories/event_repo.py): async SQLAlchemy
writing to the search_events PostgreSQL table.

Events are persisted asynchronously after the response is sent —
they never block the search path.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from medsearch.core.domain.events import SearchEvent


@runtime_checkable
class IEventStore(Protocol):
    """Append-only store for search analytics events."""

    async def append(self, event: SearchEvent) -> None:
        """
        Persist one search event.

        Fire-and-forget: called via asyncio.create_task() so failures
        are logged but never propagate to the caller.
        """
        ...

    async def get_zero_result_queries(
        self,
        tenant_id: str,
        limit:     int = 50,
    ) -> list[tuple[str, int]]:
        """
        Return (query, count) pairs for queries that returned no results.
        Used by the analytics dashboard to identify catalog gaps.
        """
        ...
