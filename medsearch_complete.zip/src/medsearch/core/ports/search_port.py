"""
core/ports/search_port.py

ISearchEngine — the abstract contract every search engine adapter must satisfy.

Why Protocol instead of ABC?
  - Structural subtyping: TypesenseEngine satisfies ISearchEngine without
    explicitly inheriting it. Easier to mock in tests.
  - runtime_checkable: lets us do isinstance(engine, ISearchEngine) in
    dependency wiring to catch mis-wired adapters at startup.

Implementations (in infra/search/):
  - TypesenseEngine  → BM25 / lexical
  - QdrantEngine     → vector / semantic
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import SearchHit


@runtime_checkable
class ISearchEngine(Protocol):
    """
    Contract for a single search engine adapter.

    SearchService holds two instances: one lexical, one vector.
    Both implement this same interface so the service never knows
    which technology is underneath.
    """

    async def search(
        self,
        query:     ParsedQuery,
        tenant_id: str,
        index:     str,
        filters:   dict[str, Any],
        limit:     int,
    ) -> list[SearchHit]:
        """
        Execute a search and return an unranked list of hits.

        Args:
            query:     Fully parsed and spell-corrected query.
            tenant_id: Tenant scope — data isolation guarantee.
            index:     Collection name within the tenant (e.g. "medicines").
            filters:   Key/value filter conditions (e.g. {"stock_qty": {"gt": 0}}).
            limit:     Maximum number of hits to return (pre-rerank pool size).

        Returns:
            List of SearchHit objects, ordered by engine's own relevance score.
            Empty list on no results or engine failure (never raises).
        """
        ...

    async def upsert(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
        document:  dict[str, Any],
    ) -> None:
        """
        Insert or update a document in the engine's index.

        Called by IndexService when a medicine/product record changes.
        Must be idempotent — safe to call multiple times with the same doc_id.
        """
        ...

    async def delete(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
    ) -> None:
        """Remove a document from the index. No-op if doc_id not found."""
        ...

    async def create_index(
        self,
        tenant_id: str,
        index:     str,
        schema:    dict[str, Any],
    ) -> None:
        """
        Create the index/collection for a new tenant.
        Called once during tenant onboarding. No-op if already exists.
        """
        ...

    async def health(self) -> bool:
        """Return True if the engine is reachable and healthy."""
        ...
