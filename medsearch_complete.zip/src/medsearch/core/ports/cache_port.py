"""
core/ports/cache_port.py

ICacheStore — abstract contract for the L1 result cache.

Implementation (infra/cache/redis_store.py): Redis with JSON serialisation.

The cache sits between the API layer and the search engines.
Cache hits skip all engines entirely, returning in < 1ms.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ICacheStore(Protocol):
    """
    Key-value cache with TTL support and pattern-based invalidation.

    Keys follow the convention:  "{tenant_id}:{index}:{query_hash}"
    This means invalidation on medicine update only needs to clear
    keys for that specific tenant+index, not the whole cache.
    """

    async def get(self, key: str) -> bytes | None:
        """Return raw bytes for key, or None if missing/expired."""
        ...

    async def set(self, key: str, value: bytes, ttl: int = 120) -> None:
        """
        Store bytes under key with TTL in seconds.
        Overwrites any existing value.
        """
        ...

    async def delete(self, key: str) -> None:
        """Remove a single key. No-op if key does not exist."""
        ...

    async def delete_pattern(self, pattern: str) -> None:
        """
        Remove all keys matching a glob pattern.
        E.g. delete_pattern("pharmacy_1:medicines:*") clears all
        cached medicine searches for pharmacy branch 1.

        Warning: KEYS scan — use only for targeted invalidation,
        not in hot search paths.
        """
        ...

    async def get_json(self, key: str) -> dict[str, Any] | None:
        """
        Convenience: get + JSON deserialise.
        Returns None on cache miss or deserialisation error.
        """
        ...

    async def set_json(
        self,
        key:   str,
        value: dict[str, Any],
        ttl:   int = 120,
    ) -> None:
        """Convenience: JSON serialise + set."""
        ...

    async def health(self) -> bool:
        """Return True if the cache store is reachable."""
        ...
