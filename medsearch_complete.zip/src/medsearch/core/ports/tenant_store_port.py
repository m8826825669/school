"""
core/ports/tenant_store_port.py

ITenantStore — abstract contract for tenant and API key data access.

Implementation (infra/db/repositories/tenant_repo.py): async SQLAlchemy
with a Redis cache layer for hot API key lookups.

API key validation is on the hot path — every request validates its key.
The implementation caches validated keys in Redis for 60 seconds to avoid
a DB hit on every search request.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from medsearch.core.domain.tenant import ApiKey, Tenant


@runtime_checkable
class ITenantStore(Protocol):
    """Read/write access to tenant and API key records."""

    async def get_tenant(self, tenant_id: str) -> Tenant | None:
        """Return Tenant by ID, or None if not found."""
        ...

    async def get_api_key(self, raw_key: str) -> ApiKey | None:
        """
        Look up an ApiKey by its raw (unhashed) value.

        Implementation hashes the input and compares against stored hashes.
        Returns None if the key is not found, inactive, or expired.

        This method is called on EVERY request — must be fast.
        Redis caching of validated keys is expected in the implementation.
        """
        ...

    async def create_tenant(self, tenant: Tenant) -> None:
        """Persist a new tenant record."""
        ...

    async def create_api_key(self, api_key: ApiKey) -> None:
        """Persist a new API key record."""
        ...

    async def revoke_api_key(self, key_id: str) -> None:
        """Mark an API key as inactive. Invalidates Redis cache entry."""
        ...
