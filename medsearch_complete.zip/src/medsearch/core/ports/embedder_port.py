"""
core/ports/embedder_port.py

IEmbedder — abstract contract for the sentence embedding model.

Implementation (infra/ml/embedder.py): sentence-transformers running
the all-MiniLM-L6-v2 model in a thread pool to avoid blocking the
asyncio event loop.

Used by:
  - QdrantEngine.search() — encodes the query text at search time
  - IndexService — encodes document text when indexing a new medicine
  - scripts/build_index.py — bulk-encodes the full catalogue
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class IEmbedder(Protocol):
    """Converts text into dense vector representations."""

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Encode a batch of texts into embedding vectors.

        Args:
            texts: One or more strings to encode. Batching is more
                   efficient than calling embed_one() in a loop.

        Returns:
            List of float vectors, one per input text.
            Vector dimension is fixed by the model (384 for MiniLM).
        """
        ...

    async def embed_one(self, text: str) -> list[float]:
        """
        Encode a single text. Convenience wrapper around embed().

        Used for query encoding at search time where batch size is always 1.
        """
        ...

    @property
    def dimensions(self) -> int:
        """
        Output vector dimension.
        Must match the vector size configured in Qdrant's collection.
        """
        ...
