"""
services/suggest_service.py

SuggestService — returns autocomplete suggestions for a given prefix.

Two-tier strategy:
  Tier 1: Redis trie (sub-millisecond, in-memory prefix lookup)
  Tier 2: Typesense prefix search (fallback if trie is cold or empty)

The trie is the primary path because:
  - O(log N) lookup regardless of catalog size
  - No network round-trip beyond Redis (on LAN this is < 0.5ms)
  - Warm after IndexService.rebuild() runs at startup

The Typesense fallback handles cold starts (empty trie) and very long
catalogs where the trie may not be fully warm yet.

Single responsibility: return autocomplete suggestions. Nothing else.
"""

from __future__ import annotations

import structlog

from medsearch.core.domain.search_query import ParsedQuery, SearchLanguage
from medsearch.core.ports.search_port import ISearchEngine
from medsearch.infra.cache.redis_trie import RedisTrie

log = structlog.get_logger(__name__)

# Minimum prefix length before suggestions are shown
_MIN_PREFIX = 2

# Maximum suggestions returned to the caller
_MAX_SUGGESTIONS = 8


class SuggestService:
    """
    Returns autocomplete suggestions via a two-tier lookup strategy.

    Injected:
      - trie:           RedisTrie      (primary — in-memory prefix trie)
      - lexical_engine: ISearchEngine  (fallback — Typesense prefix search)
    """

    def __init__(
        self,
        trie:           RedisTrie,
        lexical_engine: ISearchEngine,
    ) -> None:
        self._trie    = trie
        self._lexical = lexical_engine

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def suggest(
        self,
        prefix:    str,
        tenant_id: str,
        index:     str,
        limit:     int = _MAX_SUGGESTIONS,
    ) -> list[str]:
        """
        Return up to `limit` medicine names starting with `prefix`.

        Args:
            prefix:    The characters the user has typed so far.
            tenant_id: Tenant scope.
            index:     Collection name (e.g. "medicines").
            limit:     Maximum suggestions to return.

        Returns:
            List of medicine name strings, ordered by relevance.
            Empty list if prefix is too short or nothing matches.
        """
        prefix = prefix.strip().lower()
        if len(prefix) < _MIN_PREFIX:
            return []

        # Tier 1: Redis trie
        suggestions = await self._trie.suggest(tenant_id, index, prefix, limit)
        if suggestions:
            log.debug(
                "suggest.trie_hit",
                prefix=prefix, count=len(suggestions),
            )
            return suggestions

        # Tier 2: Typesense fallback
        log.debug("suggest.trie_miss_fallback", prefix=prefix)
        return await self._lexical_suggest(prefix, tenant_id, index, limit)

    # -------------------------------------------------------------------------
    # Private: Typesense fallback
    # -------------------------------------------------------------------------

    async def _lexical_suggest(
        self,
        prefix:    str,
        tenant_id: str,
        index:     str,
        limit:     int,
    ) -> list[str]:
        """
        Use the lexical engine's prefix search as a fallback suggestion source.
        Extracts the name field from returned hits.
        """
        query = ParsedQuery.passthrough(prefix, SearchLanguage.EN)
        try:
            hits = await self._lexical.search(
                query     = query,
                tenant_id = tenant_id,
                index     = index,
                filters   = {"stock_qty": {"gt": 0}},
                limit     = limit,
            )
            seen: set[str] = set()
            suggestions: list[str] = []
            for hit in hits:
                name = hit.name
                if name and name not in seen:
                    seen.add(name)
                    suggestions.append(name)
            return suggestions
        except Exception as exc:
            log.warning("suggest.fallback_failed", prefix=prefix, error=str(exc))
            return []
