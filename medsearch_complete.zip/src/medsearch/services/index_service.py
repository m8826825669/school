"""
services/index_service.py

IndexService — keeps all search indexes in sync when documents change.

When a medicine is created or updated in the pharmacy DB:
  1. Upsert into Typesense    (lexical index)
  2. Upsert into Qdrant       (vector index, re-embeds the document)
  3. Update Redis trie         (autocomplete suggestions)
  4. Invalidate result cache   (stale results for this tenant+index)

All four steps run in parallel with asyncio.gather.
If any step fails, it is logged but does not block the others —
eventual consistency is acceptable; the pharmacy billing never waits
for index updates.

Single responsibility: fan-out document changes. Nothing else.
"""

from __future__ import annotations

import asyncio
from typing import Any

import structlog

from medsearch.core.ports.cache_port import ICacheStore
from medsearch.core.ports.search_port import ISearchEngine
from medsearch.infra.cache.redis_trie import RedisTrie

log = structlog.get_logger(__name__)


class IndexService:
    """
    Fans out document changes to all search engine adapters.

    Injected dependencies (all ports — no concrete adapters imported here):
      - lexical_engine: ISearchEngine  (Typesense)
      - vector_engine:  ISearchEngine  (Qdrant)
      - cache:          ICacheStore    (Redis — for result cache invalidation)
      - trie:           RedisTrie      (autocomplete — concrete, not a port)
    """

    def __init__(
        self,
        lexical_engine: ISearchEngine,
        vector_engine:  ISearchEngine,
        cache:          ICacheStore,
        trie:           RedisTrie,
    ) -> None:
        self._lexical = lexical_engine
        self._vector  = vector_engine
        self._cache   = cache
        self._trie    = trie

    # -------------------------------------------------------------------------
    # Public API: upsert
    # -------------------------------------------------------------------------

    async def upsert(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
        document:  dict[str, Any],
    ) -> None:
        """
        Propagate a document insert or update to all indexes.

        Args:
            tenant_id: Tenant scope.
            index:     Collection name (e.g. "medicines").
            doc_id:    Stable document identifier (e.g. "med_123").
            document:  Full document fields. Must include "name" for trie.

        This method is called from Django's post_save signal and must not
        block the HTTP response. Fire it with asyncio.create_task().
        """
        name = document.get("name", "")

        results = await asyncio.gather(
            self._upsert_lexical(tenant_id, index, doc_id, document),
            self._upsert_vector(tenant_id, index, doc_id, document),
            self._update_trie(tenant_id, index, name, doc_id),
            self._invalidate_cache(tenant_id, index),
            return_exceptions=True,
        )

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                step = ["lexical", "vector", "trie", "cache"][i]
                log.error(
                    "index.step_failed",
                    step      = step,
                    tenant_id = tenant_id,
                    doc_id    = doc_id,
                    error     = str(result),
                )

        log.info("index.upserted", tenant_id=tenant_id, index=index, doc_id=doc_id)

    # -------------------------------------------------------------------------
    # Public API: delete
    # -------------------------------------------------------------------------

    async def delete(
        self,
        tenant_id: str,
        index:     str,
        doc_id:    str,
    ) -> None:
        """
        Remove a document from all indexes.

        Called when a medicine is deleted or marked out-of-catalogue.
        """
        results = await asyncio.gather(
            self._lexical.delete(tenant_id, index, doc_id),
            self._vector.delete(tenant_id, index, doc_id),
            self._trie.remove(tenant_id, index, doc_id),
            self._invalidate_cache(tenant_id, index),
            return_exceptions=True,
        )

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                step = ["lexical", "vector", "trie", "cache"][i]
                log.error(
                    "index.delete_step_failed",
                    step=step, tenant_id=tenant_id,
                    doc_id=doc_id, error=str(result),
                )

        log.info("index.deleted", tenant_id=tenant_id, index=index, doc_id=doc_id)

    # -------------------------------------------------------------------------
    # Public API: create_index
    # -------------------------------------------------------------------------

    async def create_index(
        self,
        tenant_id: str,
        index:     str,
        schema:    dict[str, Any],
    ) -> None:
        """
        Provision a new tenant's index in all engines.

        Called once during tenant onboarding. Idempotent — safe to call
        if index already exists.
        """
        await asyncio.gather(
            self._lexical.create_index(tenant_id, index, schema),
            self._vector.create_index(tenant_id, index, schema),
            return_exceptions=True,
        )
        log.info("index.created", tenant_id=tenant_id, index=index)

    # -------------------------------------------------------------------------
    # Private: per-engine helpers (keep each step isolated for error handling)
    # -------------------------------------------------------------------------

    async def _upsert_lexical(
        self, tenant_id: str, index: str, doc_id: str, document: dict[str, Any]
    ) -> None:
        await self._lexical.upsert(tenant_id, index, doc_id, document)

    async def _upsert_vector(
        self, tenant_id: str, index: str, doc_id: str, document: dict[str, Any]
    ) -> None:
        await self._vector.upsert(tenant_id, index, doc_id, document)

    async def _update_trie(
        self, tenant_id: str, index: str, name: str, doc_id: str
    ) -> None:
        if name:
            await self._trie.add(tenant_id, index, name, doc_id)

    async def _invalidate_cache(self, tenant_id: str, index: str) -> None:
        """
        Invalidate all cached search results for this tenant+index.

        Uses pattern deletion so every cached query is cleared when the
        catalog changes. TTL is 120s so at worst results are stale for 2m
        before natural expiry — invalidation makes it immediate.
        """
        pattern = f"{tenant_id}:{index}:*"
        await self._cache.delete_pattern(pattern)
