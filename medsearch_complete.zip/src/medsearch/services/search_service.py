"""
services/search_service.py

SearchService — orchestrates the complete search pipeline.

Pipeline (every request):
  1. L1 cache check     — return immediately if hit (< 1ms)
  2. Parallel search    — fire lexical + vector engines simultaneously
  3. RRF merge          — combine ranked lists from both engines
  4. ML re-rank         — reorder by learned model score
  5. Cache result       — store for next identical query (120s TTL)

This service depends on four ports (injected interfaces):
  - ISearchEngine   × 2  (lexical + vector)
  - ICacheStore          (Redis)
  - IRanker              (LightGBM)

It has zero knowledge of Typesense, Qdrant, Redis, or LightGBM.
Swapping any engine means wiring a new adapter — no change here.

Single responsibility: run the pipeline. Nothing else.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict

import structlog

from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import RankedHit, SearchHit, SearchResponse
from medsearch.core.ports.cache_port import ICacheStore
from medsearch.core.ports.ranker_port import IRanker
from medsearch.core.ports.search_port import ISearchEngine

log = structlog.get_logger(__name__)

# Reciprocal Rank Fusion constant — 60 is the standard recommended value.
# Higher k smooths differences between engine rankings; lower k amplifies them.
_RRF_K = 60

# Number of candidates fetched from each engine before RRF + rerank
_CANDIDATE_POOL = 30


class SearchService:
    """
    Orchestrates the full search pipeline via injected port interfaces.

    Constructed once at application startup and reused across all requests.
    All state is in the injected adapters — this class is itself stateless.
    """

    def __init__(
        self,
        lexical_engine: ISearchEngine,
        vector_engine:  ISearchEngine,
        cache:          ICacheStore,
        ranker:         IRanker,
    ) -> None:
        self._lexical = lexical_engine
        self._vector  = vector_engine
        self._cache   = cache
        self._ranker  = ranker

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def search(
        self,
        query:     ParsedQuery,
        tenant_id: str,
        index:     str,
        filters:   dict,
        boost:     dict,
        user_id:   str | None,
        limit:     int,
    ) -> SearchResponse:
        """
        Execute the full search pipeline and return a ranked SearchResponse.

        Args:
            query:     Fully parsed and NLP-processed query from QueryService.
            tenant_id: Tenant scope — isolates data and cache keys.
            index:     Collection name (e.g. "medicines", "doctors").
            filters:   Field filters applied inside each engine
                       (e.g. {"stock_qty": {"gt": 0}}).
            boost:     Caller-specified field boosts forwarded to the ranker
                       (e.g. {"margin_pct": 1.5}).
            user_id:   Optional pharmacist ID for personalisation features.
            limit:     Maximum results to return (applied after rerank).

        Returns:
            SearchResponse with ranked hits, latency, and correction info.
        """
        t0        = time.monotonic()
        cache_key = self._cache_key(tenant_id, index, query.normalized)

        # --- Stage 1: L1 cache ---
        cached = await self._cache.get_json(cache_key)
        if cached is not None:
            log.debug("search.cache_hit", tenant=tenant_id, query=query.normalized)
            return SearchResponse(**cached)

        # --- Stage 2: Parallel search ---
        candidates = await self._parallel_search(query, tenant_id, index, filters)

        # --- Stage 3: ML re-rank ---
        context = {
            "user_id":  user_id,
            "boost":    boost,
            "tenant_id": tenant_id,
        }
        ranked = self._ranker.rerank(query, candidates, context)

        # --- Stage 4: Build response ---
        response = SearchResponse(
            hits            = ranked[:limit],
            total           = len(candidates),
            corrected_query = query.corrected if query.was_corrected else None,
            latency_ms      = int((time.monotonic() - t0) * 1000),
            tenant_id       = tenant_id,
        )

        # --- Stage 5: Populate cache (non-blocking) ---
        asyncio.create_task(
            self._cache.set_json(cache_key, response.to_dict(), ttl=120)
        )

        log.info(
            "search.complete",
            tenant    = tenant_id,
            query     = query.original,
            hits      = response.hit_count,
            latency   = response.latency_ms,
            corrected = query.was_corrected,
        )
        return response

    # -------------------------------------------------------------------------
    # Private: parallel fetch + merge
    # -------------------------------------------------------------------------

    async def _parallel_search(
        self,
        query:     ParsedQuery,
        tenant_id: str,
        index:     str,
        filters:   dict,
    ) -> list[SearchHit]:
        """
        Fire lexical and vector engines simultaneously with asyncio.gather.

        Both results arrive together (bounded by the slower engine).
        If one engine fails, its exception is caught and treated as empty —
        the other engine's results still form a valid response.
        """
        lex_task = asyncio.create_task(
            self._lexical.search(query, tenant_id, index, filters, _CANDIDATE_POOL)
        )
        vec_task = asyncio.create_task(
            self._vector.search(query, tenant_id, index, filters, _CANDIDATE_POOL)
        )

        lex_hits, vec_hits = await asyncio.gather(
            lex_task, vec_task, return_exceptions=True
        )

        safe_lex = lex_hits if isinstance(lex_hits, list) else []
        safe_vec = vec_hits if isinstance(vec_hits, list) else []

        if isinstance(lex_hits, Exception):
            log.warning("search.lexical_engine_failed", error=str(lex_hits))
        if isinstance(vec_hits, Exception):
            log.warning("search.vector_engine_failed",  error=str(vec_hits))

        return self._rrf_merge([safe_lex, safe_vec])

    # -------------------------------------------------------------------------
    # Private: Reciprocal Rank Fusion
    # -------------------------------------------------------------------------

    def _rrf_merge(self, ranked_lists: list[list[SearchHit]]) -> list[SearchHit]:
        """
        Merge multiple ranked lists using Reciprocal Rank Fusion.

        RRF score for document d:  Σ  1 / (k + rank(d, list_i))

        Properties:
          - Robust: works even when engine scores are on different scales
          - Additive: a doc appearing in both lists beats one in only one
          - Stable: consistent ordering with no score normalisation needed

        Returns up to _CANDIDATE_POOL unique hits ordered by RRF score.
        """
        scores: dict[str, float]    = defaultdict(float)
        docs:   dict[str, SearchHit] = {}

        for ranked in ranked_lists:
            for rank, hit in enumerate(ranked, start=1):
                scores[hit.doc_id] += 1.0 / (_RRF_K + rank)
                # First engine's hit wins on conflict (usually more fields)
                if hit.doc_id not in docs:
                    docs[hit.doc_id] = hit

        merged = sorted(
            docs.values(),
            key=lambda h: scores[h.doc_id],
            reverse=True,
        )
        return merged[:_CANDIDATE_POOL]

    # -------------------------------------------------------------------------
    # Private: cache key
    # -------------------------------------------------------------------------

    @staticmethod
    def _cache_key(tenant_id: str, index: str, normalized_query: str) -> str:
        """
        Deterministic cache key scoped to tenant + index + query.

        Format: "{tenant_id}:{index}:{query}"
        Example: "pharmacy_1:medicines:paracetamol"

        The normalized query is used (not original) so "Paracetamol " and
        "paracetamol" map to the same cache entry.
        """
        return f"{tenant_id}:{index}:{normalized_query}"
