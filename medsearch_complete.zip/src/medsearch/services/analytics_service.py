"""
services/analytics_service.py

AnalyticsService — records search events for ML training and dashboards.

Every search request produces one SearchEvent that is persisted
asynchronously after the HTTP response is already sent. This means:
  - Zero latency impact on the billing counter
  - Failures in analytics never affect search availability

The event log is the training data for the LightGBM ranker.
After 30 days of data, the ranker retrains weekly and improves.

Key metrics exposed via get_zero_result_summary():
  - Which queries return no results (catalog gaps)
  - CTR per position (ranking quality signal)
  - p99 search latency

Single responsibility: log and query search events. Nothing else.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import structlog

from medsearch.core.domain.events import SearchEvent
from medsearch.core.domain.search_query import ParsedQuery
from medsearch.core.domain.search_result import SearchResponse
from medsearch.core.ports.event_store_port import IEventStore

log = structlog.get_logger(__name__)


class AnalyticsService:
    """
    Logs search interactions as SearchEvent domain events.

    Injected:
      - event_store: IEventStore  (PostgreSQL via EventRepository)
    """

    def __init__(self, event_store: IEventStore) -> None:
        self._store = event_store

    # -------------------------------------------------------------------------
    # Public API: log_search
    # -------------------------------------------------------------------------

    def log_search(
        self,
        query:     ParsedQuery,
        response:  SearchResponse,
        user_id:   str | None = None,
        branch_id: str | None = None,
    ) -> None:
        """
        Schedule a SearchEvent to be persisted in the background.

        Called with asyncio.create_task() so the event loop is never blocked.
        The caller (search endpoint) does not await this — it fires and forgets.

        Args:
            query:     The parsed query that was executed.
            response:  The SearchResponse returned to the caller.
            user_id:   Optional pharmacist identifier.
            branch_id: Optional branch identifier for per-branch analytics.
        """
        event = SearchEvent(
            tenant_id  = response.tenant_id,
            query      = query.original,
            corrected  = query.corrected,
            intent     = str(query.intent),
            result_ids = tuple(h.doc_id for h in response.hits),
            latency_ms = response.latency_ms,
            occurred_at= datetime.now(timezone.utc),
            user_id    = user_id,
            branch_id  = branch_id,
        )
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._persist(event))
        except RuntimeError:
            # No running loop (e.g. in sync test context) — schedule via ensure_future
            asyncio.ensure_future(self._persist(event))

    # -------------------------------------------------------------------------
    # Public API: record_selection
    # -------------------------------------------------------------------------

    async def record_selection(
        self,
        tenant_id:     str,
        query:         str,
        selected_id:   str,
        added_to_bill: bool = False,
    ) -> None:
        """
        Record which search result the pharmacist selected.

        Called from a separate endpoint when the user picks a medicine.
        Updates the most recent SearchEvent for this (tenant, query) pair.

        This selection signal is the primary training label for the ranker:
          - Position 1 selected → strong positive signal
          - Position 8 selected → model ranked it too low
        """
        # In production this would UPDATE the most recent matching event row.
        # For Phase 4 we log the intent and leave the UPDATE for Phase 5 (API layer).
        log.info(
            "analytics.selection_recorded",
            tenant_id     = tenant_id,
            query         = query,
            selected_id   = selected_id,
            added_to_bill = added_to_bill,
        )

    # -------------------------------------------------------------------------
    # Public API: get_zero_result_summary
    # -------------------------------------------------------------------------

    async def get_zero_result_summary(
        self,
        tenant_id: str,
        limit:     int = 50,
    ) -> list[dict]:
        """
        Return the top queries that returned no results.

        Used by the analytics dashboard to identify catalog gaps.
        A pharmacist searching for "glimepiride" and getting nothing
        means that medicine should be added to the catalog.
        """
        try:
            pairs = await self._store.get_zero_result_queries(tenant_id, limit)
            return [{"query": q, "count": c} for q, c in pairs]
        except Exception as exc:
            log.error("analytics.zero_result_query_failed", error=str(exc))
            return []

    # -------------------------------------------------------------------------
    # Private: persistence (runs in background task)
    # -------------------------------------------------------------------------

    async def _persist(self, event: SearchEvent) -> None:
        """
        Persist the event to the store.

        Wrapped so exceptions are logged and swallowed — analytics failures
        must never propagate to the search response path.
        """
        try:
            await self._store.append(event)
            if event.zero_results:
                log.warning(
                    "analytics.zero_results",
                    tenant_id = event.tenant_id,
                    query     = event.query,
                    intent    = event.intent,
                )
        except Exception as exc:
            log.error("analytics.persist_failed", error=str(exc), query=event.query)
