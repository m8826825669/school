"""
services/query_service.py

QueryService — turns a raw string into a ParsedQuery domain object.

Pipeline (in order):
  1. Normalise    — strip, lowercase
  2. Detect early — barcode check before any processing (fast path)
  3. Spell-correct — SymSpell corrects typos against medicine dictionary
  4. Classify intent — regex + keyword rules determine routing
  5. Build ParsedQuery — immutable value object returned to caller

This service is synchronous — every step is CPU-bound and fast (< 2ms total).
It depends only on SpellCorrector from infra/nlp; it never touches any network.

Single responsibility: understand the query. Nothing else.
"""

from __future__ import annotations

import re
from medsearch.core.domain.search_query import ParsedQuery, QueryIntent, SearchLanguage
from medsearch.infra.nlp.spell_corrector import SpellCorrector


# ---------------------------------------------------------------------------
# Classification constants
# ---------------------------------------------------------------------------

# Minimum query length — shorter strings are not worth processing
MIN_QUERY_LENGTH = 2

# Regex for barcode detection: 8–14 digits, nothing else
_BARCODE_RE = re.compile(r"^\d{8,14}$")

# Regex for salt/strength patterns: "500mg", "5ml", "0.5%", "hcl", "sodium"
_SALT_RE = re.compile(
    r"\b(\d+(\.\d+)?\s*(mg|ml|mcg|g|iu|%|units?))(?=\s|$)"
    r"|\b(hcl|hydrochloride|sodium|potassium|sulphate|sulfate|phosphate)\b",
    re.IGNORECASE,
)

# Symptom vocabulary — Hinglish terms included for Indian pharmacy context
_SYMPTOM_WORDS: frozenset[str] = frozenset({
    # English
    "fever", "pain", "cold", "cough", "headache", "migraine",
    "vomit", "nausea", "acidity", "gas", "bloating", "allergy",
    "rash", "itching", "infection", "diabetes", "bp", "pressure",
    "cholesterol", "thyroid", "anxiety", "sleep", "insomnia",
    "diarrhea", "diarrhoea", "constipation", "back", "joint",
    "muscle", "throat", "ear", "eye", "skin", "heart",
    # Hinglish
    "bukhar", "dard", "khasi", "jukam", "ulti", "pet",
    "sar", "neend", "khansi", "peeda", "tez",
})

# Generic name indicators — common INN suffixes and patterns
_GENERIC_SUFFIXES = re.compile(
    r"\b\w+(mab|nib|zole|pril|sartan|statin|olol|oxacin|mycin|cillin|cycline)\b",
    re.IGNORECASE,
)


class QueryService:
    """
    Understands raw search queries and produces ParsedQuery domain objects.

    Inject one instance per application — it is stateless after construction.
    The SpellCorrector holds the in-memory dictionary; it is not recreated
    per request.
    """

    def __init__(self, corrector: SpellCorrector) -> None:
        self._corrector = corrector

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def parse(
        self,
        raw: str,
        language: SearchLanguage = SearchLanguage.EN,
    ) -> ParsedQuery:
        """
        Parse a raw query string into a fully understood ParsedQuery.

        Args:
            raw:      The exact string the user typed.
            language: Declared locale (affects symptom vocabulary routing).

        Returns:
            Immutable ParsedQuery ready to be passed to SearchService.
            Never raises — returns a passthrough ParsedQuery on any error.
        """
        try:
            return self._parse_internal(raw, language)
        except Exception:
            # Absolute safety net — search must never crash due to NLP
            return ParsedQuery.passthrough(raw, language)

    def is_valid(self, raw: str) -> bool:
        """True if the query is long enough to be worth processing."""
        return len(raw.strip()) >= MIN_QUERY_LENGTH

    # -------------------------------------------------------------------------
    # Pipeline stages
    # -------------------------------------------------------------------------

    def _parse_internal(
        self,
        raw: str,
        language: SearchLanguage,
    ) -> ParsedQuery:
        normalized = raw.strip().lower()

        # Stage 1: Barcode fast-path — skip all NLP, no correction needed
        if _BARCODE_RE.match(normalized):
            return ParsedQuery.build(
                original=raw,
                corrected=normalized,
                intent=QueryIntent.BARCODE,
                language=language,
            )

        # Stage 2: Spell correction
        corrected = self._corrector.correct(normalized)

        # Stage 3: Intent classification (on corrected text)
        intent = self._classify(corrected, language)

        return ParsedQuery.build(
            original=raw,
            corrected=corrected,
            intent=intent,
            language=language,
        )

    def _classify(self, query: str, language: SearchLanguage) -> QueryIntent:
        """
        Determine routing intent from the corrected query text.

        Rules are evaluated in priority order:
          1. Salt/strength patterns  → SALT
          2. Symptom keywords        → SYMPTOM
          3. Generic name suffixes   → GENERIC
          4. Default                 → BRAND
        """
        if _SALT_RE.search(query):
            return QueryIntent.SALT

        tokens = set(query.split())

        # Expand symptom set for Hinglish when language is hi-IN
        symptom_vocab = _SYMPTOM_WORDS
        if language == SearchLanguage.HI_IN:
            symptom_vocab = _SYMPTOM_WORDS  # already includes Hinglish terms

        if tokens & symptom_vocab:
            return QueryIntent.SYMPTOM

        if _GENERIC_SUFFIXES.search(query):
            return QueryIntent.GENERIC

        return QueryIntent.BRAND
