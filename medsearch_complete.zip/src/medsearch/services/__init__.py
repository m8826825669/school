"""
services/__init__.py

Public surface of the services layer.

Import from here:
    from medsearch.services import SearchService, IndexService, QueryService
"""

from medsearch.services.analytics_service import AnalyticsService
from medsearch.services.index_service import IndexService
from medsearch.services.query_service import QueryService
from medsearch.services.search_service import SearchService
from medsearch.services.suggest_service import SuggestService

__all__ = [
    "QueryService",
    "SearchService",
    "IndexService",
    "SuggestService",
    "AnalyticsService",
]
