"""
src/medsearch/main.py

Application factory — the only place where everything is assembled.

create_app() builds the FastAPI instance:
  1. Lifespan — startup/shutdown hooks for singletons
  2. Middleware — CORS, request IDs, structured logging
  3. Error handlers — consistent JSON error shape
  4. Routers — v1 API routes
  5. Metrics — Prometheus scrape endpoint at /metrics

Usage:
    uvicorn medsearch.main:app --reload --port 8001
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import structlog
from fastapi import FastAPI
from prometheus_fastapi_instrumentator import Instrumentator

from medsearch.api.dependencies import init_singletons, shutdown_singletons
from medsearch.api.error_handlers import register_error_handlers
from medsearch.api.middleware import register_middleware
from medsearch.api.v1.router import router as v1_router
from medsearch.settings import get_settings

# ---------------------------------------------------------------------------
# Structured logging configuration
# ---------------------------------------------------------------------------


def _configure_logging(log_level: str) -> None:
    """
    Configure structlog to emit JSON in production, pretty-printed in dev.
    Call once at startup — before any log lines are emitted.
    """
    level = getattr(logging, log_level.upper(), logging.INFO)
    logging.basicConfig(level=level)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class  = structlog.make_filtering_bound_logger(level),
        context_class  = dict,
        logger_factory = structlog.PrintLoggerFactory(),
        cache_logger_on_first_use = True,
    )


# ---------------------------------------------------------------------------
# Lifespan context manager
# ---------------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Runs startup logic before the first request and shutdown logic on exit.

    Startup:
      - Configure logging
      - Initialise all expensive singletons (Redis, Typesense, embedder, ranker)

    Shutdown:
      - Close Redis connection pool

    The yield point is where FastAPI serves requests.
    """
    settings = get_settings()
    _configure_logging(settings.log_level)

    log = structlog.get_logger(__name__)
    log.info("medsearch.starting", env=settings.app_env, port=settings.app_port)

    # Initialise all singletons (blocking — done before first request)
    init_singletons(settings)

    log.info("medsearch.ready")
    yield

    # Shutdown
    log.info("medsearch.shutting_down")
    await shutdown_singletons()
    log.info("medsearch.stopped")


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------


def create_app() -> FastAPI:
    """
    Assemble and return the FastAPI application.

    Separating construction into this factory function:
      - Makes the app importable without side effects (tests can import safely)
      - Enables easy testing via TestClient(create_app())
      - Documents the exact assembly order in one place
    """
    settings = get_settings()

    app = FastAPI(
        title       = "MedSearch",
        description = "Standalone medicine search microservice — multi-tenant, ML-powered.",
        version     = "1.0.0",
        lifespan    = lifespan,
        docs_url    = "/docs"  if not settings.is_production else None,
        redoc_url   = "/redoc" if not settings.is_production else None,
        openapi_url = "/openapi.json" if not settings.is_production else None,
    )

    # Middleware (order: registered last = outermost = first to see requests)
    register_middleware(app)

    # Error handlers
    register_error_handlers(app)

    # API routes — all v1 endpoints under /v1
    app.include_router(v1_router, prefix="/v1")

    # Health check at root level (no prefix, no auth — for load balancers)
    @app.get("/health", tags=["health"], include_in_schema=False)
    async def root_health() -> dict:
        return {"status": "ok"}

    # Prometheus metrics at /metrics
    Instrumentator(
        should_group_status_codes   = True,
        should_ignore_untemplated   = True,
        should_respect_env_var      = False,
        excluded_handlers           = ["/metrics", "/health"],
    ).instrument(app).expose(app, endpoint="/metrics", include_in_schema=False)

    return app


# ---------------------------------------------------------------------------
# Module-level app instance — used by uvicorn
# ---------------------------------------------------------------------------

app = create_app()
