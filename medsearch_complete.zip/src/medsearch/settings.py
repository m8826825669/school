"""
src/medsearch/settings.py

Application configuration loaded from environment variables / .env file.
All other modules import `get_settings()` — never os.environ directly.

Pattern: one Settings class, one lru_cache'd factory function.
FastAPI Depends(get_settings) injects it wherever needed.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import AnyUrl, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Validates and exposes every env var used by the application.
    Raises a clear ValidationError on startup if any required var is missing.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # silently drop unknown vars
    )

    # -------------------------------------------------------------------------
    # Application
    # -------------------------------------------------------------------------
    app_env: Literal["development", "staging", "production"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = Field(default=8001, ge=1, le=65535)
    app_workers: int = Field(default=4, ge=1)
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    # -------------------------------------------------------------------------
    # Security
    # -------------------------------------------------------------------------
    secret_key: str = Field(min_length=32)

    # -------------------------------------------------------------------------
    # PostgreSQL
    # -------------------------------------------------------------------------
    database_url: str  # postgresql+asyncpg://user:pass@host:port/db
    database_pool_size: int = Field(default=10, ge=1)
    database_max_overflow: int = Field(default=20, ge=0)

    # -------------------------------------------------------------------------
    # Redis
    # -------------------------------------------------------------------------
    redis_url: str = "redis://localhost:6379/0"
    redis_cache_ttl: int = Field(default=120, ge=1)
    redis_autocomplete_ttl: int = Field(default=86400, ge=60)

    # -------------------------------------------------------------------------
    # Typesense
    # -------------------------------------------------------------------------
    typesense_url: str = "http://localhost:8108"
    typesense_api_key: str
    typesense_connection_timeout: int = Field(default=2, ge=1)

    # -------------------------------------------------------------------------
    # Qdrant
    # -------------------------------------------------------------------------
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection_hnsw_m: int = Field(default=16, ge=4)
    qdrant_collection_ef_construct: int = Field(default=128, ge=16)

    # -------------------------------------------------------------------------
    # Embeddings
    # -------------------------------------------------------------------------
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_batch_size: int = Field(default=64, ge=1)
    embedding_dimensions: int = Field(default=384, ge=64)
    similarity_threshold: float = Field(default=0.35, ge=0.0, le=1.0)

    # -------------------------------------------------------------------------
    # ML Ranker
    # -------------------------------------------------------------------------
    ranker_model_path: str = "models/ranker.lgb"
    ranker_enabled: bool = True

    # -------------------------------------------------------------------------
    # Rate limiting
    # -------------------------------------------------------------------------
    rate_limit_per_minute: int = Field(default=300, ge=1)
    rate_limit_burst: int = Field(default=50, ge=1)

    # -------------------------------------------------------------------------
    # CORS — stored as comma-separated string; pydantic-settings v2 compatible
    # -------------------------------------------------------------------------
    cors_origins: str = "http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        """Parsed list of CORS origin URLs."""
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    # -------------------------------------------------------------------------
    # Derived properties (not env vars)
    # -------------------------------------------------------------------------
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_development(self) -> bool:
        return self.app_env == "development"

    @property
    def typesense_host(self) -> str:
        """Extract hostname from URL for Typesense client config."""
        return self.typesense_url.split("://")[1].split(":")[0]

    @property
    def typesense_port(self) -> str:
        """Extract port from URL for Typesense client config."""
        parts = self.typesense_url.split("://")[1].split(":")
        return parts[1] if len(parts) > 1 else "8108"

    @property
    def typesense_protocol(self) -> str:
        return self.typesense_url.split("://")[0]

    # -------------------------------------------------------------------------
    # Validators
    # -------------------------------------------------------------------------


@lru_cache
def get_settings() -> Settings:
    """
    Returns the singleton Settings instance.
    Cached after first call — safe for FastAPI Depends().

    Usage:
        from medsearch.settings import get_settings
        settings = get_settings()

        # In FastAPI endpoint:
        def my_endpoint(settings: Settings = Depends(get_settings)):
            ...
    """
    return Settings()
