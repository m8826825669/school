-- =============================================================================
-- MedSearch — PostgreSQL bootstrap script
-- Runs once when the container is first created.
-- =============================================================================

-- Enable pgvector for semantic search embeddings
CREATE EXTENSION IF NOT EXISTS vector;

-- Enable pg_trgm for fuzzy ILIKE queries (fallback search)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Enable uuid-ossp for UUID primary keys
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
