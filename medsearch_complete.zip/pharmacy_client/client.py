"""
pharmacy_client/client.py

Thin async HTTP client for calling the MedSearch service from any
Python application (Django, FastAPI, Flask, etc.).

Drop this file into your project — it has zero dependencies beyond httpx.

Usage in Django (views.py):
    from pharmacy_client import MedSearchClient

    client = MedSearchClient.from_env()   # reads MEDSEARCH_URL + MEDSEARCH_API_KEY

    async def search_view(request):
        results = await client.search(
            query     = request.GET["q"],
            tenant_id = f"pharmacy_branch_{request.user.branch_id}",
            filters   = {"stock_qty": {"gt": 0}},
        )
        return JsonResponse({"hits": results})

Usage in Django signals (post_save):
    @receiver(post_save, sender=Medicine)
    def sync_to_search(sender, instance, **kwargs):
        import asyncio
        asyncio.create_task(client.index(
            tenant_id = "pharmacy_1",
            doc_id    = str(instance.id),
            document  = {
                "name":            instance.name,
                "generic_name":    instance.generic_name,
                "salt_composition": instance.salt_composition,
                "price":           float(instance.price),
                "stock_qty":       instance.stock_qty,
                "sales_30d":       instance.sales_30d,
                "indications":     instance.indications or "",
            },
        ))
"""

from __future__ import annotations

import os
from typing import Any

import httpx


class MedSearchError(Exception):
    """Raised when MedSearch returns an error response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail      = detail
        super().__init__(f"MedSearch error {status_code}: {detail}")


class MedSearchClient:
    """
    Async client for the MedSearch API.

    Thread-safe. Create one instance per application and reuse it.
    Uses httpx.AsyncClient with connection pooling.
    """

    def __init__(
        self,
        base_url: str,
        api_key:  str,
        timeout:  float = 3.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._headers  = {
            "X-API-Key":    api_key,
            "Content-Type": "application/json",
        }
        self._timeout = timeout
        self._http    = httpx.AsyncClient(
            base_url = self._base_url,
            headers  = self._headers,
            timeout  = self._timeout,
        )

    @classmethod
    def from_env(cls) -> "MedSearchClient":
        """
        Construct from environment variables.
        MEDSEARCH_URL      — e.g. http://medsearch:8001
        MEDSEARCH_API_KEY  — your tenant API key
        MEDSEARCH_TIMEOUT  — request timeout in seconds (default 3.0)
        """
        url     = os.environ.get("MEDSEARCH_URL",     "http://localhost:8001")
        api_key = os.environ.get("MEDSEARCH_API_KEY", "")
        timeout = float(os.environ.get("MEDSEARCH_TIMEOUT", "3.0"))
        return cls(url, api_key, timeout)

    # -------------------------------------------------------------------------
    # Search
    # -------------------------------------------------------------------------

    async def search(
        self,
        query:     str,
        tenant_id: str,
        index:     str = "medicines",
        filters:   dict[str, Any] | None = None,
        boost:     dict[str, float] | None = None,
        user_id:   str | None = None,
        limit:     int = 15,
        language:  str = "hi-IN",
    ) -> list[dict[str, Any]]:
        """
        Search for medicines. Returns list of hit payloads.

        Falls back to empty list on timeout or connection error so billing
        can fall back to local DB search without crashing.

        Args:
            query:     Search string typed by pharmacist.
            tenant_id: Your tenant ID (e.g. "pharmacy_branch_3").
            index:     Index name (default "medicines").
            filters:   Stock/category filters (default: in-stock only).
            boost:     Per-field score multipliers for business rules.
            user_id:   Pharmacist ID for personalisation (optional).
            limit:     Max results (default 15).
            language:  "en" or "hi-IN" (default "hi-IN" for India).

        Returns:
            List of document payloads, ordered best-first.
            Empty list on error — never raises for network failures.
        """
        if filters is None:
            filters = {"stock_qty": {"gt": 0}}

        try:
            r = await self._http.post("/v1/search", json={
                "query":     query,
                "tenant_id": tenant_id,
                "index":     index,
                "filters":   filters,
                "boost":     boost or {},
                "user_id":   user_id,
                "limit":     limit,
                "language":  language,
            })
            self._raise_for_status(r)
            data = r.json()
            return [hit["payload"] for hit in data.get("hits", [])]
        except (httpx.TimeoutException, httpx.ConnectError):
            return []   # caller falls back to local DB
        except MedSearchError:
            raise
        except Exception:
            return []

    # -------------------------------------------------------------------------
    # Suggest (autocomplete)
    # -------------------------------------------------------------------------

    async def suggest(
        self,
        prefix:    str,
        tenant_id: str,
        index:     str = "medicines",
        limit:     int = 8,
    ) -> list[str]:
        """Return autocomplete suggestions for the given prefix."""
        try:
            r = await self._http.get("/v1/suggest", params={
                "q":         prefix,
                "tenant_id": tenant_id,
                "index":     index,
                "limit":     limit,
            })
            self._raise_for_status(r)
            return r.json().get("suggestions", [])
        except (httpx.TimeoutException, httpx.ConnectError):
            return []
        except Exception:
            return []

    # -------------------------------------------------------------------------
    # Index (write)
    # -------------------------------------------------------------------------

    async def index(
        self,
        tenant_id: str,
        doc_id:    str,
        document:  dict[str, Any],
        index:     str = "medicines",
    ) -> bool:
        """
        Upsert a document into the search index.
        Returns True on success, False on failure.
        Called from Django post_save signals.
        """
        try:
            r = await self._http.post("/v1/index", json={
                "tenant_id": tenant_id,
                "index":     index,
                "doc_id":    doc_id,
                "document":  document,
            })
            self._raise_for_status(r)
            return True
        except Exception:
            return False

    async def delete(
        self,
        tenant_id: str,
        doc_id:    str,
        index:     str = "medicines",
    ) -> bool:
        """Remove a document from the search index."""
        try:
            r = await self._http.delete(
                f"/v1/index/{doc_id}",
                params={"tenant_id": tenant_id, "index": index},
            )
            self._raise_for_status(r)
            return True
        except Exception:
            return False

    # -------------------------------------------------------------------------
    # Analytics
    # -------------------------------------------------------------------------

    async def record_selection(
        self,
        tenant_id:     str,
        query:         str,
        selected_id:   str,
        added_to_bill: bool = False,
    ) -> None:
        """
        Record which search result the pharmacist picked.
        Call this when a medicine is selected from the search results.
        This is the primary ML training signal — call it on every selection.
        """
        try:
            await self._http.post("/v1/analytics/select", json={
                "tenant_id":     tenant_id,
                "query":         query,
                "selected_id":   selected_id,
                "added_to_bill": added_to_bill,
            })
        except Exception:
            pass   # analytics failures are silently ignored

    # -------------------------------------------------------------------------
    # Health
    # -------------------------------------------------------------------------

    async def is_healthy(self) -> bool:
        """Return True if MedSearch service is reachable and healthy."""
        try:
            r = await self._http.get("/health", timeout=1.0)
            return r.status_code == 200
        except Exception:
            return False

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "MedSearchClient":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # -------------------------------------------------------------------------
    # Private
    # -------------------------------------------------------------------------

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.status_code >= 400:
            try:
                detail = response.json().get("error", response.text)
            except Exception:
                detail = response.text
            raise MedSearchError(response.status_code, detail)
