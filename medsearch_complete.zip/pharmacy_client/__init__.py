"""
pharmacy_client — Thin MedSearch client for Python applications.

from pharmacy_client import MedSearchClient

client = MedSearchClient.from_env()
hits   = await client.search("paracetamol", tenant_id="pharmacy_1")
"""
from pharmacy_client.client import MedSearchClient, MedSearchError

__all__ = ["MedSearchClient", "MedSearchError"]
