"""
pharmacy_client/django_integration.py

Drop-in Django integration helpers.

1. MedSearchMixin     — add to any DRF APIView for search + suggest
2. sync_search()      — sync wrapper for Django sync views
3. register_signals() — call once in AppConfig.ready() to auto-sync

Example AppConfig:
    class PharmacyConfig(AppConfig):
        default_auto_field = "django.db.models.BigAutoField"
        name = "pharmacy"

        def ready(self):
            from pharmacy_client.django_integration import register_signals
            from pharmacy.models import Medicine
            register_signals(
                model     = Medicine,
                client    = MedSearchClient.from_env(),
                tenant_id = settings.MEDSEARCH_TENANT_ID,
                build_doc = lambda instance: {
                    "name":            instance.name,
                    "generic_name":    instance.generic_name,
                    "salt_composition": instance.salt_composition,
                    "price":           float(instance.price),
                    "stock_qty":       instance.stock_qty,
                    "sales_30d":       instance.sales_30d,
                    "indications":     instance.indications or "",
                },
            )
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable

from pharmacy_client.client import MedSearchClient


# ---------------------------------------------------------------------------
# DRF mixin
# ---------------------------------------------------------------------------


class MedSearchMixin:
    """
    Add to a DRF APIView to get search() and suggest() methods backed by
    MedSearch with a local DB fallback.

    class MedicineSearchView(MedSearchMixin, APIView):
        medsearch_client   = MedSearchClient.from_env()
        medsearch_tenant   = "pharmacy_branch_3"
        medsearch_fallback = Medicine.objects.filter(stock_qty__gt=0)

        async def get(self, request):
            hits = await self.medsearch_search(request.GET.get("q", ""))
            return Response(hits)
    """

    medsearch_client: MedSearchClient
    medsearch_tenant: str
    medsearch_fallback: Any = None  # QuerySet used when MedSearch is down

    async def medsearch_search(
        self,
        query:   str,
        filters: dict | None = None,
        limit:   int = 15,
        user_id: str | None = None,
    ) -> list[dict]:
        results = await self.medsearch_client.search(
            query     = query,
            tenant_id = self.medsearch_tenant,
            filters   = filters,
            limit     = limit,
            user_id   = user_id,
        )
        if results:
            return results

        # Fallback to local DB when MedSearch is unreachable
        if self.medsearch_fallback is not None:
            qs = self.medsearch_fallback.filter(name__icontains=query)[:limit]
            return list(qs.values())
        return []

    async def medsearch_suggest(self, prefix: str, limit: int = 8) -> list[str]:
        return await self.medsearch_client.suggest(
            prefix    = prefix,
            tenant_id = self.medsearch_tenant,
            limit     = limit,
        )


# ---------------------------------------------------------------------------
# Sync wrapper for Django sync views
# ---------------------------------------------------------------------------


def sync_search(
    client:    MedSearchClient,
    query:     str,
    tenant_id: str,
    **kwargs:  Any,
) -> list[dict]:
    """
    Sync wrapper for use in Django sync views or management commands.

    result = sync_search(client, query="parace", tenant_id="pharmacy_1")
    """
    return asyncio.get_event_loop().run_until_complete(
        client.search(query=query, tenant_id=tenant_id, **kwargs)
    )


# ---------------------------------------------------------------------------
# Django signal auto-sync
# ---------------------------------------------------------------------------


def register_signals(
    model:     Any,
    client:    MedSearchClient,
    tenant_id: str,
    build_doc: Callable[[Any], dict[str, Any]],
    index:     str = "medicines",
) -> None:
    """
    Register post_save and post_delete signals on a Django model to
    automatically keep MedSearch in sync.

    Call this in your AppConfig.ready() method.

    Args:
        model:     Django model class (e.g. Medicine)
        client:    MedSearchClient instance
        tenant_id: Your tenant ID string
        build_doc: Function that maps a model instance → document dict
        index:     Index name (default "medicines")
    """
    from django.db.models.signals import post_delete, post_save
    from django.dispatch import receiver

    @receiver(post_save, sender=model, weak=False)
    def _on_save(sender: Any, instance: Any, **kwargs: Any) -> None:
        doc = build_doc(instance)
        asyncio.create_task(
            client.index(
                tenant_id = tenant_id,
                doc_id    = str(instance.pk),
                document  = doc,
                index     = index,
            )
        )

    @receiver(post_delete, sender=model, weak=False)
    def _on_delete(sender: Any, instance: Any, **kwargs: Any) -> None:
        asyncio.create_task(
            client.delete(
                tenant_id = tenant_id,
                doc_id    = str(instance.pk),
                index     = index,
            )
        )
