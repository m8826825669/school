@echo off
REM ============================================================
REM  School Management ERP — Run Script (Windows)
REM ============================================================

echo ============================================
echo   SCHOOL MANAGEMENT ERP
echo   Powered by Spring Boot + JavaFX
echo ============================================

REM Check Maven
where mvn >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Maven not found in PATH!
    echo Please install Maven from https://maven.apache.org
    pause
    exit /b 1
)

set JAR_FILE=target\school-management-erp-1.0.0.jar

IF NOT EXIST "%JAR_FILE%" (
    echo Building project...
    call mvn clean package -DskipTests -q
    if %errorlevel% neq 0 (
        echo Build FAILED! See errors above.
        pause
        exit /b 1
    )
    echo Build SUCCESS!
)

echo Starting School ERP...
echo.

call mvn javafx:run

pause
