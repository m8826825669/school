#!/bin/bash
# ============================================================
# School Management ERP — Run Script (Linux/Mac)
# ============================================================

echo "============================================"
echo "  SCHOOL MANAGEMENT ERP"
echo "  Powered by Spring Boot + JavaFX"
echo "============================================"

# Check Java 21+
java_version=$(java -version 2>&1 | grep -oP '(?<=version ")[0-9]+')
if [ -z "$java_version" ] || [ "$java_version" -lt 21 ]; then
    echo "ERROR: Java 21 or higher is required!"
    echo "Current version: $(java -version 2>&1 | head -1)"
    exit 1
fi

echo "Java OK: $(java -version 2>&1 | head -1)"
echo ""

# Build if JAR doesn't exist
JAR_FILE="target/school-management-erp-1.0.0.jar"
if [ ! -f "$JAR_FILE" ]; then
    echo "Building project..."
    mvn clean package -DskipTests -q
    if [ $? -ne 0 ]; then
        echo "Build FAILED! Check errors above."
        exit 1
    fi
    echo "Build SUCCESS!"
fi

echo "Starting School ERP..."
echo ""

# Run with required JavaFX/module args
java \
  --module-path "$(mvn dependency:build-classpath -q -Dinclude.scope=compile -Dmdep.outputFile=/dev/stdout 2>/dev/null | tr ':' '\n' | grep javafx | tr '\n' ':')" \
  --add-modules javafx.controls,javafx.fxml,javafx.swing \
  --add-opens javafx.graphics/com.sun.javafx.application=ALL-UNNAMED \
  --add-opens java.base/java.lang=ALL-UNNAMED \
  -jar "$JAR_FILE"
