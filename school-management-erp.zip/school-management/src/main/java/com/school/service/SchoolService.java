package com.school.service;

import com.school.model.*;
import com.school.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class SchoolService {

    private final StudentRepo studentRepo;
    private final TeacherRepo teacherRepo;
    private final ClassRoomRepo classRoomRepo;
    private final SectionRepo sectionRepo;
    private final SubjectRepo subjectRepo;
    private final AttendanceRepo attendanceRepo;
    private final ExamRepo examRepo;
    private final ExamResultRepo examResultRepo;
    private final FeeStructureRepo feeStructureRepo;
    private final FeePaymentRepo feePaymentRepo;
    private final BookRepo bookRepo;
    private final BookIssueRepo bookIssueRepo;
    private final NoticeRepo noticeRepo;
    private final TimetableRepo timetableRepo;
    private final StaffRepo staffRepo;

    @Value("${school.academic.year:2024-25}")
    private String currentAcademicYear;

    // ==================== STUDENT OPERATIONS ====================

    public Student saveStudent(Student student) {
        if (student.getId() == null) {
            student.setAdmissionNo(generateAdmissionNo());
            student.setCreatedAt(LocalDate.now());
        }
        return studentRepo.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepo.findByStatus(Student.StudentStatus.ACTIVE);
    }

    public List<Student> searchStudents(String query) {
        if (query == null || query.isBlank()) return getAllStudents();
        return studentRepo.searchStudents(query.trim());
    }

    public List<Student> getStudentsByClass(ClassRoom c) {
        return studentRepo.findByClassRoomOrderByRollNumber(c);
    }

    public List<Student> getStudentsByClassAndSection(ClassRoom c, Section s) {
        return studentRepo.findByClassRoomAndSectionOrderByRollNumber(c, s);
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepo.findById(id);
    }

    public void deleteStudent(Long id) {
        studentRepo.deleteById(id);
    }

    private String generateAdmissionNo() {
        String year = String.valueOf(LocalDate.now().getYear()).substring(2);
        long count = studentRepo.count() + 1;
        return "ADM" + year + String.format("%04d", count);
    }

    // ==================== TEACHER OPERATIONS ====================

    public Teacher saveTeacher(Teacher teacher) {
        if (teacher.getId() == null) {
            teacher.setEmployeeId(generateEmployeeId());
            teacher.setCreatedAt(LocalDate.now());
        }
        return teacherRepo.save(teacher);
    }

    public List<Teacher> getAllTeachers() {
        return teacherRepo.findByStatus(Teacher.TeacherStatus.ACTIVE);
    }

    public List<Teacher> searchTeachers(String query) {
        if (query == null || query.isBlank()) return getAllTeachers();
        return teacherRepo.searchTeachers(query.trim());
    }

    public Optional<Teacher> getTeacherById(Long id) {
        return teacherRepo.findById(id);
    }

    public void deleteTeacher(Long id) {
        teacherRepo.deleteById(id);
    }

    private String generateEmployeeId() {
        long count = teacherRepo.count() + 1;
        return "EMP" + String.format("%04d", count);
    }

    // ==================== CLASS & SECTION OPERATIONS ====================

    public ClassRoom saveClass(ClassRoom c) { return classRoomRepo.save(c); }
    public List<ClassRoom> getAllClasses() { return classRoomRepo.findAllByOrderByName(); }
    public void deleteClass(Long id) { classRoomRepo.deleteById(id); }

    public Section saveSection(Section s) { return sectionRepo.save(s); }
    public List<Section> getSectionsByClass(ClassRoom c) {
        return sectionRepo.findByClassRoomOrderByName(c);
    }
    public List<Section> getAllSections() { return sectionRepo.findAll(); }
    public void deleteSection(Long id) { sectionRepo.deleteById(id); }

    // ==================== SUBJECT OPERATIONS ====================

    public Subject saveSubject(Subject s) { return subjectRepo.save(s); }
    public List<Subject> getAllSubjects() { return subjectRepo.findAll(); }
    public List<Subject> getSubjectsByClass(ClassRoom c) { return subjectRepo.findByClassRoom(c); }
    public void deleteSubject(Long id) { subjectRepo.deleteById(id); }

    // ==================== ATTENDANCE OPERATIONS ====================

    public void markAttendance(Student student, LocalDate date, Attendance.AttendanceStatus status, String remarks) {
        if (attendanceRepo.existsByStudentAndDate(student, date)) {
            // Update existing
            List<Attendance> existing = attendanceRepo.findByStudentAndDateBetweenOrderByDate(student, date, date);
            if (!existing.isEmpty()) {
                Attendance att = existing.get(0);
                att.setStatus(status);
                att.setRemarks(remarks);
                attendanceRepo.save(att);
                return;
            }
        }
        Attendance attendance = Attendance.builder()
            .student(student).date(date).status(status).remarks(remarks).build();
        attendanceRepo.save(attendance);
    }

    public void markBulkAttendance(List<Student> students, LocalDate date,
                                    Map<Long, Attendance.AttendanceStatus> statusMap) {
        for (Student student : students) {
            Attendance.AttendanceStatus status = statusMap.getOrDefault(student.getId(),
                Attendance.AttendanceStatus.PRESENT);
            markAttendance(student, date, status, null);
        }
    }

    public List<Attendance> getAttendanceByClassAndDate(ClassRoom c, LocalDate date) {
        return attendanceRepo.findByDateAndStudent_ClassRoom(date, c);
    }

    public List<Attendance> getStudentAttendance(Student s, LocalDate from, LocalDate to) {
        return attendanceRepo.findByStudentAndDateBetweenOrderByDate(s, from, to);
    }

    public double getAttendancePercentage(Student s, LocalDate from, LocalDate to) {
        long present = attendanceRepo.countPresent(s, from, to);
        long total = attendanceRepo.countTotal(s, from, to);
        if (total == 0) return 0.0;
        return (present * 100.0) / total;
    }

    // ==================== EXAM & RESULT OPERATIONS ====================

    public Exam saveExam(Exam exam) { return examRepo.save(exam); }
    public List<Exam> getAllExams() { return examRepo.findAll(); }
    public List<Exam> getExamsByClass(ClassRoom c) { return examRepo.findByClassRoom(c); }
    public void deleteExam(Long id) { examRepo.deleteById(id); }

    public ExamResult saveResult(ExamResult result) {
        // Auto-calculate grade
        if (result.getMarksObtained() != null && result.getMaxMarks() != null) {
            double pct = result.getPercentage();
            result.setGrade(ExamResult.calculateGrade(pct));
            result.setIsPassed(pct >= 33.0);
        }
        return examResultRepo.save(result);
    }

    public List<ExamResult> getResultsByStudentAndExam(Student s, Exam e) {
        return examResultRepo.findByStudentAndExam(s, e);
    }

    public List<ExamResult> getStudentResults(Student s) {
        return examResultRepo.findByStudent(s);
    }

    public Map<String, Double> getExamStatsBySubject(Exam exam, Subject subject) {
        Map<String, Double> stats = new HashMap<>();
        List<ExamResult> results = examResultRepo.findByExamAndSubject(exam, subject);
        if (results.isEmpty()) return stats;
        double avg = results.stream().mapToDouble(ExamResult::getPercentage).average().orElse(0);
        double max = results.stream().mapToDouble(ExamResult::getPercentage).max().orElse(0);
        double min = results.stream().mapToDouble(ExamResult::getPercentage).min().orElse(0);
        long passed = results.stream().filter(r -> Boolean.TRUE.equals(r.getIsPassed())).count();
        stats.put("average", avg);
        stats.put("highest", max);
        stats.put("lowest", min);
        stats.put("passRate", (passed * 100.0) / results.size());
        return stats;
    }

    // ==================== FEE OPERATIONS ====================

    public FeeStructure saveFeeStructure(FeeStructure fs) { return feeStructureRepo.save(fs); }
    public List<FeeStructure> getAllFeeStructures() { return feeStructureRepo.findAll(); }
    public void deleteFeeStructure(Long id) { feeStructureRepo.deleteById(id); }

    public FeePayment saveFeePayment(FeePayment payment) {
        if (payment.getId() == null) {
            payment.setReceiptNo(generateReceiptNo());
            payment.setCreatedAt(LocalDate.now());
        }
        // Calculate balance
        if (payment.getTotalAmount() != null && payment.getAmountPaid() != null) {
            double disc = payment.getDiscount() != null ? payment.getDiscount() : 0;
            double fine = payment.getFine() != null ? payment.getFine() : 0;
            double net = payment.getTotalAmount() - disc + fine;
            payment.setBalance(net - payment.getAmountPaid());
            if (payment.getBalance() <= 0) payment.setStatus(FeePayment.PaymentStatus.PAID);
            else if (payment.getAmountPaid() > 0) payment.setStatus(FeePayment.PaymentStatus.PARTIAL);
        }
        return feePaymentRepo.save(payment);
    }

    public List<FeePayment> getPaymentsByStudent(Student s) {
        return feePaymentRepo.findByStudent(s);
    }

    public List<FeePayment> getAllPayments() {
        return feePaymentRepo.findAll();
    }

    public double getTodayCollection() {
        LocalDate today = LocalDate.now();
        Double total = feePaymentRepo.totalCollectedBetween(today, today);
        return total != null ? total : 0.0;
    }

    public double getMonthlyCollection() {
        LocalDate start = LocalDate.now().withDayOfMonth(1);
        LocalDate end = LocalDate.now();
        Double total = feePaymentRepo.totalCollectedBetween(start, end);
        return total != null ? total : 0.0;
    }

    private String generateReceiptNo() {
        String yr = String.valueOf(LocalDate.now().getYear());
        long count = feePaymentRepo.count() + 1;
        return "RCP" + yr + String.format("%05d", count);
    }

    // ==================== LIBRARY OPERATIONS ====================

    public Book saveBook(Book book) { return bookRepo.save(book); }
    public List<Book> getAllBooks() { return bookRepo.findAll(); }
    public List<Book> searchBooks(String query) {
        if (query == null || query.isBlank()) return getAllBooks();
        return bookRepo.searchBooks(query.trim());
    }
    public void deleteBook(Long id) { bookRepo.deleteById(id); }

    public BookIssue issueBook(Book book, Student student, LocalDate dueDate) {
        if (book.getAvailableCopies() <= 0) throw new RuntimeException("No copies available!");
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepo.save(book);
        return bookIssueRepo.save(BookIssue.builder()
            .book(book).student(student).borrowerType("STUDENT")
            .issueDate(LocalDate.now()).dueDate(dueDate).status(BookIssue.IssueStatus.ISSUED)
            .build());
    }

    public BookIssue returnBook(BookIssue issue) {
        issue.setReturnDate(LocalDate.now());
        issue.setStatus(BookIssue.IssueStatus.RETURNED);
        // Calculate fine (₹2/day)
        if (issue.isOverdue()) {
            issue.setFine(issue.getOverdueDays() * 2.0);
        }
        Book book = issue.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepo.save(book);
        return bookIssueRepo.save(issue);
    }

    public List<BookIssue> getOverdueBooks() {
        return bookIssueRepo.findByStatusAndDueDateBefore(BookIssue.IssueStatus.ISSUED, LocalDate.now());
    }

    public List<BookIssue> getAllIssues() { return bookIssueRepo.findAll(); }

    // ==================== NOTICE OPERATIONS ====================

    public Notice saveNotice(Notice n) {
        if (n.getIsActive() == null) n.setIsActive(true);
        return noticeRepo.save(n);
    }
    public List<Notice> getActiveNotices() { return noticeRepo.findByIsActiveTrueOrderByPublishDateDesc(); }
    public List<Notice> getAllNotices() { return noticeRepo.findAllByOrderByPublishDateDesc(); }
    public void deleteNotice(Long id) { noticeRepo.deleteById(id); }

    // ==================== TIMETABLE OPERATIONS ====================

    public Timetable saveTimetable(Timetable t) { return timetableRepo.save(t); }
    public void deleteTimetable(Long id) { timetableRepo.deleteById(id); }
    public List<Timetable> getTimetableByClass(ClassRoom c) {
        return timetableRepo.findByClassRoomOrderByDayOfWeekAscStartTimeAsc(c);
    }
    public List<Timetable> getTimetableByClassSectionDay(ClassRoom c, Section s, String day) {
        return timetableRepo.findByClassRoomAndSectionAndDayOfWeekOrderByStartTime(c, s, day);
    }

    // ==================== STAFF OPERATIONS ====================

    public Staff saveStaff(Staff s) {
        if (s.getId() == null && (s.getStaffId() == null || s.getStaffId().isBlank())) {
            s.setStaffId("STF" + String.format("%04d", staffRepo.count() + 1));
        }
        return staffRepo.save(s);
    }
    public List<Staff> getAllStaff() { return staffRepo.findByStatus(Staff.StaffStatus.ACTIVE); }
    public void deleteStaff(Long id) { staffRepo.deleteById(id); }

    // ==================== DASHBOARD STATS ====================

    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents", studentRepo.countByStatus(Student.StudentStatus.ACTIVE));
        stats.put("totalTeachers", teacherRepo.countByStatus(Teacher.TeacherStatus.ACTIVE));
        stats.put("totalStaff", staffRepo.countByStatus(Staff.StaffStatus.ACTIVE));
        stats.put("totalClasses", classRoomRepo.count());
        stats.put("totalBooks", bookRepo.count());
        stats.put("booksIssued", bookIssueRepo.countByStatus(BookIssue.IssueStatus.ISSUED));
        stats.put("overdueBooks", bookIssueRepo.findByStatusAndDueDateBefore(
            BookIssue.IssueStatus.ISSUED, LocalDate.now()).size());
        stats.put("todayCollection", getTodayCollection());
        stats.put("monthlyCollection", getMonthlyCollection());
        stats.put("pendingFees", feePaymentRepo.countByStatus(FeePayment.PaymentStatus.PENDING));
        stats.put("activeNotices", noticeRepo.findByIsActiveTrueOrderByPublishDateDesc().size());
        // Today's total attendance records across all classes
        long presentToday = attendanceRepo.countTodayPresent(LocalDate.now());
        stats.put("presentToday", presentToday);
        return stats;
    }
}
