package com.school;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.util.Objects;

@SpringBootApplication
public class SchoolApp extends Application {

    private ConfigurableApplicationContext springContext;
    private Stage splashStage;

    @Override
    public void init() throws Exception {
        Platform.runLater(this::showSplash);
        Thread.sleep(200); // Let splash render
        springContext = SpringApplication.run(SchoolApp.class);
    }

    private void showSplash() {
        splashStage = new Stage(StageStyle.UNDECORATED);
        VBox splash = new VBox(20);
        splash.setAlignment(Pos.CENTER);
        splash.setPrefSize(500, 340);
        splash.setStyle("""
            -fx-background-color: linear-gradient(to bottom right, #0D47A1, #1565C0, #1976D2);
            -fx-background-radius: 12;
        """);

        Label title = new Label("🏫  SchoolERP");
        title.setStyle("-fx-font-size: 42px; -fx-font-weight: bold; -fx-text-fill: white; -fx-font-family: 'Segoe UI';");

        Label subtitle = new Label("Comprehensive School Management System");
        subtitle.setStyle("-fx-font-size: 15px; -fx-text-fill: #BBDEFB; -fx-font-family: 'Segoe UI';");

        ProgressBar pb = new ProgressBar();
        pb.setPrefWidth(280);
        pb.setStyle("-fx-accent: #FFD600;");

        Label loading = new Label("Initializing application...");
        loading.setStyle("-fx-font-size: 12px; -fx-text-fill: #90CAF9;");

        Label version = new Label("Version 1.0.0  |  Powered by Spring Boot + JavaFX");
        version.setStyle("-fx-font-size: 10px; -fx-text-fill: #5C8BC8;");

        splash.getChildren().addAll(title, subtitle, pb, loading, version);
        Scene splashScene = new Scene(splash, Color.TRANSPARENT);
        splashScene.setFill(Color.TRANSPARENT);
        splashStage.setScene(splashScene);
        splashStage.initStyle(StageStyle.TRANSPARENT);
        splashStage.setAlwaysOnTop(true);
        splashStage.centerOnScreen();
        splashStage.show();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/main.fxml"));
        loader.setControllerFactory(springContext::getBean);

        Scene scene = new Scene(loader.load(), 1366, 768);
        scene.getStylesheets().add(
            Objects.requireNonNull(getClass().getResource("/css/style.css")).toExternalForm()
        );

        primaryStage.setTitle("SchoolERP — School Management System");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1100);
        primaryStage.setMinHeight(700);
        primaryStage.setMaximized(true);

        if (splashStage != null) splashStage.close();
        primaryStage.show();
    }

    @Override
    public void stop() {
        if (springContext != null) springContext.close();
        Platform.exit();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
