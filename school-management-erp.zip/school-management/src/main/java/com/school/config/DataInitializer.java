package com.school.config;

import com.school.model.*;
import com.school.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final ClassRoomRepo classRoomRepo;
    private final SectionRepo sectionRepo;
    private final TeacherRepo teacherRepo;
    private final StudentRepo studentRepo;
    private final SubjectRepo subjectRepo;
    private final FeeStructureRepo feeStructureRepo;
    private final BookRepo bookRepo;
    private final NoticeRepo noticeRepo;
    private final StaffRepo staffRepo;

    @Override
    public void run(String... args) {
        if (classRoomRepo.count() > 0) {
            log.info("Database already initialized — skipping seed data.");
            return;
        }
        log.info("First run detected — seeding sample data...");
        seedClasses();
        seedTeachers();
        seedSubjects();
        seedStudents();
        seedFeeStructures();
        seedBooks();
        seedNotices();
        seedStaff();
        log.info("Sample data loaded successfully!");
    }

    private void seedClasses() {
        String[] classNames = {"Nursery","KG","1","2","3","4","5","6","7","8","9","10","11","12"};
        for (String name : classNames) {
            ClassRoom c = ClassRoom.builder().name(name).capacity(40)
                .description("Class " + name).build();
            classRoomRepo.save(c);
        }
        // Add sections A,B for each class
        List<ClassRoom> classes = classRoomRepo.findAll();
        for (ClassRoom c : classes) {
            sectionRepo.save(Section.builder().name("A").classRoom(c).capacity(40).build());
            sectionRepo.save(Section.builder().name("B").classRoom(c).capacity(40).build());
        }
        log.info("Classes and sections seeded.");
    }

    private void seedTeachers() {
        List<ClassRoom> classes = classRoomRepo.findAll();
        String[][] teachers = {
            {"Priya","Sharma","HOD","Mathematics","EMP0001","9876543210","priya@school.edu"},
            {"Rajesh","Kumar","Teacher","Science","EMP0002","9876543211","rajesh@school.edu"},
            {"Sunita","Gupta","Teacher","English","EMP0003","9876543212","sunita@school.edu"},
            {"Amit","Verma","Teacher","Hindi","EMP0004","9876543213","amit@school.edu"},
            {"Deepa","Singh","Teacher","Social Studies","EMP0005","9876543214","deepa@school.edu"},
            {"Vikram","Patel","Teacher","Physics","EMP0006","9876543215","vikram@school.edu"},
            {"Meera","Joshi","Teacher","Chemistry","EMP0007","9876543216","meera@school.edu"},
            {"Suresh","Yadav","Teacher","Biology","EMP0008","9876543217","suresh@school.edu"},
            {"Anita","Chauhan","Teacher","Computer Science","EMP0009","9876543218","anita@school.edu"},
            {"Principal","Admin","Principal","Administration","EMP0010","9876543219","principal@school.edu"}
        };
        for (String[] t : teachers) {
            teacherRepo.save(Teacher.builder()
                .firstName(t[0]).lastName(t[1]).designation(t[2]).department(t[3])
                .employeeId(t[4]).phone(t[5]).email(t[6])
                .joiningDate(LocalDate.of(2020, 6, 1))
                .salary(45000.0).qualification("M.Ed").experienceYears(5)
                .gender("Female").status(Teacher.TeacherStatus.ACTIVE)
                .dateOfBirth(LocalDate.of(1985, 3, 15))
                .address("Staff Colony, Springfield").build());
        }
        log.info("Teachers seeded.");
    }

    private void seedSubjects() {
        List<ClassRoom> classes = classRoomRepo.findAll();
        List<Teacher> teachers = teacherRepo.findAll();
        String[][] subjects = {
            {"Mathematics","MATH","THEORY","100","33"},
            {"Science","SCI","BOTH","100","33"},
            {"English","ENG","THEORY","100","33"},
            {"Hindi","HIN","THEORY","100","33"},
            {"Social Studies","SST","THEORY","100","33"},
            {"Computer Science","CS","BOTH","100","33"},
            {"Physical Education","PE","PRACTICAL","50","17"},
            {"Art & Craft","ART","PRACTICAL","50","17"}
        };
        ClassRoom c6 = classRoomRepo.findByName("6").orElse(classes.get(0));
        for (int i = 0; i < subjects.length; i++) {
            String[] s = subjects[i];
            subjectRepo.save(Subject.builder()
                .name(s[0]).code(s[1]).type(s[2])
                .fullMarks(Integer.parseInt(s[3])).passMarks(Integer.parseInt(s[4]))
                .classRoom(c6)
                .teacher(teachers.size() > i ? teachers.get(i) : teachers.get(0))
                .periodsPerWeek(5).isMandatory(true).build());
        }
        log.info("Subjects seeded.");
    }

    private void seedStudents() {
        ClassRoom c6 = classRoomRepo.findByName("6").orElse(null);
        ClassRoom c7 = classRoomRepo.findByName("7").orElse(null);
        ClassRoom c8 = classRoomRepo.findByName("8").orElse(null);
        ClassRoom c9 = classRoomRepo.findByName("9").orElse(null);
        ClassRoom c10 = classRoomRepo.findByName("10").orElse(null);
        if (c6 == null) return;

        Section secA6 = sectionRepo.findByClassRoomOrderByName(c6).stream()
            .filter(s -> "A".equals(s.getName())).findFirst().orElse(null);

        String[][] students = {
            {"Aarav","Sharma","ADM240001","2012-03-15","M","1"},
            {"Priya","Singh","ADM240002","2012-07-22","F","2"},
            {"Rohan","Kumar","ADM240003","2012-01-10","M","3"},
            {"Ananya","Gupta","ADM240004","2012-11-05","F","4"},
            {"Vivaan","Patel","ADM240005","2012-04-18","M","5"},
            {"Ishaan","Verma","ADM240006","2012-09-30","M","6"},
            {"Kavya","Sharma","ADM240007","2012-06-25","F","7"},
            {"Arjun","Mishra","ADM240008","2012-02-14","M","8"},
            {"Diya","Joshi","ADM240009","2012-08-09","F","9"},
            {"Rehan","Khan","ADM240010","2012-12-20","M","10"},
            {"Tanvi","Chauhan","ADM240011","2012-05-03","F","11"},
            {"Yash","Agarwal","ADM240012","2012-10-17","M","12"},
            {"Meera","Nair","ADM240013","2012-03-28","F","13"},
            {"Advait","Rao","ADM240014","2012-07-11","M","14"},
            {"Siya","Chandra","ADM240015","2012-01-22","F","15"}
        };

        for (String[] s : students) {
            studentRepo.save(Student.builder()
                .firstName(s[0]).lastName(s[1]).admissionNo(s[2])
                .dateOfBirth(LocalDate.parse(s[3]))
                .gender("M".equals(s[4]) ? "MALE" : "FEMALE")
                .rollNumber(Integer.parseInt(s[5]))
                .classRoom(c6).section(secA6)
                .fatherName(s[1] + " Sr.").guardianPhone("98765" + String.format("%05d", Integer.parseInt(s[5])))
                .admissionDate(LocalDate.of(2024, 4, 1))
                .bloodGroup("O+").category("GEN").status(Student.StudentStatus.ACTIVE)
                .address("123 Main Street, Springfield")
                .transportRequired(false).hostelRequired(false).build());
        }

        // Add a few more students in other classes
        if (c9 != null) {
            Section secA9 = sectionRepo.findByClassRoomOrderByName(c9).stream()
                .filter(sec -> "A".equals(sec.getName())).findFirst().orElse(null);
            studentRepo.save(Student.builder()
                .firstName("Shivam").lastName("Tiwari").admissionNo("ADM240016")
                .dateOfBirth(LocalDate.of(2009, 5, 14)).gender("MALE").rollNumber(1)
                .classRoom(c9).section(secA9)
                .admissionDate(LocalDate.of(2020, 4, 1))
                .fatherName("Rakesh Tiwari").guardianPhone("9812345678")
                .status(Student.StudentStatus.ACTIVE).category("OBC")
                .address("45 Colony Road, Springfield").build());
        }
        log.info("Students seeded.");
    }

    private void seedFeeStructures() {
        List<ClassRoom> classes = classRoomRepo.findAll();
        // Universal fees
        feeStructureRepo.save(FeeStructure.builder().name("Tuition Fee").amount(2500.0)
            .frequency("MONTHLY").academicYear("2024-25").classRoom(null).build());
        feeStructureRepo.save(FeeStructure.builder().name("Admission Fee").amount(5000.0)
            .frequency("ONE_TIME").academicYear("2024-25").classRoom(null).build());
        feeStructureRepo.save(FeeStructure.builder().name("Sports Fee").amount(1000.0)
            .frequency("ANNUALLY").academicYear("2024-25").classRoom(null).build());
        feeStructureRepo.save(FeeStructure.builder().name("Library Fee").amount(500.0)
            .frequency("ANNUALLY").academicYear("2024-25").classRoom(null).build());
        feeStructureRepo.save(FeeStructure.builder().name("Lab Fee").amount(1500.0)
            .frequency("ANNUALLY").academicYear("2024-25").classRoom(null).build());
        feeStructureRepo.save(FeeStructure.builder().name("Exam Fee").amount(800.0)
            .frequency("QUARTERLY").academicYear("2024-25").classRoom(null).build());
        log.info("Fee structures seeded.");
    }

    private void seedBooks() {
        String[][] books = {
            {"Mathematics NCERT Class 6","NCERT","NCERT","978-81-7450-634-5","Academics","10","10","250"},
            {"Science NCERT Class 6","NCERT","NCERT","978-81-7450-635-2","Academics","10","10","280"},
            {"Wings of Fire","A.P.J. Abdul Kalam","Universities Press","978-81-7371-146-4","Biography","5","5","199"},
            {"Discovery of India","Jawaharlal Nehru","Penguin","978-0-14-303353-9","History","3","3","499"},
            {"Harry Potter","J.K. Rowling","Bloomsbury","978-0-7475-3269-9","Fiction","8","8","399"},
            {"The Alchemist","Paulo Coelho","HarperCollins","978-0-06-112241-5","Fiction","6","6","299"},
            {"Introduction to Algorithms","CLRS","MIT Press","978-0-262-03384-8","Computer Science","4","4","2999"},
            {"Chemistry NCERT Class 11","NCERT","NCERT","978-81-7450-711-3","Academics","8","8","310"},
            {"Physics Part 1 Class 12","NCERT","NCERT","978-81-7450-703-8","Academics","8","8","295"},
            {"English Grammar","Wren & Martin","S Chand","978-81-219-0189-0","Language","10","10","350"}
        };
        for (String[] b : books) {
            bookRepo.save(Book.builder()
                .title(b[0]).author(b[1]).publisher(b[2]).isbn(b[3]).category(b[4])
                .totalCopies(Integer.parseInt(b[5])).availableCopies(Integer.parseInt(b[6]))
                .price(Double.parseDouble(b[7])).language("English")
                .addedDate(LocalDate.now()).build());
        }
        log.info("Books seeded.");
    }

    private void seedNotices() {
        noticeRepo.save(Notice.builder()
            .title("Annual Day Celebration 2024")
            .content("We are pleased to announce that our Annual Day celebration will be held on December 25, 2024. All students are requested to participate in cultural events. Parents are cordially invited.")
            .category("ACADEMIC").audience(Notice.NoticeAudience.ALL)
            .publishDate(LocalDate.now()).isActive(true).createdBy("Principal").build());

        noticeRepo.save(Notice.builder()
            .title("Half Yearly Exam Schedule Released")
            .content("The Half Yearly Examination schedule has been released. Exams will be conducted from November 15 to November 30. Students should collect their admit cards from the office.")
            .category("EXAM").audience(Notice.NoticeAudience.STUDENTS)
            .publishDate(LocalDate.now().minusDays(3)).isActive(true).createdBy("Examination Cell").build());

        noticeRepo.save(Notice.builder()
            .title("Parent-Teacher Meeting — November 10")
            .content("A Parent-Teacher Meeting (PTM) is scheduled for November 10, 2024 from 9:00 AM to 1:00 PM. All parents are requested to attend and discuss their ward's academic progress.")
            .category("CIRCULAR").audience(Notice.NoticeAudience.PARENTS)
            .publishDate(LocalDate.now().minusDays(7)).isActive(true).createdBy("Principal").build());

        noticeRepo.save(Notice.builder()
            .title("Staff Meeting — October 30")
            .content("A mandatory staff meeting will be held on October 30 at 3:00 PM in the conference room. All teaching and non-teaching staff must attend.")
            .category("CIRCULAR").audience(Notice.NoticeAudience.TEACHERS)
            .publishDate(LocalDate.now().minusDays(10)).isActive(false).createdBy("Admin").build());
        log.info("Notices seeded.");
    }

    private void seedStaff() {
        String[][] staff = {
            {"Ramesh","Yadav","Peon","9812341234","STF0001"},
            {"Sita","Devi","Librarian","9812341235","STF0002"},
            {"Gopal","Sharma","Security Guard","9812341236","STF0003"},
            {"Munna","Lal","Bus Driver","9812341237","STF0004"},
            {"Kavita","Singh","Accountant","9812341238","STF0005"},
            {"Rajni","Devi","Cook","9812341239","STF0006"}
        };
        for (String[] s : staff) {
            staffRepo.save(Staff.builder()
                .firstName(s[0]).lastName(s[1]).role(s[2]).phone(s[3]).staffId(s[4])
                .joiningDate(LocalDate.of(2021, 4, 1)).salary(15000.0)
                .gender("Male").status(Staff.StaffStatus.ACTIVE)
                .dateOfBirth(LocalDate.of(1985, 6, 15)).build());
        }
        log.info("Staff seeded.");
    }
}
