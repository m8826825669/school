package com.school.repository;

import com.school.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepo extends JpaRepository<Student, Long> {
    List<Student> findByClassRoomAndSectionOrderByRollNumber(ClassRoom c, Section s);
    List<Student> findByClassRoomOrderByRollNumber(ClassRoom c);
    List<Student> findByStatus(Student.StudentStatus status);
    Optional<Student> findByAdmissionNo(String admissionNo);
    long countByStatus(Student.StudentStatus status);
    long countByClassRoom(ClassRoom c);
    @Query("SELECT s FROM Student s WHERE LOWER(s.firstName) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(s.lastName) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(s.admissionNo) LIKE LOWER(CONCAT('%',:q,'%'))")
    List<Student> searchStudents(@Param("q") String query);
}
