package com.school.repository;

import com.school.model.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NoticeRepo extends JpaRepository<Notice, Long> {
    List<Notice> findByIsActiveTrueOrderByPublishDateDesc();
    List<Notice> findAllByOrderByPublishDateDesc();
}
