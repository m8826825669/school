package com.school.repository;

import com.school.model.ClassRoom;
import com.school.model.Section;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SectionRepo extends JpaRepository<Section, Long> {
    List<Section> findByClassRoom(ClassRoom classRoom);
    List<Section> findByClassRoomOrderByName(ClassRoom classRoom);
}
