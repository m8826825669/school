package com.school.repository;

import com.school.model.FeePayment;
import com.school.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface FeePaymentRepo extends JpaRepository<FeePayment, Long> {
    List<FeePayment> findByStudent(Student s);
    List<FeePayment> findByStatus(FeePayment.PaymentStatus status);
    List<FeePayment> findByPaymentDateBetween(LocalDate from, LocalDate to);
    Optional<FeePayment> findByReceiptNo(String receiptNo);
    @Query("SELECT COALESCE(SUM(f.amountPaid),0) FROM FeePayment f WHERE f.status='PAID' AND f.paymentDate BETWEEN :from AND :to")
    Double totalCollectedBetween(@Param("from") LocalDate from, @Param("to") LocalDate to);
    long countByStatus(FeePayment.PaymentStatus status);
}
