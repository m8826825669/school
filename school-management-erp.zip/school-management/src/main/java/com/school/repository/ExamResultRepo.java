package com.school.repository;

import com.school.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExamResultRepo extends JpaRepository<ExamResult, Long> {
    List<ExamResult> findByStudentAndExam(Student s, Exam e);
    List<ExamResult> findByExamAndSubject(Exam e, Subject s);
    List<ExamResult> findByStudent(Student s);
    @Query("SELECT AVG(r.marksObtained/r.maxMarks*100) FROM ExamResult r WHERE r.exam=:e AND r.subject=:s")
    Double avgPercentage(@Param("e") Exam e, @Param("s") Subject s);
}
