package com.school.repository;

import com.school.model.ClassRoom;
import com.school.model.FeeStructure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FeeStructureRepo extends JpaRepository<FeeStructure, Long> {
    List<FeeStructure> findByClassRoom(ClassRoom c);
    List<FeeStructure> findByClassRoomIsNull();
}
