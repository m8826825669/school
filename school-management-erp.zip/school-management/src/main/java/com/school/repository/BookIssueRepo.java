package com.school.repository;

import com.school.model.BookIssue;
import com.school.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookIssueRepo extends JpaRepository<BookIssue, Long> {
    List<BookIssue> findByStudent(Student s);
    List<BookIssue> findByStatus(BookIssue.IssueStatus status);
    List<BookIssue> findByStatusAndDueDateBefore(BookIssue.IssueStatus status, LocalDate date);
    long countByStatus(BookIssue.IssueStatus status);
}
