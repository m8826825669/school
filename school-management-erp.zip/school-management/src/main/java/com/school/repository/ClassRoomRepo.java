package com.school.repository;

import com.school.model.ClassRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClassRoomRepo extends JpaRepository<ClassRoom, Long> {
    Optional<ClassRoom> findByName(String name);
    List<ClassRoom> findAllByOrderByName();
}
