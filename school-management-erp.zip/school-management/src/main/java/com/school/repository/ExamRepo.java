package com.school.repository;

import com.school.model.ClassRoom;
import com.school.model.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExamRepo extends JpaRepository<Exam, Long> {
    List<Exam> findByClassRoom(ClassRoom c);
    List<Exam> findByStatus(Exam.ExamStatus status);
    List<Exam> findByAcademicYear(String year);
}
