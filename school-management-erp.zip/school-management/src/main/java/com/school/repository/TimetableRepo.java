package com.school.repository;

import com.school.model.ClassRoom;
import com.school.model.Section;
import com.school.model.Teacher;
import com.school.model.Timetable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TimetableRepo extends JpaRepository<Timetable, Long> {
    List<Timetable> findByClassRoomAndSectionAndDayOfWeekOrderByStartTime(ClassRoom c, Section s, String day);
    List<Timetable> findByTeacherAndDayOfWeekOrderByStartTime(Teacher t, String day);
    List<Timetable> findByClassRoomOrderByDayOfWeekAscStartTimeAsc(ClassRoom c);
}
