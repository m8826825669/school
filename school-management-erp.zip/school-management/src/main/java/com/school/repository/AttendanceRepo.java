package com.school.repository;

import com.school.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface AttendanceRepo extends JpaRepository<Attendance, Long> {
    List<Attendance> findByStudentAndDateBetweenOrderByDate(Student s, LocalDate from, LocalDate to);
    List<Attendance> findByDateAndStudent_ClassRoomAndStudent_Section(LocalDate date, ClassRoom c, Section s);
    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.student=:s AND a.status='PRESENT' AND a.date BETWEEN :from AND :to")
    long countPresent(@Param("s") Student s, @Param("from") LocalDate from, @Param("to") LocalDate to);
    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.student=:s AND a.date BETWEEN :from AND :to")
    long countTotal(@Param("s") Student s, @Param("from") LocalDate from, @Param("to") LocalDate to);
    boolean existsByStudentAndDate(Student s, LocalDate date);
    List<Attendance> findByDateAndStudent_ClassRoom(LocalDate date, ClassRoom c);
    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.date=:date AND a.status='PRESENT'")
    long countTodayPresent(@Param("date") LocalDate date);
}
