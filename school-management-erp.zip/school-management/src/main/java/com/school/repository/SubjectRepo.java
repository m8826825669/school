package com.school.repository;

import com.school.model.ClassRoom;
import com.school.model.Subject;
import com.school.model.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubjectRepo extends JpaRepository<Subject, Long> {
    List<Subject> findByClassRoom(ClassRoom classRoom);
    List<Subject> findByTeacher(Teacher teacher);
    Optional<Subject> findByCode(String code);
}
