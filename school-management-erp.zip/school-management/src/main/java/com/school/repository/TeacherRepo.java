package com.school.repository;

import com.school.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface TeacherRepo extends JpaRepository<Teacher, Long> {
    List<Teacher> findByStatus(Teacher.TeacherStatus status);
    Optional<Teacher> findByEmployeeId(String empId);
    @Query("SELECT t FROM Teacher t WHERE LOWER(t.firstName) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(t.lastName) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(t.employeeId) LIKE LOWER(CONCAT('%',:q,'%'))")
    List<Teacher> searchTeachers(@Param("q") String query);
    long countByStatus(Teacher.TeacherStatus status);
}
