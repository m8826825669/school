package com.school.repository;

import com.school.model.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepo extends JpaRepository<Staff, Long> {
    List<Staff> findByStatus(Staff.StaffStatus status);
    List<Staff> findByRole(String role);
    Optional<Staff> findByStaffId(String staffId);
    long countByStatus(Staff.StaffStatus status);
}
