package com.school.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;

import java.util.Optional;

public class UIHelper {

    public static void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("An error occurred");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("✅  Operation Successful");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static boolean confirm(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    public static Optional<String> prompt(String title, String label, String defaultValue) {
        TextInputDialog dialog = new TextInputDialog(defaultValue != null ? defaultValue : "");
        dialog.setTitle(title);
        dialog.setHeaderText(null);
        dialog.setContentText(label + ":");
        return dialog.showAndWait();
    }

    public static Label createBadge(String text, String color) {
        Label badge = new Label(text);
        badge.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 12; " +
                       "-fx-padding: 2 10; -fx-font-size: 11px; -fx-text-fill: white; -fx-font-weight: bold;");
        return badge;
    }

    public static Label statusBadge(String status) {
        String color = switch (status.toUpperCase()) {
            case "ACTIVE", "PAID", "PRESENT", "RETURNED"  -> "#4CAF50";
            case "PENDING", "ISSUED", "LATE"               -> "#FF9800";
            case "PARTIAL", "HALF_DAY"                     -> "#2196F3";
            case "OVERDUE", "ABSENT", "DROPPED"            -> "#F44336";
            case "WAIVED", "ON_LEAVE"                      -> "#9C27B0";
            default                                         -> "#607D8B";
        };
        return createBadge(status, color);
    }

    public static void styleTableView(TableView<?> table) {
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
        table.setPlaceholder(new Label("No records found"));
    }

    public static Button actionButton(String text, String style) {
        Button btn = new Button(text);
        btn.setStyle(style);
        return btn;
    }

    public static HBox createToolbar(Button... buttons) {
        HBox toolbar = new HBox(8);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(0, 0, 12, 0));
        toolbar.getChildren().addAll(buttons);
        return toolbar;
    }
}
