package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class StudentController implements Initializable {

    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> colAdmNo, colRoll, colName, colClass,
                                               colGender, colDOB, colFather, colPhone, colBlood;
    @FXML private TableColumn<Student, Void>   colStatus, colActions;
    @FXML private ComboBox<String> filterClass, filterSection, filterStatus;
    @FXML private TextField searchField;
    @FXML private Label lblTotal, lblActive, lblMale, lblFemale, lblRecordCount;

    private final SchoolService schoolService;
    private final ObservableList<Student> allStudents = FXCollections.observableArrayList();
    private final ObservableList<Student> filteredStudents = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupColumns();
        loadFilters();
        loadStudents();
        setupDoubleClick();
        UIHelper.styleTableView(studentTable);
    }

    private void setupColumns() {
        colAdmNo.setCellValueFactory(new PropertyValueFactory<>("admissionNo"));
        colRoll.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getRollNumber() != null ? String.valueOf(c.getValue().getRollNumber()) : "-"));
        colName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFullName()));
        colClass.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDisplayClass()));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colDOB.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getDateOfBirth() != null
                ? c.getValue().getDateOfBirth().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                : "-"));
        colFather.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getFatherName() != null ? c.getValue().getFatherName() : "-"));
        colPhone.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getGuardianPhone() != null ? c.getValue().getGuardianPhone() : "-"));
        colBlood.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getBloodGroup() != null ? c.getValue().getBloodGroup() : "-"));

        // Status badge column
        colStatus.setCellFactory(col -> new TableCell<Student, Void>() {
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow().getItem() == null) { setGraphic(null); return; }
                Student s = getTableRow().getItem();
                setGraphic(UIHelper.statusBadge(s.getStatus().name()));
            }
        });

        // Action buttons column
        colActions.setCellFactory(col -> new TableCell<Student, Void>() {
            private final Button btnEdit = new Button("✏️ Edit");
            private final Button btnView = new Button("👁️");
            private final HBox box = new HBox(4, btnView, btnEdit);

            {
                btnEdit.setStyle("-fx-background-color:#1565C0;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:10px;-fx-padding:3 8;");
                btnView.setStyle("-fx-background-color:#455A64;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:10px;-fx-padding:3 8;");
                btnEdit.setOnAction(e -> {
                    Student s = getTableRow().getItem();
                    if (s != null) openStudentDialog(s);
                });
                btnView.setOnAction(e -> {
                    Student s = getTableRow().getItem();
                    if (s != null) showStudentProfile(s);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });
    }

    private void loadFilters() {
        // Class filter
        List<String> classNames = schoolService.getAllClasses().stream()
            .map(ClassRoom::getName).collect(Collectors.toList());
        filterClass.getItems().clear();
        filterClass.getItems().add("All Classes");
        filterClass.getItems().addAll(classNames);
        filterClass.setValue("All Classes");

        // Section filter
        filterSection.getItems().clear();
        filterSection.getItems().addAll("All Sections", "A", "B", "C", "D");
        filterSection.setValue("All Sections");

        // Status filter
        filterStatus.getItems().clear();
        filterStatus.getItems().addAll("All Status", "ACTIVE", "TRANSFERRED", "PASSED_OUT", "DROPPED");
        filterStatus.setValue("All Status");
    }

    private void loadStudents() {
        allStudents.setAll(schoolService.getAllStudents());
        applyFilter();
    }

    @FXML
    private void applyFilter() {
        String classFilter   = filterClass.getValue();
        String sectionFilter = filterSection.getValue();
        String statusFilter  = filterStatus.getValue();
        String searchText    = searchField.getText().toLowerCase().trim();

        List<Student> result = allStudents.stream()
            .filter(s -> classFilter == null || classFilter.equals("All Classes") ||
                (s.getClassRoom() != null && s.getClassRoom().getName().equals(classFilter)))
            .filter(s -> sectionFilter == null || sectionFilter.equals("All Sections") ||
                (s.getSection() != null && s.getSection().getName().equals(sectionFilter)))
            .filter(s -> statusFilter == null || statusFilter.equals("All Status") ||
                s.getStatus().name().equals(statusFilter))
            .filter(s -> searchText.isEmpty() ||
                s.getFullName().toLowerCase().contains(searchText) ||
                (s.getAdmissionNo() != null && s.getAdmissionNo().toLowerCase().contains(searchText)) ||
                (s.getFatherName() != null && s.getFatherName().toLowerCase().contains(searchText)))
            .collect(Collectors.toList());

        filteredStudents.setAll(result);
        studentTable.setItems(filteredStudents);
        updateStats(result);
    }

    @FXML
    private void onSearch() { applyFilter(); }

    @FXML
    private void clearSearch() {
        searchField.clear();
        applyFilter();
    }

    private void updateStats(List<Student> students) {
        long active = students.stream().filter(s -> s.getStatus() == Student.StudentStatus.ACTIVE).count();
        long male   = students.stream().filter(s -> "MALE".equalsIgnoreCase(s.getGender())).count();
        long female = students.stream().filter(s -> "FEMALE".equalsIgnoreCase(s.getGender())).count();
        lblTotal.setText("Total: " + students.size());
        lblActive.setText("Active: " + active);
        lblMale.setText("Boys: " + male);
        lblFemale.setText("Girls: " + female);
        lblRecordCount.setText(students.size() + " record(s)");
    }

    @FXML
    private void addStudent() { openStudentDialog(null); }

    @FXML
    private void editStudent() {
        Student s = studentTable.getSelectionModel().getSelectedItem();
        if (s == null) { UIHelper.showInfo("Please select a student to edit."); return; }
        openStudentDialog(s);
    }

    @FXML
    private void deleteStudent() {
        Student s = studentTable.getSelectionModel().getSelectedItem();
        if (s == null) { UIHelper.showInfo("Please select a student."); return; }
        if (UIHelper.confirm("Delete Student", "Delete " + s.getFullName() + "? This cannot be undone.")) {
            schoolService.deleteStudent(s.getId());
            loadStudents();
            UIHelper.showSuccess("Student deleted successfully.");
        }
    }

    @FXML private void viewProfile() {
        Student s = studentTable.getSelectionModel().getSelectedItem();
        if (s != null) showStudentProfile(s);
    }

    @FXML private void viewAttendance() { UIHelper.showInfo("Navigate to Attendance module to view details."); }
    @FXML private void viewResults()    { UIHelper.showInfo("Navigate to Results module to view details."); }
    @FXML private void viewFees()       { UIHelper.showInfo("Navigate to Fee Management module."); }
    @FXML private void printIdCard()    { UIHelper.showInfo("ID Card generation coming soon!"); }

    @FXML
    private void exportExcel() {
        UIHelper.showInfo("Exporting " + filteredStudents.size() + " students to Excel...\n(Feature: saves to Desktop/students_export.xlsx)");
    }

    private void setupDoubleClick() {
        studentTable.setRowFactory(tv -> {
            TableRow<Student> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty()) {
                    showStudentProfile(row.getItem());
                }
            });
            return row;
        });
    }

    private void openStudentDialog(Student existing) {
        StudentFormDialog dialog = new StudentFormDialog(existing, schoolService);
        dialog.showAndWait().ifPresent(student -> {
            schoolService.saveStudent(student);
            loadStudents();
            UIHelper.showSuccess(existing == null ? "Student added successfully!" : "Student updated successfully!");
        });
    }

    private void showStudentProfile(Student student) {
        StudentProfileDialog dialog = new StudentProfileDialog(student, schoolService);
        dialog.showAndWait();
    }
}
