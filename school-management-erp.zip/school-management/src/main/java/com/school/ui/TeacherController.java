package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TeacherController implements Initializable {

    @FXML private TableView<Teacher> teacherTable;
    @FXML private TableColumn<Teacher, String> colEmpId, colName, colDesig, colDept,
                                               colPhone, colExp, colJoin, colSalary;
    @FXML private TableColumn<Teacher, Void>   colStatus, colActions;
    @FXML private ComboBox<String> filterDept, filterStatus;
    @FXML private TextField searchField;
    @FXML private Label lblTotal, lblActive, lblOnLeave, lblRecordCount;

    private final SchoolService schoolService;
    private final ObservableList<Teacher> allTeachers = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupColumns();
        setupFilters();
        loadTeachers();
        UIHelper.styleTableView(teacherTable);
        teacherTable.setRowFactory(tv -> {
            TableRow<Teacher> row = new TableRow<>();
            row.setOnMouseClicked(e -> { if (e.getClickCount() == 2 && !row.isEmpty()) openDialog(row.getItem()); });
            return row;
        });
    }

    private void setupColumns() {
        colEmpId.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        colName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFullName()));
        colDesig.setCellValueFactory(new PropertyValueFactory<>("designation"));
        colDept.setCellValueFactory(new PropertyValueFactory<>("department"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colExp.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getExperienceYears() != null ? c.getValue().getExperienceYears() + " yrs" : "-"));
        colJoin.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getJoiningDate() != null
                ? c.getValue().getJoiningDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        colSalary.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getSalary() != null ? "₹" + String.format("%,.0f", c.getValue().getSalary()) : "-"));
        colStatus.setCellFactory(col -> new TableCell<Teacher, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });
        colActions.setCellFactory(col -> new TableCell<Teacher, Void>() {
            private final Button btnEdit = new Button("✏️ Edit");
            { btnEdit.setStyle("-fx-background-color:#1565C0;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:10px;-fx-padding:3 8;");
              btnEdit.setOnAction(e -> { Teacher t = getTableRow().getItem(); if (t != null) openDialog(t); }); }
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e); setGraphic(e ? null : btnEdit); }
        });
    }

    private void setupFilters() {
        filterDept.getItems().addAll("All Departments","Mathematics","Science","English","Hindi",
            "Social Studies","Computer Science","Physics","Chemistry","Biology","Administration");
        filterDept.setValue("All Departments");
        filterStatus.getItems().addAll("All Status","ACTIVE","ON_LEAVE","RESIGNED","RETIRED");
        filterStatus.setValue("All Status");
    }

    private void loadTeachers() {
        allTeachers.setAll(schoolService.getAllTeachers());
        applyFilter();
    }

    @FXML
    private void applyFilter() {
        String dept = filterDept.getValue();
        String status = filterStatus.getValue();
        String search = searchField != null ? searchField.getText().toLowerCase().trim() : "";
        List<Teacher> result = allTeachers.stream()
            .filter(t -> dept == null || dept.equals("All Departments") || dept.equals(t.getDepartment()))
            .filter(t -> status == null || status.equals("All Status") || t.getStatus().name().equals(status))
            .filter(t -> search.isEmpty() || t.getFullName().toLowerCase().contains(search)
                || t.getEmployeeId().toLowerCase().contains(search))
            .collect(Collectors.toList());
        teacherTable.setItems(FXCollections.observableArrayList(result));
        long active = result.stream().filter(t -> t.getStatus() == Teacher.TeacherStatus.ACTIVE).count();
        long onLeave = result.stream().filter(t -> t.getStatus() == Teacher.TeacherStatus.ON_LEAVE).count();
        lblTotal.setText("Total: " + result.size());
        lblActive.setText("Active: " + active);
        lblOnLeave.setText("On Leave: " + onLeave);
        lblRecordCount.setText(result.size() + " record(s)");
    }

    @FXML private void onSearch() { applyFilter(); }
    @FXML private void addTeacher() { openDialog(null); }
    @FXML private void editTeacher() {
        Teacher t = teacherTable.getSelectionModel().getSelectedItem();
        if (t == null) { UIHelper.showInfo("Select a teacher first."); return; }
        openDialog(t);
    }
    @FXML private void deleteTeacher() {
        Teacher t = teacherTable.getSelectionModel().getSelectedItem();
        if (t == null) { UIHelper.showInfo("Select a teacher first."); return; }
        if (UIHelper.confirm("Delete Teacher", "Delete " + t.getFullName() + "?")) {
            schoolService.deleteTeacher(t.getId());
            loadTeachers();
            UIHelper.showSuccess("Teacher deleted.");
        }
    }
    @FXML private void exportExcel() { UIHelper.showInfo("Exporting teachers to Excel..."); }

    private void openDialog(Teacher existing) {
        Dialog<Teacher> dialog = buildTeacherDialog(existing);
        dialog.showAndWait().ifPresent(t -> {
            schoolService.saveTeacher(t);
            loadTeachers();
            UIHelper.showSuccess(existing == null ? "Teacher added!" : "Teacher updated!");
        });
    }

    private Dialog<Teacher> buildTeacherDialog(Teacher existing) {
        Dialog<Teacher> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "➕  Add Teacher" : "✏️  Edit Teacher");
        dialog.setResizable(true);
        dialog.getDialogPane().setPrefSize(700, 560);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        Button ok = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        ok.setText("💾  Save");
        ok.setStyle("-fx-background-color:#1565C0;-fx-text-fill:white;-fx-font-weight:bold;-fx-padding:8 20;");

        // Form fields
        TextField tfFirst    = new TextField(); tfFirst.setPromptText("First Name");
        TextField tfLast     = new TextField(); tfLast.setPromptText("Last Name");
        TextField tfEmpId    = new TextField(); tfEmpId.setPromptText("Auto-generated"); tfEmpId.setEditable(false);
        TextField tfPhone    = new TextField(); tfPhone.setPromptText("Phone Number");
        TextField tfEmail    = new TextField(); tfEmail.setPromptText("Email Address");
        TextField tfQual     = new TextField(); tfQual.setPromptText("Qualification");
        TextField tfSpec     = new TextField(); tfSpec.setPromptText("Specialization");
        TextField tfSalary   = new TextField(); tfSalary.setPromptText("Monthly Salary");
        TextField tfExp      = new TextField(); tfExp.setPromptText("Years of Experience");
        TextArea  taAddress  = new TextArea();  taAddress.setPrefRowCount(2); taAddress.setPromptText("Address");
        ComboBox<String> cbGender  = new ComboBox<>(FXCollections.observableArrayList("Male","Female","Other"));
        ComboBox<String> cbDesig   = new ComboBox<>(FXCollections.observableArrayList("Principal","Vice-Principal","HOD","Senior Teacher","Teacher","Lecturer","Lab Assistant"));
        ComboBox<String> cbDept    = new ComboBox<>(FXCollections.observableArrayList("Mathematics","Science","English","Hindi","Social Studies","Computer Science","Physics","Chemistry","Biology","Physical Education","Art","Music","Administration"));
        ComboBox<String> cbStatus  = new ComboBox<>(FXCollections.observableArrayList("ACTIVE","ON_LEAVE","RESIGNED","RETIRED"));
        DatePicker dpJoin = new DatePicker();
        DatePicker dpDOB  = new DatePicker();
        cbStatus.setValue("ACTIVE");

        if (existing != null) {
            tfFirst.setText(existing.getFirstName()); tfLast.setText(existing.getLastName());
            tfEmpId.setText(existing.getEmployeeId()); tfPhone.setText(existing.getPhone());
            tfEmail.setText(existing.getEmail()); tfQual.setText(existing.getQualification());
            tfSpec.setText(existing.getSpecialization());
            if (existing.getSalary() != null) tfSalary.setText(String.valueOf(existing.getSalary()));
            if (existing.getExperienceYears() != null) tfExp.setText(String.valueOf(existing.getExperienceYears()));
            taAddress.setText(existing.getAddress()); cbGender.setValue(existing.getGender());
            cbDesig.setValue(existing.getDesignation()); cbDept.setValue(existing.getDepartment());
            if (existing.getStatus() != null) cbStatus.setValue(existing.getStatus().name());
            dpJoin.setValue(existing.getJoiningDate()); dpDOB.setValue(existing.getDateOfBirth());
        }

        GridPane grid = new GridPane();
        grid.setHgap(14); grid.setVgap(10); grid.setPadding(new Insets(20));
        ColumnConstraints lc = new ColumnConstraints(130);
        ColumnConstraints fc = new ColumnConstraints(); fc.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(lc,fc,lc,fc);
        // Make fields full width
        for (var f : List.of(tfFirst,tfLast,tfPhone,tfEmail,tfQual,tfSpec,tfSalary,tfExp)) { f.setMaxWidth(Double.MAX_VALUE); }
        for (var c : List.of(cbGender,cbDesig,cbDept,cbStatus,dpJoin,dpDOB)) { c.setMaxWidth(Double.MAX_VALUE); }

        int r = 0;
        row(grid,r++,"First Name *",tfFirst,"Last Name *",tfLast);
        row(grid,r++,"Designation",cbDesig,"Department",cbDept);
        row(grid,r++,"Gender",cbGender,"Date of Birth",dpDOB);
        row(grid,r++,"Joining Date",dpJoin,"Qualification",tfQual);
        row(grid,r++,"Specialization",tfSpec,"Experience (yrs)",tfExp);
        row(grid,r++,"Phone *",tfPhone,"Email",tfEmail);
        row(grid,r++,"Salary (₹)",tfSalary,"Status",cbStatus);
        Label la = lbl("Address"); taAddress.setMaxWidth(Double.MAX_VALUE); GridPane.setColumnSpan(taAddress,3);
        grid.add(la,0,r); grid.add(taAddress,1,r);

        dialog.getDialogPane().setContent(new ScrollPane(grid) {{ setFitToWidth(true); }});

        dialog.setResultConverter(btn -> {
            if (btn != ButtonType.OK) return null;
            if (tfFirst.getText().isBlank()) { UIHelper.showError("First name required."); return null; }
            if (tfPhone.getText().isBlank()) { UIHelper.showError("Phone required."); return null; }
            Teacher t = existing != null ? existing : new Teacher();
            t.setFirstName(tfFirst.getText().trim()); t.setLastName(tfLast.getText().trim());
            t.setPhone(tfPhone.getText().trim()); t.setEmail(tfEmail.getText().trim());
            t.setQualification(tfQual.getText().trim()); t.setSpecialization(tfSpec.getText().trim());
            t.setGender(cbGender.getValue()); t.setDesignation(cbDesig.getValue());
            t.setDepartment(cbDept.getValue()); t.setJoiningDate(dpJoin.getValue());
            t.setDateOfBirth(dpDOB.getValue()); t.setAddress(taAddress.getText().trim());
            if (!tfSalary.getText().isBlank()) try { t.setSalary(Double.parseDouble(tfSalary.getText())); } catch(Exception ignored){}
            if (!tfExp.getText().isBlank()) try { t.setExperienceYears(Integer.parseInt(tfExp.getText())); } catch(Exception ignored){}
            if (cbStatus.getValue() != null) t.setStatus(Teacher.TeacherStatus.valueOf(cbStatus.getValue()));
            return t;
        });
        return dialog;
    }

    private void row(GridPane g, int r, String l1, javafx.scene.Node f1, String l2, javafx.scene.Node f2) {
        g.add(lbl(l1),0,r); g.add(f1,1,r); g.add(lbl(l2),2,r); g.add(f2,3,r);
    }
    private Label lbl(String t) {
        Label l = new Label(t); l.setStyle("-fx-font-weight:bold;-fx-text-fill:#37474F;"); return l;
    }
}
