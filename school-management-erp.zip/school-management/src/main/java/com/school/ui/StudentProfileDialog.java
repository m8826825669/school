package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StudentProfileDialog extends Dialog<Void> {

    private final Student student;
    private final SchoolService service;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd MMM yyyy");

    public StudentProfileDialog(Student student, SchoolService service) {
        this.student = student;
        this.service = service;
        setTitle("👤  Student Profile — " + student.getFullName());
        setResizable(true);
        getDialogPane().setPrefSize(860, 660);
        getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        getDialogPane().setContent(buildContent());
    }

    private TabPane buildContent() {
        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabs.getTabs().add(buildProfileTab());
        tabs.getTabs().add(buildAttendanceTab());
        tabs.getTabs().add(buildResultTab());
        tabs.getTabs().add(buildFeeTab());
        return tabs;
    }

    // ==================== PROFILE TAB ====================
    private Tab buildProfileTab() {
        VBox root = new VBox(16);
        root.setPadding(new Insets(20));

        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("-fx-background-color:linear-gradient(to right,#1565C0,#1976D2);" +
                        "-fx-background-radius:12;-fx-padding:20;");

        Label avatar = new Label(student.getFirstName().substring(0, 1).toUpperCase());
        avatar.setStyle("-fx-background-color:white;-fx-background-radius:50%;" +
                        "-fx-min-width:72;-fx-min-height:72;-fx-max-width:72;-fx-max-height:72;" +
                        "-fx-alignment:center;-fx-font-size:32;-fx-font-weight:bold;-fx-text-fill:#1565C0;");

        VBox info = new VBox(6);
        Label name = new Label(student.getFullName());
        name.setStyle("-fx-font-size:22px;-fx-font-weight:bold;-fx-text-fill:white;");
        Label adm = new Label("Adm No: " + student.getAdmissionNo() + "  |  " + student.getDisplayClass());
        adm.setStyle("-fx-font-size:13px;-fx-text-fill:#BBDEFB;");
        info.getChildren().addAll(name, adm, UIHelper.statusBadge(student.getStatus().name()));

        header.getChildren().addAll(avatar, info);

        GridPane grid = new GridPane();
        grid.setHgap(24); grid.setVgap(12);
        grid.setStyle("-fx-background-color:white;-fx-background-radius:10;-fx-padding:20;" +
                      "-fx-effect:dropshadow(gaussian,rgba(0,0,0,0.08),8,0,0,2);");
        ColumnConstraints lc = new ColumnConstraints(160);
        ColumnConstraints vc = new ColumnConstraints(); vc.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(lc, vc, lc, vc);

        int row = 0;
        addField(grid, row++, "Date of Birth",  fmt(student.getDateOfBirth()),
                               "Gender",         nvl(student.getGender()));
        addField(grid, row++, "Blood Group",    nvl(student.getBloodGroup()),
                               "Category",       nvl(student.getCategory()));
        addField(grid, row++, "Phone",          nvl(student.getPhone()),
                               "Email",          nvl(student.getEmail()));
        addField(grid, row++, "Father's Name",  nvl(student.getFatherName()),
                               "Mother's Name",  nvl(student.getMotherName()));
        addField(grid, row++, "Guardian",       nvl(student.getGuardianName()),
                               "Guardian Phone", nvl(student.getGuardianPhone()));
        addField(grid, row++, "Admission Date", fmt(student.getAdmissionDate()),
                               "Roll Number",    student.getRollNumber() != null
                                                     ? String.valueOf(student.getRollNumber()) : "-");
        addField(grid, row++, "Religion",       nvl(student.getReligion()),
                               "Transport",      Boolean.TRUE.equals(student.getTransportRequired()) ? "Yes" : "No");

        Label addrLbl = lbl("Address", true);
        Label addrVal = lbl(nvl(student.getAddress()), false);
        addrVal.setWrapText(true);
        GridPane.setColumnSpan(addrVal, 3);
        grid.add(addrLbl, 0, row); grid.add(addrVal, 1, row);

        root.getChildren().addAll(header, grid);
        ScrollPane sp = new ScrollPane(root); sp.setFitToWidth(true);
        Tab tab = new Tab("👤  Profile"); tab.setContent(sp); return tab;
    }

    // ==================== ATTENDANCE TAB ====================
    private Tab buildAttendanceTab() {
        VBox root = new VBox(16);
        root.setPadding(new Insets(20));

        Label title = new Label("📅  Attendance Summary");
        title.setStyle("-fx-font-size:16px;-fx-font-weight:bold;");

        LocalDate yearStart = LocalDate.now().withDayOfYear(1);
        double pct = service.getAttendancePercentage(student, yearStart, LocalDate.now());
        ProgressBar pb = new ProgressBar(pct / 100.0);
        pb.setPrefWidth(420);
        pb.setStyle(pct >= 75 ? "-fx-accent:#4CAF50;" : "-fx-accent:#F44336;");
        Label pctLabel = new Label(String.format("%.1f%% attendance this year", pct));
        pctLabel.setStyle("-fx-font-weight:bold;-fx-font-size:14px;" +
                          (pct >= 75 ? "-fx-text-fill:#2E7D32;" : "-fx-text-fill:#C62828;"));

        TableView<Attendance> table = new TableView<>();
        UIHelper.styleTableView(table);

        TableColumn<Attendance, String> colDate = new TableColumn<>("Date");
        colDate.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDate().format(FMT)));

        TableColumn<Attendance, Void> colStatus = new TableColumn<>("Status");
        colStatus.setCellFactory(col -> new TableCell<Attendance, Void>() {
            protected void updateItem(Void i, boolean empty) {
                super.updateItem(i, empty);
                if (empty || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });

        TableColumn<Attendance, String> colRemark = new TableColumn<>("Remarks");
        colRemark.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getRemarks() != null ? c.getValue().getRemarks() : ""));

        table.getColumns().addAll(colDate, colStatus, colRemark);
        table.setItems(FXCollections.observableArrayList(
            service.getStudentAttendance(student, LocalDate.now().minusMonths(3), LocalDate.now())));
        VBox.setVgrow(table, Priority.ALWAYS);

        root.getChildren().addAll(title, pb, pctLabel, table);
        Tab tab = new Tab("✅  Attendance"); tab.setContent(root); return tab;
    }

    // ==================== RESULTS TAB ====================
    private Tab buildResultTab() {
        VBox root = new VBox(16);
        root.setPadding(new Insets(20));

        Label title = new Label("📊  Exam Results");
        title.setStyle("-fx-font-size:16px;-fx-font-weight:bold;");

        TableView<ExamResult> table = new TableView<>();
        UIHelper.styleTableView(table);

        TableColumn<ExamResult, String> cExam = new TableColumn<>("Exam");
        cExam.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getExam().getName()));

        TableColumn<ExamResult, String> cSubj = new TableColumn<>("Subject");
        cSubj.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSubject().getName()));

        TableColumn<ExamResult, String> cMarks = new TableColumn<>("Marks");
        cMarks.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getMarksObtained() + "/" + c.getValue().getMaxMarks()));

        TableColumn<ExamResult, String> cPct = new TableColumn<>("Percentage");
        cPct.setCellValueFactory(c -> new SimpleStringProperty(
            String.format("%.1f%%", c.getValue().getPercentage())));

        TableColumn<ExamResult, String> cGrade = new TableColumn<>("Grade");
        cGrade.setCellValueFactory(c -> new SimpleStringProperty(nvl(c.getValue().getGrade())));

        TableColumn<ExamResult, Void> cPass = new TableColumn<>("Result");
        cPass.setCellFactory(col -> new TableCell<ExamResult, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                boolean pass = Boolean.TRUE.equals(getTableRow().getItem().getIsPassed());
                setGraphic(UIHelper.statusBadge(pass ? "PASSED" : "FAILED"));
            }
        });

        table.getColumns().addAll(cExam, cSubj, cMarks, cPct, cGrade, cPass);
        table.setItems(FXCollections.observableArrayList(service.getStudentResults(student)));
        VBox.setVgrow(table, Priority.ALWAYS);

        root.getChildren().addAll(title, table);
        Tab tab = new Tab("🏆  Results"); tab.setContent(root); return tab;
    }

    // ==================== FEE TAB ====================
    private Tab buildFeeTab() {
        VBox root = new VBox(16);
        root.setPadding(new Insets(20));

        Label title = new Label("💰  Fee Payment History");
        title.setStyle("-fx-font-size:16px;-fx-font-weight:bold;");

        TableView<FeePayment> table = new TableView<>();
        UIHelper.styleTableView(table);

        TableColumn<FeePayment, String> cReceipt = new TableColumn<>("Receipt No");
        cReceipt.setCellValueFactory(c -> new SimpleStringProperty(nvl(c.getValue().getReceiptNo())));

        TableColumn<FeePayment, String> cFee = new TableColumn<>("Fee Type");
        cFee.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getFeeStructure() != null ? c.getValue().getFeeStructure().getName() : "-"));

        TableColumn<FeePayment, String> cAmt = new TableColumn<>("Amount Paid");
        cAmt.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getAmountPaid() != null
                ? "₹" + String.format("%,.0f", c.getValue().getAmountPaid()) : "-"));

        TableColumn<FeePayment, String> cDate = new TableColumn<>("Date");
        cDate.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getPaymentDate() != null ? c.getValue().getPaymentDate().format(FMT) : "-"));

        TableColumn<FeePayment, String> cMode = new TableColumn<>("Mode");
        cMode.setCellValueFactory(c -> new SimpleStringProperty(nvl(c.getValue().getPaymentMode())));

        TableColumn<FeePayment, Void> cStatus = new TableColumn<>("Status");
        cStatus.setCellFactory(col -> new TableCell<FeePayment, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });

        table.getColumns().addAll(cReceipt, cFee, cAmt, cDate, cMode, cStatus);
        table.setItems(FXCollections.observableArrayList(service.getPaymentsByStudent(student)));
        VBox.setVgrow(table, Priority.ALWAYS);

        root.getChildren().addAll(title, table);
        Tab tab = new Tab("💰  Fees"); tab.setContent(root); return tab;
    }

    // ==================== HELPERS ====================
    private void addField(GridPane g, int row, String l1, String v1, String l2, String v2) {
        g.add(lbl(l1, true), 0, row); g.add(lbl(v1, false), 1, row);
        g.add(lbl(l2, true), 2, row); g.add(lbl(v2, false), 3, row);
    }

    private Label lbl(String text, boolean bold) {
        Label l = new Label(text != null ? text : "-");
        l.setStyle(bold ? "-fx-font-weight:bold;-fx-text-fill:#546E7A;-fx-font-size:12px;"
                        : "-fx-text-fill:#212121;-fx-font-size:12px;");
        return l;
    }

    private String nvl(String s) { return (s != null && !s.isBlank()) ? s : "-"; }
    private String fmt(LocalDate d) { return d != null ? d.format(FMT) : "-"; }
}
