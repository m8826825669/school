package com.school.ui;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

@Component
@Slf4j
public class MainController implements Initializable {

    @FXML private StackPane contentArea;
    @FXML private Label lblPageTitle, lblClock, lblDate;
    @FXML private Button btnDashboard, btnStudents, btnTeachers, btnClasses,
                         btnAttendance, btnExams, btnResults, btnTimetable,
                         btnFees, btnLibrary, btnStaff, btnNotices, btnReports;

    private final ApplicationContext appContext;
    private Button activeButton;
    private final Map<String, Node> pageCache = new HashMap<>();

    public MainController(ApplicationContext appContext) {
        this.appContext = appContext;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupClock();
        setupDate();
        activeButton = btnDashboard;
        loadPage("dashboard", "Dashboard");
    }

    private void setupClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            lblClock.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a")));
        }));
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }

    private void setupDate() {
        lblDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy")));
    }

    @FXML
    private void navigate(javafx.event.ActionEvent event) {
        Button clicked = (Button) event.getSource();
        String page = (String) clicked.getUserData();
        String title = switch (page) {
            case "dashboard"   -> "Dashboard";
            case "students"    -> "Student Management";
            case "teachers"    -> "Teacher Management";
            case "classes"     -> "Classes & Sections";
            case "attendance"  -> "Attendance Management";
            case "exams"       -> "Examination Management";
            case "results"     -> "Results & Report Cards";
            case "timetable"   -> "Timetable Management";
            case "fees"        -> "Fee Management";
            case "library"     -> "Library Management";
            case "staff"       -> "Staff Management";
            case "notices"     -> "Notice Board";
            case "reports"     -> "Reports & Analytics";
            default            -> page;
        };
        setActiveButton(clicked);
        loadPage(page, title);
    }

    private void setActiveButton(Button btn) {
        if (activeButton != null) {
            activeButton.getStyleClass().remove("nav-active");
        }
        btn.getStyleClass().add("nav-active");
        activeButton = btn;
    }

    private void loadPage(String page, String title) {
        lblPageTitle.setText(title);
        try {
            // Use cache to avoid reloading
            if (pageCache.containsKey(page)) {
                contentArea.getChildren().setAll(pageCache.get(page));
                return;
            }
            String fxmlPath = "/fxml/" + page + ".fxml";
            URL resource = getClass().getResource(fxmlPath);
            if (resource == null) {
                log.warn("FXML not found: {}", fxmlPath);
                showPlaceholder(title);
                return;
            }
            FXMLLoader loader = new FXMLLoader(resource);
            loader.setControllerFactory(appContext::getBean);
            Node view = loader.load();
            pageCache.put(page, view);
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            log.error("Error loading page: {}", page, e);
            showPlaceholder(title + " (Error loading view)");
        }
    }

    private void showPlaceholder(String title) {
        Label ph = new Label("📂  " + title + "\nModule coming soon...");
        ph.setStyle("-fx-font-size: 22px; -fx-text-fill: #90A4AE; -fx-text-alignment: center;");
        ph.setAlignment(javafx.geometry.Pos.CENTER);
        contentArea.getChildren().setAll(ph);
    }

    @FXML
    private void showNotifications() {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
            javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle("Notifications");
        alert.setHeaderText("Recent Alerts");
        alert.setContentText("📚 3 overdue books in library\n💰 12 pending fee payments\n📅 PTM scheduled for Nov 10");
        alert.showAndWait();
    }

    public void invalidateCache(String page) {
        pageCache.remove(page);
    }
}
