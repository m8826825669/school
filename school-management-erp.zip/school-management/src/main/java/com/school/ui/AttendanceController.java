package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.LocalDate;
import java.util.*;

@Component
@RequiredArgsConstructor
public class AttendanceController implements Initializable {

    @FXML private DatePicker dpDate;
    @FXML private ComboBox<ClassRoom> cbClass;
    @FXML private ComboBox<Section> cbSection;
    @FXML private TableView<AttendanceRow> attendanceTable;
    @FXML private TableColumn<AttendanceRow, String> colRoll, colName, colClass, colGender;
    @FXML private TableColumn<AttendanceRow, Void>   colRemarks;
    @FXML private TableColumn<AttendanceRow, RadioButton> colPresent, colAbsent, colLate, colHalfDay, colLeave;
    @FXML private Label lblPresent, lblAbsent, lblLate, lblTotal, lblPercentage, lblStatus;

    private final SchoolService schoolService;
    private final ObservableList<AttendanceRow> rows = FXCollections.observableArrayList();

    // Inner class to hold attendance row data
    public static class AttendanceRow {
        final Student student;
        final ToggleGroup group = new ToggleGroup();
        final RadioButton rbPresent  = new RadioButton();
        final RadioButton rbAbsent   = new RadioButton();
        final RadioButton rbLate     = new RadioButton();
        final RadioButton rbHalfDay  = new RadioButton();
        final RadioButton rbLeave    = new RadioButton();
        final TextField   tfRemarks  = new TextField();

        AttendanceRow(Student student, Attendance.AttendanceStatus status) {
            this.student = student;
            rbPresent.setToggleGroup(group);
            rbAbsent.setToggleGroup(group);
            rbLate.setToggleGroup(group);
            rbHalfDay.setToggleGroup(group);
            rbLeave.setToggleGroup(group);
            tfRemarks.setPromptText("Remarks...");
            tfRemarks.setPrefWidth(150);
            setStatus(status != null ? status : Attendance.AttendanceStatus.PRESENT);
        }

        void setStatus(Attendance.AttendanceStatus s) {
            switch (s) {
                case PRESENT  -> rbPresent.setSelected(true);
                case ABSENT   -> rbAbsent.setSelected(true);
                case LATE     -> rbLate.setSelected(true);
                case HALF_DAY -> rbHalfDay.setSelected(true);
                case LEAVE    -> rbLeave.setSelected(true);
                default       -> rbPresent.setSelected(true);
            }
        }

        Attendance.AttendanceStatus getStatus() {
            if (rbAbsent.isSelected())  return Attendance.AttendanceStatus.ABSENT;
            if (rbLate.isSelected())    return Attendance.AttendanceStatus.LATE;
            if (rbHalfDay.isSelected()) return Attendance.AttendanceStatus.HALF_DAY;
            if (rbLeave.isSelected())   return Attendance.AttendanceStatus.LEAVE;
            return Attendance.AttendanceStatus.PRESENT;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dpDate.setValue(LocalDate.now());
        cbClass.getItems().addAll(schoolService.getAllClasses());
        setupColumns();
        attendanceTable.setItems(rows);
        UIHelper.styleTableView(attendanceTable);
    }

    private void setupColumns() {
        colRoll.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().student.getRollNumber() != null ? String.valueOf(c.getValue().student.getRollNumber()) : "-"));
        colName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().student.getFullName()));
        colClass.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().student.getDisplayClass()));
        colGender.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().student.getGender() != null ? c.getValue().student.getGender().substring(0,1) : "-"));
        colRemarks.setCellFactory(col -> new TableCell<AttendanceRow, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(getTableRow().getItem().tfRemarks);
            }
        });
        radioCol(colPresent,  r -> r.rbPresent);
        radioCol(colAbsent,   r -> r.rbAbsent);
        radioCol(colLate,     r -> r.rbLate);
        radioCol(colHalfDay,  r -> r.rbHalfDay);
        radioCol(colLeave,    r -> r.rbLeave);

        // Update stats when any radio changes
        rows.addListener((javafx.collections.ListChangeListener<AttendanceRow>) c -> updateStats());
    }

    private void radioCol(TableColumn<AttendanceRow, RadioButton> col,
                           java.util.function.Function<AttendanceRow, RadioButton> fn) {
        col.setCellFactory(c -> new TableCell<>() {
            protected void updateItem(RadioButton i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                RadioButton rb = fn.apply(getTableRow().getItem());
                rb.setOnAction(ev -> updateStats());
                setGraphic(rb);
            }
        });
    }

    @FXML
    private void onClassChange() {
        cbSection.getItems().clear();
        if (cbClass.getValue() != null) {
            cbSection.getItems().addAll(schoolService.getSectionsByClass(cbClass.getValue()));
        }
        loadAttendance();
    }

    @FXML
    private void loadAttendance() {
        rows.clear();
        ClassRoom cls = cbClass.getValue();
        Section sec   = cbSection.getValue();
        LocalDate date = dpDate.getValue();
        if (cls == null || date == null) {
            lblStatus.setText("Please select class and date.");
            return;
        }
        List<Student> students = sec != null
            ? schoolService.getStudentsByClassAndSection(cls, sec)
            : schoolService.getStudentsByClass(cls);

        // Load existing attendance if any
        List<Attendance> existing = schoolService.getAttendanceByClassAndDate(cls, date);
        Map<Long, Attendance.AttendanceStatus> existingMap = new HashMap<>();
        for (Attendance a : existing) existingMap.put(a.getStudent().getId(), a.getStatus());

        for (Student s : students) {
            Attendance.AttendanceStatus status = existingMap.getOrDefault(s.getId(), Attendance.AttendanceStatus.PRESENT);
            rows.add(new AttendanceRow(s, status));
        }
        updateStats();
        lblStatus.setText("Loaded " + students.size() + " students for " + cls.getName() +
            (sec != null ? "-" + sec.getName() : "") + " on " + date);
    }

    @FXML
    private void markAllPresent() {
        rows.forEach(r -> r.rbPresent.setSelected(true));
        updateStats();
    }

    @FXML
    private void markAllAbsent() {
        rows.forEach(r -> r.rbAbsent.setSelected(true));
        updateStats();
    }

    @FXML
    private void saveAttendance() {
        if (rows.isEmpty()) { UIHelper.showInfo("No students loaded. Select a class first."); return; }
        LocalDate date = dpDate.getValue();
        for (AttendanceRow row : rows) {
            schoolService.markAttendance(row.student, date, row.getStatus(), row.tfRemarks.getText().trim());
        }
        UIHelper.showSuccess("Attendance saved for " + rows.size() + " students!");
        updateStats();
    }

    private void updateStats() {
        long present = rows.stream().filter(r -> r.getStatus() == Attendance.AttendanceStatus.PRESENT).count();
        long absent  = rows.stream().filter(r -> r.getStatus() == Attendance.AttendanceStatus.ABSENT).count();
        long late    = rows.stream().filter(r -> r.getStatus() == Attendance.AttendanceStatus.LATE).count();
        lblPresent.setText("Present: " + present);
        lblAbsent.setText("Absent: " + absent);
        lblLate.setText("Late: " + late);
        lblTotal.setText("Total: " + rows.size());
        double pct = rows.isEmpty() ? 0 : (present * 100.0) / rows.size();
        lblPercentage.setText(String.format("Attendance: %.1f%%", pct));
        lblPercentage.setStyle(pct >= 75
            ? "-fx-text-fill:#2E7D32;-fx-font-weight:bold;"
            : "-fx-text-fill:#C62828;-fx-font-weight:bold;");
    }

    @FXML private void monthlyReport() { UIHelper.showInfo("Monthly attendance report — opens PDF export dialog."); }
    @FXML private void exportReport()  { UIHelper.showInfo("Exporting attendance to Excel..."); }
}
