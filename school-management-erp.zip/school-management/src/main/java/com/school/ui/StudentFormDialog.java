package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.util.List;

public class StudentFormDialog extends Dialog<Student> {

    private final Student existing;
    private final SchoolService schoolService;

    // Personal fields
    private final TextField tfFirstName = styled(new TextField(), "First Name");
    private final TextField tfLastName  = styled(new TextField(), "Last Name");
    private final DatePicker dpDOB      = new DatePicker();
    private final ComboBox<String> cbGender   = new ComboBox<>();
    private final TextField tfPhone    = styled(new TextField(), "Phone Number");
    private final TextField tfEmail    = styled(new TextField(), "Email");
    private final TextArea  taAddress  = new TextArea();

    // Academic fields
    private final ComboBox<ClassRoom> cbClass   = new ComboBox<>();
    private final ComboBox<Section>   cbSection = new ComboBox<>();
    private final TextField tfRollNo = styled(new TextField(), "Roll Number");
    private final DatePicker dpAdmDate = new DatePicker();
    private final TextField tfAdmNo = styled(new TextField(), "Admission No (Auto)");
    private final ComboBox<String> cbCategory = new ComboBox<>();
    private final ComboBox<String> cbStatus   = new ComboBox<>();

    // Parent fields
    private final TextField tfFather   = styled(new TextField(), "Father's Name");
    private final TextField tfMother   = styled(new TextField(), "Mother's Name");
    private final TextField tfGuardian = styled(new TextField(), "Guardian Name");
    private final TextField tfGuardPhone = styled(new TextField(), "Guardian Phone");
    private final ComboBox<String> cbRelation = new ComboBox<>();

    // Medical
    private final ComboBox<String> cbBlood = new ComboBox<>();
    private final TextArea taMedical = new TextArea();

    public StudentFormDialog(Student existing, SchoolService service) {
        this.existing = existing;
        this.schoolService = service;

        setTitle(existing == null ? "➕  Add New Student" : "✏️  Edit Student");
        setResizable(true);

        getDialogPane().setPrefSize(780, 680);
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button okBtn = (Button) getDialogPane().lookupButton(ButtonType.OK);
        okBtn.setText("💾  Save Student");
        okBtn.setStyle("-fx-background-color:#1565C0;-fx-text-fill:white;-fx-font-weight:bold;-fx-padding:8 20;");

        getDialogPane().setContent(buildContent());
        populateDropdowns();
        if (existing != null) fillForm(existing);

        setResultConverter(btn -> {
            if (btn == ButtonType.OK) return buildStudent();
            return null;
        });

        okBtn.addEventFilter(javafx.event.ActionEvent.ACTION, e -> {
            if (!validate()) e.consume();
        });
    }

    private VBox buildContent() {
        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        tabs.getTabs().add(buildTab("👤  Personal", buildPersonalGrid()));
        tabs.getTabs().add(buildTab("🎓  Academic", buildAcademicGrid()));
        tabs.getTabs().add(buildTab("👨‍👩‍👧  Parent/Guardian", buildParentGrid()));
        tabs.getTabs().add(buildTab("🏥  Medical", buildMedicalGrid()));

        VBox content = new VBox(tabs);
        content.setPadding(new Insets(16));
        return content;
    }

    private Tab buildTab(String name, GridPane grid) {
        Tab tab = new Tab(name);
        ScrollPane sp = new ScrollPane(grid);
        sp.setFitToWidth(true);
        tab.setContent(sp);
        return tab;
    }

    private GridPane buildPersonalGrid() {
        GridPane g = grid();
        cbGender.getItems().addAll("MALE", "FEMALE", "OTHER");
        dpDOB.setPromptText("Date of Birth");
        taAddress.setPrefRowCount(3);
        taAddress.setPromptText("Full Address");

        addRow(g, 0, "First Name *",    tfFirstName,    "Last Name *",  tfLastName);
        addRow(g, 1, "Date of Birth",   dpDOB,          "Gender",       cbGender);
        addRow(g, 2, "Phone",           tfPhone,        "Email",        tfEmail);
        addFull(g, 3, "Address",        taAddress);
        return g;
    }

    private GridPane buildAcademicGrid() {
        GridPane g = grid();
        dpAdmDate.setValue(LocalDate.now());
        tfAdmNo.setEditable(false);
        tfAdmNo.setStyle("-fx-background-color:#F5F5F5;");
        cbCategory.getItems().addAll("GEN","OBC","SC","ST","EWS");
        cbStatus.getItems().addAll("ACTIVE","TRANSFERRED","PASSED_OUT","DROPPED");
        cbStatus.setValue("ACTIVE");

        cbClass.getItems().addAll(schoolService.getAllClasses());
        cbClass.setOnAction(e -> {
            cbSection.getItems().clear();
            if (cbClass.getValue() != null) {
                cbSection.getItems().addAll(schoolService.getSectionsByClass(cbClass.getValue()));
            }
        });

        addRow(g, 0, "Admission No",    tfAdmNo,        "Admission Date", dpAdmDate);
        addRow(g, 1, "Class *",         cbClass,        "Section",        cbSection);
        addRow(g, 2, "Roll Number",     tfRollNo,       "Category",       cbCategory);
        addRow(g, 3, "Status",          cbStatus,       "",               new Label(""));
        return g;
    }

    private GridPane buildParentGrid() {
        GridPane g = grid();
        cbRelation.getItems().addAll("Father","Mother","Guardian","Uncle","Aunt","Grandparent","Other");
        addRow(g, 0, "Father's Name",   tfFather,       "Mother's Name",   tfMother);
        addRow(g, 1, "Guardian Name",   tfGuardian,     "Relation",        cbRelation);
        addRow(g, 2, "Guardian Phone *",tfGuardPhone,   "",                new Label(""));
        return g;
    }

    private GridPane buildMedicalGrid() {
        GridPane g = grid();
        cbBlood.getItems().addAll("A+","A-","B+","B-","AB+","AB-","O+","O-","Unknown");
        taMedical.setPrefRowCount(4);
        taMedical.setPromptText("Any known medical conditions, allergies...");
        addRow(g, 0, "Blood Group",     cbBlood,        "",               new Label(""));
        addFull(g, 1, "Medical Notes",  taMedical);
        return g;
    }

    private void populateDropdowns() {}

    private void fillForm(Student s) {
        tfFirstName.setText(s.getFirstName());
        tfLastName.setText(s.getLastName());
        dpDOB.setValue(s.getDateOfBirth());
        cbGender.setValue(s.getGender());
        tfPhone.setText(s.getPhone());
        tfEmail.setText(s.getEmail());
        taAddress.setText(s.getAddress());
        tfAdmNo.setText(s.getAdmissionNo());
        dpAdmDate.setValue(s.getAdmissionDate());
        cbClass.setValue(s.getClassRoom());
        if (s.getClassRoom() != null) {
            cbSection.getItems().addAll(schoolService.getSectionsByClass(s.getClassRoom()));
            cbSection.setValue(s.getSection());
        }
        if (s.getRollNumber() != null) tfRollNo.setText(String.valueOf(s.getRollNumber()));
        cbCategory.setValue(s.getCategory());
        if (s.getStatus() != null) cbStatus.setValue(s.getStatus().name());
        tfFather.setText(s.getFatherName());
        tfMother.setText(s.getMotherName());
        tfGuardian.setText(s.getGuardianName());
        tfGuardPhone.setText(s.getGuardianPhone());
        cbRelation.setValue(s.getRelation());
        cbBlood.setValue(s.getBloodGroup());
        taMedical.setText(s.getMedicalConditions());
    }

    private boolean validate() {
        if (tfFirstName.getText().isBlank()) { UIHelper.showError("First name is required."); return false; }
        if (tfLastName.getText().isBlank())  { UIHelper.showError("Last name is required."); return false; }
        if (cbClass.getValue() == null)      { UIHelper.showError("Please select a class."); return false; }
        return true;
    }

    private Student buildStudent() {
        Student s = existing != null ? existing : new Student();
        s.setFirstName(tfFirstName.getText().trim());
        s.setLastName(tfLastName.getText().trim());
        s.setDateOfBirth(dpDOB.getValue());
        s.setGender(cbGender.getValue());
        s.setPhone(tfPhone.getText().trim());
        s.setEmail(tfEmail.getText().trim());
        s.setAddress(taAddress.getText().trim());
        s.setAdmissionDate(dpAdmDate.getValue());
        s.setClassRoom(cbClass.getValue());
        s.setSection(cbSection.getValue());
        if (!tfRollNo.getText().isBlank()) {
            try { s.setRollNumber(Integer.parseInt(tfRollNo.getText().trim())); } catch (Exception ignored) {}
        }
        s.setCategory(cbCategory.getValue());
        if (cbStatus.getValue() != null) s.setStatus(Student.StudentStatus.valueOf(cbStatus.getValue()));
        s.setFatherName(tfFather.getText().trim());
        s.setMotherName(tfMother.getText().trim());
        s.setGuardianName(tfGuardian.getText().trim());
        s.setGuardianPhone(tfGuardPhone.getText().trim());
        s.setRelation(cbRelation.getValue());
        s.setBloodGroup(cbBlood.getValue());
        s.setMedicalConditions(taMedical.getText().trim());
        s.setTransportRequired(false);
        s.setHostelRequired(false);
        return s;
    }

    // ---- Helpers ----
    private GridPane grid() {
        GridPane g = new GridPane();
        g.setHgap(16); g.setVgap(12);
        g.setPadding(new Insets(16));
        ColumnConstraints c1 = new ColumnConstraints(120);
        ColumnConstraints c2 = new ColumnConstraints(); c2.setHgrow(Priority.ALWAYS);
        ColumnConstraints c3 = new ColumnConstraints(120);
        ColumnConstraints c4 = new ColumnConstraints(); c4.setHgrow(Priority.ALWAYS);
        g.getColumnConstraints().addAll(c1, c2, c3, c4);
        return g;
    }

    private void addRow(GridPane g, int row, String l1, javafx.scene.Node f1, String l2, javafx.scene.Node f2) {
        Label lb1 = new Label(l1); lb1.setStyle("-fx-font-weight:bold;-fx-text-fill:#37474F;");
        Label lb2 = new Label(l2); lb2.setStyle("-fx-font-weight:bold;-fx-text-fill:#37474F;");
        if (f1 instanceof TextField tf) tf.setMaxWidth(Double.MAX_VALUE);
        if (f2 instanceof TextField tf) tf.setMaxWidth(Double.MAX_VALUE);
        if (f1 instanceof ComboBox cb) cb.setMaxWidth(Double.MAX_VALUE);
        if (f2 instanceof ComboBox cb) cb.setMaxWidth(Double.MAX_VALUE);
        g.add(lb1, 0, row); g.add(f1, 1, row);
        if (!l2.isBlank()) { g.add(lb2, 2, row); g.add(f2, 3, row); }
    }

    private void addFull(GridPane g, int row, String label, javafx.scene.Node field) {
        Label lb = new Label(label); lb.setStyle("-fx-font-weight:bold;-fx-text-fill:#37474F;");
        GridPane.setColumnSpan(field, 3);
        if (field instanceof TextArea ta) ta.setMaxWidth(Double.MAX_VALUE);
        g.add(lb, 0, row); g.add(field, 1, row);
    }

    private <T extends Control> T styled(T ctrl, String prompt) {
        if (ctrl instanceof TextField tf) tf.setPromptText(prompt);
        return ctrl;
    }
}
