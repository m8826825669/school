package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

// ========== LIBRARY CONTROLLER ==========
@Component
@RequiredArgsConstructor
class LibraryController implements Initializable {
    @FXML private TableView<Book>      bookTable;
    @FXML private TableView<BookIssue> issueTable;
    @FXML private TableColumn<Book, String>      bTitle, bAuthor, bISBN, bCategory, bCopies, bPrice;
    @FXML private TableColumn<Book, Void>        bAvail;
    @FXML private TableColumn<BookIssue, String> iBook, iStudent, iIssued, iDue, iReturn, iFine;
    @FXML private TableColumn<BookIssue, Void>   iStatus, iActions;
    @FXML private TextField searchBook;
    @FXML private Label lblTotalBooks, lblIssued, lblOverdue;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        setupBookTable();
        setupIssueTable();
        loadBooks();
        loadIssues();
    }

    private void setupBookTable() {
        bTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        bAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        bISBN.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        bCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        bCopies.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getTotalCopies())));
        bAvail.setCellFactory(col -> new TableCell<Book, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                Book b = getTableRow().getItem();
                setGraphic(UIHelper.statusBadge(b.isAvailable() ? "AVAILABLE" : "UNAVAILABLE"));
            }
        });
        bPrice.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getPrice() != null ? "₹" + c.getValue().getPrice() : "-"));
        UIHelper.styleTableView(bookTable);
    }

    private void setupIssueTable() {
        iBook.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBook().getTitle()));
        iStudent.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getStudent() != null ? c.getValue().getStudent().getFullName() : "-"));
        iIssued.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getIssueDate() != null ? c.getValue().getIssueDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        iDue.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getDueDate() != null ? c.getValue().getDueDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        iReturn.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getReturnDate() != null ? c.getValue().getReturnDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        iStatus.setCellFactory(col -> new TableCell<BookIssue, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                BookIssue bi = getTableRow().getItem();
                String status = bi.isOverdue() ? "OVERDUE" : bi.getStatus().name();
                setGraphic(UIHelper.statusBadge(status));
            }
        });
        iFine.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getFine() != null && c.getValue().getFine() > 0 ? "₹" + c.getValue().getFine() : "-"));
        iActions.setCellFactory(col -> new TableCell<BookIssue, Void>() {
            private final Button btn = new Button("↩ Return");
            { btn.setStyle("-fx-background-color:#2E7D32;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:10px;-fx-padding:3 8;");
              btn.setOnAction(e -> {
                BookIssue bi = getTableRow().getItem();
                if (bi != null && bi.getStatus() == BookIssue.IssueStatus.ISSUED) {
                    service.returnBook(bi);
                    loadIssues(); loadBooks();
                    UIHelper.showSuccess("Book returned!" + (bi.getFine() != null && bi.getFine() > 0 ? "\nFine: ₹" + bi.getFine() : ""));
                }
              }); }
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(getTableRow().getItem().getStatus() == BookIssue.IssueStatus.ISSUED ? btn : null);
            }
        });
        UIHelper.styleTableView(issueTable);
    }

    private void loadBooks() {
        bookTable.setItems(FXCollections.observableArrayList(service.getAllBooks()));
        lblTotalBooks.setText("Books: " + service.getAllBooks().size());
    }
    private void loadIssues() {
        List<BookIssue> issues = service.getAllIssues();
        issueTable.setItems(FXCollections.observableArrayList(issues));
        long issued  = issues.stream().filter(i -> i.getStatus() == BookIssue.IssueStatus.ISSUED).count();
        long overdue = service.getOverdueBooks().size();
        lblIssued.setText("Issued: " + issued);
        lblOverdue.setText("Overdue: " + overdue);
    }

    @FXML private void searchBook() {
        bookTable.setItems(FXCollections.observableArrayList(service.searchBooks(searchBook.getText())));
    }
    @FXML private void addBook()    { openBookDialog(null); }
    @FXML private void editBook()   { Book b = bookTable.getSelectionModel().getSelectedItem(); if(b!=null) openBookDialog(b); }
    @FXML private void deleteBook() {
        Book b = bookTable.getSelectionModel().getSelectedItem();
        if (b != null && UIHelper.confirm("Delete", "Delete book: " + b.getTitle() + "?")) {
            service.deleteBook(b.getId()); loadBooks();
        }
    }
    @FXML private void issueBook() {
        Book book = bookTable.getSelectionModel().getSelectedItem();
        if (book == null) { UIHelper.showInfo("Select a book to issue."); return; }
        if (!book.isAvailable()) { UIHelper.showError("No copies available for this book."); return; }
        List<Student> students = service.getAllStudents();
        ChoiceDialog<Student> dlg = new ChoiceDialog<>(students.isEmpty() ? null : students.get(0), students);
        dlg.setTitle("Issue Book"); dlg.setHeaderText("Issue: " + book.getTitle());
        dlg.setContentText("Select Student:");
        dlg.getDialogPane().setStyle("-fx-font-size:13px;");
        dlg.showAndWait().ifPresent(student -> {
            service.issueBook(book, student, LocalDate.now().plusDays(14));
            loadBooks(); loadIssues();
            UIHelper.showSuccess("Book issued to " + student.getFullName() + "\nDue: " + LocalDate.now().plusDays(14));
        });
    }

    private void openBookDialog(Book existing) {
        Dialog<Book> d = new Dialog<>();
        d.setTitle(existing == null ? "Add Book" : "Edit Book");
        d.getDialogPane().getPrefWidth();
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField tfTitle = f(existing != null ? existing.getTitle() : "", "Title *");
        TextField tfAuthor= f(existing != null ? existing.getAuthor() : "", "Author");
        TextField tfISBN  = f(existing != null ? existing.getIsbn() : "", "ISBN");
        TextField tfPub   = f(existing != null ? existing.getPublisher() : "", "Publisher");
        TextField tfCopies= f(existing != null ? String.valueOf(existing.getTotalCopies()) : "1", "Copies");
        TextField tfPrice = f(existing != null && existing.getPrice() != null ? String.valueOf(existing.getPrice()) : "", "Price");
        ComboBox<String> cbCat = new ComboBox<>(FXCollections.observableArrayList(
            "Academics","Fiction","Non-Fiction","Biography","Science","History","Reference","Computer Science","Language","Other"));
        if (existing != null) cbCat.setValue(existing.getCategory());
        GridPane g = new GridPane(); g.setHgap(12); g.setVgap(10); g.setPadding(new Insets(20));
        g.add(lbl("Title *"),0,0); g.add(tfTitle,1,0); g.add(lbl("Author"),2,0); g.add(tfAuthor,3,0);
        g.add(lbl("ISBN"),0,1); g.add(tfISBN,1,1); g.add(lbl("Publisher"),2,1); g.add(tfPub,3,1);
        g.add(lbl("Category"),0,2); g.add(cbCat,1,2); g.add(lbl("Copies"),2,2); g.add(tfCopies,3,2);
        g.add(lbl("Price (₹)"),0,3); g.add(tfPrice,1,3);
        d.getDialogPane().setContent(g);
        d.setResultConverter(btn -> {
            if (btn != ButtonType.OK || tfTitle.getText().isBlank()) return null;
            Book b = existing != null ? existing : new Book();
            b.setTitle(tfTitle.getText().trim()); b.setAuthor(tfAuthor.getText().trim());
            b.setIsbn(tfISBN.getText().trim()); b.setPublisher(tfPub.getText().trim());
            b.setCategory(cbCat.getValue()); b.setLanguage("English");
            try { int c = Integer.parseInt(tfCopies.getText()); b.setTotalCopies(c);
                  if (existing == null) b.setAvailableCopies(c); } catch(Exception ignored){}
            try { b.setPrice(Double.parseDouble(tfPrice.getText())); } catch(Exception ignored){}
            return b;
        });
        d.showAndWait().ifPresent(b -> { service.saveBook(b); loadBooks(); });
    }
    private TextField f(String v, String p) { TextField tf=new TextField(v); tf.setPromptText(p); tf.setMaxWidth(Double.MAX_VALUE); return tf; }
    private Label lbl(String t) { Label l=new Label(t); l.setStyle("-fx-font-weight:bold;-fx-text-fill:#37474F;"); return l; }
}

// ========== EXAM CONTROLLER ==========
@Component
@RequiredArgsConstructor
class ExamController implements Initializable {
    @FXML private TableView<Exam> examTable;
    @FXML private TableColumn<Exam, String> eClass, eName, eStart, eEnd;
    @FXML private TableColumn<Exam, Void>   eStatus;
    @FXML private ComboBox<ClassRoom> cbExamClass;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        eClass.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getClassRoom() != null ? c.getValue().getClassRoom().getName() : "All"));
        eName.setCellValueFactory(new PropertyValueFactory<>("name"));
        eStart.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStartDate() != null ? c.getValue().getStartDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        eEnd.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getEndDate() != null ? c.getValue().getEndDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        eStatus.setCellFactory(col -> new TableCell<Exam, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });
        cbExamClass.getItems().addAll(service.getAllClasses());
        UIHelper.styleTableView(examTable);
        loadExams();
    }

    private void loadExams() {
        ClassRoom cls = cbExamClass.getValue();
        List<Exam> exams = cls != null ? service.getExamsByClass(cls) : service.getAllExams();
        examTable.setItems(FXCollections.observableArrayList(exams));
    }

    @FXML private void filterExams()  { loadExams(); }
    @FXML private void addExam()      { openExamDialog(null); }
    @FXML private void editExam()     { Exam e = examTable.getSelectionModel().getSelectedItem(); if (e != null) openExamDialog(e); }
    @FXML private void deleteExam()   {
        Exam e = examTable.getSelectionModel().getSelectedItem();
        if (e != null && UIHelper.confirm("Delete Exam", "Delete " + e.getName() + "?")) {
            service.deleteExam(e.getId()); loadExams();
        }
    }
    @FXML private void enterResults() { UIHelper.showInfo("Select an exam and navigate to Results tab."); }

    private void openExamDialog(Exam existing) {
        Dialog<Exam> d = new Dialog<>();
        d.setTitle(existing == null ? "Add Exam" : "Edit Exam");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField tfName = new TextField(existing != null ? existing.getName() : "");
        tfName.setPromptText("Exam Name");
        ComboBox<ClassRoom> cbCls = new ComboBox<>(FXCollections.observableArrayList(service.getAllClasses()));
        if (existing != null) cbCls.setValue(existing.getClassRoom());
        ComboBox<String> cbStatus = new ComboBox<>(FXCollections.observableArrayList("UPCOMING","ONGOING","COMPLETED","RESULT_DECLARED"));
        cbStatus.setValue(existing != null ? existing.getStatus().name() : "UPCOMING");
        DatePicker dpStart = new DatePicker(existing != null ? existing.getStartDate() : null);
        DatePicker dpEnd   = new DatePicker(existing != null ? existing.getEndDate() : null);
        TextField tfYear   = new TextField(existing != null ? existing.getAcademicYear() : "2024-25");
        GridPane g = new GridPane(); g.setHgap(12); g.setVgap(10); g.setPadding(new Insets(20));
        for (var c : List.of(cbCls, cbStatus, dpStart, dpEnd)) { ((javafx.scene.control.Control)c).setMaxWidth(Double.MAX_VALUE); }
        g.add(new Label("Exam Name *"),0,0); g.add(tfName,1,0);
        g.add(new Label("Class"),0,1); g.add(cbCls,1,1);
        g.add(new Label("Start Date"),0,2); g.add(dpStart,1,2);
        g.add(new Label("End Date"),0,3); g.add(dpEnd,1,3);
        g.add(new Label("Status"),0,4); g.add(cbStatus,1,4);
        g.add(new Label("Academic Year"),0,5); g.add(tfYear,1,5);
        d.getDialogPane().setContent(g);
        d.setResultConverter(btn -> {
            if (btn != ButtonType.OK || tfName.getText().isBlank()) return null;
            Exam ex = existing != null ? existing : new Exam();
            ex.setName(tfName.getText().trim()); ex.setClassRoom(cbCls.getValue());
            ex.setStartDate(dpStart.getValue()); ex.setEndDate(dpEnd.getValue());
            ex.setStatus(Exam.ExamStatus.valueOf(cbStatus.getValue()));
            ex.setAcademicYear(tfYear.getText().trim()); return ex;
        });
        d.showAndWait().ifPresent(ex -> { service.saveExam(ex); loadExams(); });
    }
}

// ========== RESULTS CONTROLLER ==========
@Component
@RequiredArgsConstructor
class ResultsController implements Initializable {
    @FXML private ComboBox<Exam> cbExam;
    @FXML private ComboBox<Student> cbStudent;
    @FXML private TableView<ExamResult> resultTable;
    @FXML private TableColumn<ExamResult,String> rSubject, rMarks, rMax, rPct, rGrade;
    @FXML private TableColumn<ExamResult,Void>   rStatus;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        cbExam.getItems().addAll(service.getAllExams());
        cbStudent.getItems().addAll(service.getAllStudents());
        cbStudent.setCellFactory(lv -> new ListCell<>() {
            protected void updateItem(Student s, boolean empty) {
                super.updateItem(s, empty);
                setText(empty || s == null ? null : s.getFullName());
            }
        });
        cbStudent.setButtonCell(new ListCell<>() {
            protected void updateItem(Student s, boolean empty) {
                super.updateItem(s, empty);
                setText(empty || s == null ? null : s.getFullName());
            }
        });
        rSubject.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSubject().getName()));
        rMarks.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getMarksObtained())));
        rMax.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getMaxMarks())));
        rPct.setCellValueFactory(c -> new SimpleStringProperty(String.format("%.1f%%", c.getValue().getPercentage())));
        rGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
        rStatus.setCellFactory(col -> new TableCell<ExamResult, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(Boolean.TRUE.equals(getTableRow().getItem().getIsPassed()) ? "PASSED" : "FAILED"));
            }
        });
        UIHelper.styleTableView(resultTable);
    }

    @FXML private void loadResults() {
        Exam e = cbExam.getValue(); Student s = cbStudent.getValue();
        if (e != null && s != null) {
            resultTable.setItems(FXCollections.observableArrayList(service.getResultsByStudentAndExam(s, e)));
        }
    }

    @FXML private void addResult() {
        Exam e = cbExam.getValue(); Student s = cbStudent.getValue();
        if (e == null || s == null) { UIHelper.showInfo("Select exam and student first."); return; }
        List<Subject> subjects = service.getAllSubjects();
        ChoiceDialog<Subject> dlg = new ChoiceDialog<>(subjects.isEmpty() ? null : subjects.get(0), subjects);
        dlg.setTitle("Add Result"); dlg.setContentText("Subject:");
        dlg.showAndWait().ifPresent(subj -> {
            Dialog<ExamResult> rd = new Dialog<>();
            rd.setTitle("Enter Marks — " + subj.getName());
            rd.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
            TextField tfMarks = new TextField(); tfMarks.setPromptText("Marks Obtained");
            TextField tfMax   = new TextField(subj.getFullMarks() != null ? String.valueOf(subj.getFullMarks()) : "100");
            GridPane g = new GridPane(); g.setHgap(12); g.setVgap(10); g.setPadding(new Insets(16));
            g.add(new Label("Marks Obtained:"),0,0); g.add(tfMarks,1,0);
            g.add(new Label("Max Marks:"),0,1); g.add(tfMax,1,1);
            rd.getDialogPane().setContent(g);
            rd.setResultConverter(btn -> {
                if (btn != ButtonType.OK) return null;
                ExamResult r = new ExamResult();
                r.setStudent(s); r.setExam(e); r.setSubject(subj);
                try { r.setMarksObtained(Double.parseDouble(tfMarks.getText())); } catch(Exception ignored){}
                try { r.setMaxMarks(Double.parseDouble(tfMax.getText())); } catch(Exception ignored){}
                return r;
            });
            rd.showAndWait().ifPresent(result -> { service.saveResult(result); loadResults(); UIHelper.showSuccess("Result saved!"); });
        });
    }

    @FXML private void generateReportCard() { UIHelper.showInfo("Generating PDF report card for " + (cbStudent.getValue() != null ? cbStudent.getValue().getFullName() : "student") + "..."); }
}

// ========== NOTICE CONTROLLER ==========
@Component
@RequiredArgsConstructor
class NoticeController implements Initializable {
    @FXML private TableView<Notice> noticeTable;
    @FXML private TableColumn<Notice,String> nTitle, nCategory, nAudience, nDate;
    @FXML private TableColumn<Notice,Void>   nActive;
    @FXML private TableColumn<Notice,Void>   nActions;
    @FXML private TextArea taNoticeContent;
    @FXML private ComboBox<String> cbNoticeFilter;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        nTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        nCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        nAudience.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAudience() != null ? c.getValue().getAudience().name() : "-"));
        nDate.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPublishDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))));
        nActive.setCellFactory(col -> new TableCell<Notice, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(Boolean.TRUE.equals(getTableRow().getItem().getIsActive()) ? "ACTIVE" : "INACTIVE"));
            }
        });
        nActions.setCellFactory(col -> new TableCell<Notice, Void>() {
            private final Button btn = new Button("🗑️");
            { btn.setStyle("-fx-background-color:#C62828;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:11px;-fx-padding:3 6;");
              btn.setOnAction(e -> {
                Notice n = getTableRow().getItem();
                if (n != null && UIHelper.confirm("Delete", "Delete notice?")) { service.deleteNotice(n.getId()); loadNotices(); }
              }); }
            protected void updateItem(Void i, boolean e) { super.updateItem(i, e); setGraphic(e ? null : btn); }
        });
        noticeTable.getSelectionModel().selectedItemProperty().addListener((obs, old, n) -> {
            if (n != null && taNoticeContent != null) taNoticeContent.setText(n.getContent());
        });
        cbNoticeFilter.getItems().addAll("All","Active","Students","Teachers","Parents","Staff");
        cbNoticeFilter.setValue("All");
        UIHelper.styleTableView(noticeTable);
        loadNotices();
    }

    private void loadNotices() {
        noticeTable.setItems(FXCollections.observableArrayList(service.getAllNotices()));
    }

    @FXML private void addNotice() { openNoticeDialog(null); }
    @FXML private void filterNotices() { loadNotices(); }

    private void openNoticeDialog(Notice existing) {
        Dialog<Notice> d = new Dialog<>();
        d.setTitle("📢  New Notice");
        d.getDialogPane().setPrefSize(600, 480);
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField tfTitle = new TextField(); tfTitle.setPromptText("Notice Title");
        TextArea taContent = new TextArea(); taContent.setPromptText("Notice content..."); taContent.setPrefRowCount(8);
        ComboBox<String> cbCat = new ComboBox<>(FXCollections.observableArrayList("ACADEMIC","EXAM","HOLIDAY","SPORTS","CIRCULAR","URGENT"));
        ComboBox<String> cbAud = new ComboBox<>(FXCollections.observableArrayList("ALL","STUDENTS","TEACHERS","PARENTS","STAFF"));
        cbCat.setValue("ACADEMIC"); cbAud.setValue("ALL");
        DatePicker dpPub = new DatePicker(LocalDate.now());
        VBox box = new VBox(10); box.setPadding(new Insets(20));
        HBox row1 = new HBox(12, new Label("Title:"), tfTitle); tfTitle.setMaxWidth(Double.MAX_VALUE); HBox.setHgrow(tfTitle, Priority.ALWAYS);
        HBox row2 = new HBox(12, new Label("Category:"), cbCat, new Label("Audience:"), cbAud, new Label("Date:"), dpPub);
        box.getChildren().addAll(row1, row2, new Label("Content:"), taContent);
        d.getDialogPane().setContent(box);
        d.setResultConverter(btn -> {
            if (btn != ButtonType.OK || tfTitle.getText().isBlank()) return null;
            Notice n = new Notice();
            n.setTitle(tfTitle.getText().trim()); n.setContent(taContent.getText().trim());
            n.setCategory(cbCat.getValue()); n.setPublishDate(dpPub.getValue());
            if (cbAud.getValue() != null) n.setAudience(Notice.NoticeAudience.valueOf(cbAud.getValue()));
            n.setIsActive(true); n.setCreatedBy("Admin"); return n;
        });
        d.showAndWait().ifPresent(n -> { service.saveNotice(n); loadNotices(); UIHelper.showSuccess("Notice published!"); });
    }
}

// ========== TIMETABLE CONTROLLER ==========
@Component
@RequiredArgsConstructor
class TimetableController implements Initializable {
    @FXML private ComboBox<ClassRoom> cbTTClass;
    @FXML private ComboBox<Section>   cbTTSection;
    @FXML private TableView<Timetable> ttTable;
    @FXML private TableColumn<Timetable,String> ttDay,ttPeriod,ttStart,ttEnd,ttSubject,ttTeacher,ttRoom;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        cbTTClass.getItems().addAll(service.getAllClasses());
        cbTTClass.setOnAction(e -> {
            cbTTSection.getItems().clear();
            if (cbTTClass.getValue() != null) cbTTSection.getItems().addAll(service.getSectionsByClass(cbTTClass.getValue()));
        });
        ttDay.setCellValueFactory(new PropertyValueFactory<>("dayOfWeek"));
        ttPeriod.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPeriodNo() != null ? "P" + c.getValue().getPeriodNo() : "-"));
        ttStart.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStartTime() != null ? c.getValue().getStartTime().toString() : "-"));
        ttEnd.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getEndTime() != null ? c.getValue().getEndTime().toString() : "-"));
        ttSubject.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSubject().getName()));
        ttTeacher.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTeacher().getFullName()));
        ttRoom.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getRoomNo() != null ? c.getValue().getRoomNo() : "-"));
        UIHelper.styleTableView(ttTable);
    }

    @FXML private void loadTimetable() {
        ClassRoom cls = cbTTClass.getValue();
        if (cls == null) return;
        ttTable.setItems(FXCollections.observableArrayList(service.getTimetableByClass(cls)));
    }
    @FXML private void addPeriod()     { UIHelper.showInfo("Add period dialog — select subject, teacher, day and time."); }
    @FXML private void deletePeriod()  {
        Timetable t = ttTable.getSelectionModel().getSelectedItem();
        if (t != null && UIHelper.confirm("Delete","Remove this period?")) {
            service.deleteTimetable(t.getId()); loadTimetable();
        }
    }
    @FXML private void exportTT() { UIHelper.showInfo("Exporting timetable to PDF..."); }
}

// ========== CLASSES CONTROLLER ==========
@Component
@RequiredArgsConstructor
class ClassesController implements Initializable {
    @FXML private TableView<ClassRoom> classTable;
    @FXML private TableView<Section>   sectionTable;
    @FXML private TableColumn<ClassRoom,String> clsName,clsCap,clsRoom,clsTeacher;
    @FXML private TableColumn<Section,String>   secName,secClass,secCap,secTeacher;
    @FXML private TableView<Subject> subjectTable;
    @FXML private TableColumn<Subject,String> subName,subCode,subType,subTeacher,subMarks;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        clsName.setCellValueFactory(new PropertyValueFactory<>("name"));
        clsCap.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCapacity() != null ? String.valueOf(c.getValue().getCapacity()) : "-"));
        clsRoom.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getRoomNumber() != null ? c.getValue().getRoomNumber() : "-"));
        clsTeacher.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getClassTeacher() != null ? c.getValue().getClassTeacher().getFullName() : "-"));
        secName.setCellValueFactory(new PropertyValueFactory<>("name"));
        secClass.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getClassRoom().getName()));
        secCap.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCapacity() != null ? String.valueOf(c.getValue().getCapacity()) : "-"));
        secTeacher.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSectionTeacher() != null ? c.getValue().getSectionTeacher().getFullName() : "-"));
        subName.setCellValueFactory(new PropertyValueFactory<>("name"));
        subCode.setCellValueFactory(new PropertyValueFactory<>("code"));
        subType.setCellValueFactory(new PropertyValueFactory<>("type"));
        subTeacher.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTeacher() != null ? c.getValue().getTeacher().getFullName() : "-"));
        subMarks.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFullMarks() != null ? String.valueOf(c.getValue().getFullMarks()) : "-"));
        UIHelper.styleTableView(classTable); UIHelper.styleTableView(sectionTable); UIHelper.styleTableView(subjectTable);
        loadAll();
    }

    private void loadAll() {
        classTable.setItems(FXCollections.observableArrayList(service.getAllClasses()));
        sectionTable.setItems(FXCollections.observableArrayList(service.getAllSections()));
        subjectTable.setItems(FXCollections.observableArrayList(service.getAllSubjects()));
    }

    @FXML private void addClass()    { UIHelper.prompt("Add Class","Class Name","").ifPresent(n -> { ClassRoom c=new ClassRoom(); c.setName(n); c.setCapacity(40); service.saveClass(c); loadAll(); }); }
    @FXML private void addSection()  { UIHelper.showInfo("Select class then add section."); }
    @FXML private void addSubject()  { UIHelper.showInfo("Open subject form to add subject."); }
    @FXML private void deleteClass()   { ClassRoom c=classTable.getSelectionModel().getSelectedItem(); if(c!=null&&UIHelper.confirm("Delete","Delete class "+c.getName()+"?")){service.deleteClass(c.getId());loadAll();} }
    @FXML private void deleteSection() { Section s=sectionTable.getSelectionModel().getSelectedItem(); if(s!=null&&UIHelper.confirm("Delete","Delete section?")){service.deleteSection(s.getId());loadAll();} }
    @FXML private void deleteSubject() { Subject s=subjectTable.getSelectionModel().getSelectedItem(); if(s!=null&&UIHelper.confirm("Delete","Delete subject "+s.getName()+"?")){service.deleteSubject(s.getId());loadAll();} }
}

// ========== STAFF CONTROLLER ==========
@Component
@RequiredArgsConstructor
class StaffController implements Initializable {
    @FXML private TableView<Staff> staffTable;
    @FXML private TableColumn<Staff,String> stId,stName,stRole,stPhone,stJoin,stSalary;
    @FXML private TableColumn<Staff,Void>   stStatus;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        stId.setCellValueFactory(new PropertyValueFactory<>("staffId"));
        stName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFullName()));
        stRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        stPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        stJoin.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getJoiningDate() != null ? c.getValue().getJoiningDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : "-"));
        stSalary.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getSalary() != null ? "₹" + String.format("%,.0f", c.getValue().getSalary()) : "-"));
        stStatus.setCellFactory(col -> new TableCell<Staff, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });
        UIHelper.styleTableView(staffTable);
        loadStaff();
    }

    private void loadStaff() { staffTable.setItems(FXCollections.observableArrayList(service.getAllStaff())); }

    @FXML private void addStaff()    { openDialog(null); }
    @FXML private void editStaff()   { Staff s=staffTable.getSelectionModel().getSelectedItem(); if(s!=null) openDialog(s); }
    @FXML private void deleteStaff() {
        Staff s=staffTable.getSelectionModel().getSelectedItem();
        if(s!=null&&UIHelper.confirm("Delete","Delete "+s.getFullName()+"?")) { service.deleteStaff(s.getId()); loadStaff(); }
    }

    private void openDialog(Staff existing) {
        Dialog<Staff> d = new Dialog<>();
        d.setTitle(existing==null?"Add Staff":"Edit Staff");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
        TextField tfFN = new TextField(existing!=null?existing.getFirstName():""); tfFN.setPromptText("First Name");
        TextField tfLN = new TextField(existing!=null?existing.getLastName():"");  tfLN.setPromptText("Last Name");
        TextField tfPh = new TextField(existing!=null?existing.getPhone():"");     tfPh.setPromptText("Phone");
        TextField tfSal= new TextField(existing!=null&&existing.getSalary()!=null?String.valueOf(existing.getSalary()):""); tfSal.setPromptText("Salary");
        ComboBox<String> cbRole = new ComboBox<>(FXCollections.observableArrayList("Peon","Security Guard","Bus Driver","Cook","Librarian","Accountant","Office Staff","Lab Assistant","Nurse","Gardener","Other"));
        if(existing!=null) cbRole.setValue(existing.getRole());
        GridPane g=new GridPane(); g.setHgap(12); g.setVgap(10); g.setPadding(new Insets(20));
        g.add(new Label("First Name:"),0,0); g.add(tfFN,1,0);
        g.add(new Label("Last Name:"),0,1);  g.add(tfLN,1,1);
        g.add(new Label("Role:"),0,2);       g.add(cbRole,1,2);
        g.add(new Label("Phone:"),0,3);      g.add(tfPh,1,3);
        g.add(new Label("Salary (₹):"),0,4); g.add(tfSal,1,4);
        d.getDialogPane().setContent(g);
        d.setResultConverter(btn -> {
            if(btn!=ButtonType.OK||tfFN.getText().isBlank()) return null;
            Staff s=existing!=null?existing:new Staff();
            s.setFirstName(tfFN.getText().trim()); s.setLastName(tfLN.getText().trim());
            s.setPhone(tfPh.getText().trim()); s.setRole(cbRole.getValue());
            s.setJoiningDate(LocalDate.now()); s.setStatus(Staff.StaffStatus.ACTIVE);
            try{s.setSalary(Double.parseDouble(tfSal.getText()));}catch(Exception ignored){}
            return s;
        });
        d.showAndWait().ifPresent(s->{ service.saveStaff(s); loadStaff(); UIHelper.showSuccess("Staff saved!"); });
    }
}

// ========== REPORTS CONTROLLER ==========
@Component
@RequiredArgsConstructor
class ReportsController implements Initializable {
    @FXML private ComboBox<String> cbReportType;
    @FXML private DatePicker dpRepFrom, dpRepTo;
    @FXML private ComboBox<ClassRoom> cbRepClass;
    private final SchoolService service;

    @Override
    public void initialize(URL u, ResourceBundle rb) {
        cbReportType.getItems().addAll("Student List","Teacher List","Attendance Report",
            "Fee Collection Report","Result Analysis","Library Report","Staff List","Daily Collection");
        cbReportType.setValue("Student List");
        cbRepClass.getItems().addAll(service.getAllClasses());
        dpRepFrom.setValue(LocalDate.now().withDayOfMonth(1));
        dpRepTo.setValue(LocalDate.now());
    }

    @FXML private void generateReport() {
        UIHelper.showInfo("📄 Generating: " + cbReportType.getValue() + "\nFormat: PDF\nSaving to Desktop...");
    }
    @FXML private void exportExcel() {
        UIHelper.showInfo("📊 Exporting: " + cbReportType.getValue() + " to Excel...");
    }
    @FXML private void printReport() {
        UIHelper.showInfo("🖨️ Sending to printer: " + cbReportType.getValue());
    }
}
