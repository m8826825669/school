package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FeeController implements Initializable {

    // Collect Fee tab
    @FXML private TextField tfSearchStudent, tfTotalAmount, tfDiscount, tfFine,
                            tfAmountPaid, tfBalance, tfTxnId, tfRemarks;
    @FXML private ComboBox<ClassRoom>    cbFeeClass;
    @FXML private ComboBox<FeeStructure> cbFeeCategory;
    @FXML private ComboBox<String> cbPayMode, cbMonth, cbHistStatus;
    @FXML private DatePicker dpDueDate, dpFromDate, dpToDate;
    @FXML private ListView<Student> studentList;
    @FXML private Label lblSelectedStudent, lblNetAmount, lblTotalCollected;

    // History tab
    @FXML private TableView<FeePayment> paymentTable;
    @FXML private TableColumn<FeePayment, String> colReceipt, colStudent, colFeeType, colAmount,
                                                   colTotal, colBalance, colMode, colPayDate;
    @FXML private TableColumn<FeePayment, Void>   colPayStatus;
    @FXML private TableColumn<FeePayment, Void>   colPrint;

    // Structure tab
    @FXML private TableView<FeeStructure> structureTable;
    @FXML private TableColumn<FeeStructure, String> csName, csAmount, csClass, csFrequency, csYear;

    private final SchoolService schoolService;
    private Student selectedStudent;
    private final ObservableList<Student> searchResults = FXCollections.observableArrayList();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupDropdowns();
        setupStudentList();
        setupPaymentTable();
        setupStructureTable();
        loadPaymentHistory();
        loadFeeStructures();
    }

    private void setupDropdowns() {
        cbFeeClass.getItems().addAll(schoolService.getAllClasses());
        cbFeeCategory.getItems().addAll(schoolService.getAllFeeStructures());
        cbPayMode.getItems().addAll("CASH","CHEQUE","ONLINE","DD","UPI","CARD");
        cbPayMode.setValue("CASH");
        cbMonth.getItems().addAll("April","May","June","July","August","September",
            "October","November","December","January","February","March");
        cbHistStatus.getItems().addAll("All","PAID","PENDING","PARTIAL","OVERDUE","WAIVED");
        cbHistStatus.setValue("All");
        dpDueDate.setValue(LocalDate.now().plusDays(30));
        dpFromDate.setValue(LocalDate.now().withDayOfMonth(1));
        dpToDate.setValue(LocalDate.now());
    }

    private void setupStudentList() {
        studentList.setItems(searchResults);
        studentList.setCellFactory(lv -> new ListCell<>() {
            protected void updateItem(Student s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || s == null) { setText(null); }
                else { setText(s.getAdmissionNo() + " — " + s.getFullName() + " (" + s.getDisplayClass() + ")"); }
            }
        });
        // Load all students initially
        searchResults.addAll(schoolService.getAllStudents());
    }

    @FXML
    private void searchStudent() {
        String q = tfSearchStudent.getText().trim();
        searchResults.setAll(schoolService.searchStudents(q));
    }

    @FXML
    private void filterByClass() {
        ClassRoom cls = cbFeeClass.getValue();
        if (cls == null) {
            searchResults.setAll(schoolService.getAllStudents());
        } else {
            searchResults.setAll(schoolService.getStudentsByClass(cls));
        }
    }

    @FXML
    private void onStudentSelect() {
        Student s = studentList.getSelectionModel().getSelectedItem();
        if (s == null) return;
        selectedStudent = s;
        lblSelectedStudent.setText("Student: " + s.getFullName() + " | " + s.getDisplayClass() + " | Adm: " + s.getAdmissionNo());
    }

    @FXML
    private void onFeeSelect() {
        FeeStructure fs = cbFeeCategory.getValue();
        if (fs != null && fs.getAmount() != null) {
            tfTotalAmount.setText(String.valueOf(fs.getAmount()));
            calcBalance();
        }
    }

    @FXML
    private void calcBalance() {
        try {
            double total   = parse(tfTotalAmount.getText());
            double disc    = parse(tfDiscount.getText());
            double fine    = parse(tfFine.getText());
            double paid    = parse(tfAmountPaid.getText());
            double net     = total - disc + fine;
            double balance = net - paid;
            tfBalance.setText(String.format("%.2f", Math.max(0, balance)));
            lblNetAmount.setText("Net: ₹" + String.format("%.2f", net));
        } catch (Exception ignored) {}
    }

    private double parse(String s) {
        try { return s == null || s.isBlank() ? 0 : Double.parseDouble(s.trim()); }
        catch (Exception e) { return 0; }
    }

    @FXML
    private void collectFee() {
        if (selectedStudent == null) { UIHelper.showError("Please select a student."); return; }
        if (cbFeeCategory.getValue() == null) { UIHelper.showError("Please select a fee category."); return; }
        double paid = parse(tfAmountPaid.getText());
        if (paid <= 0) { UIHelper.showError("Enter a valid payment amount."); return; }

        FeePayment payment = new FeePayment();
        payment.setStudent(selectedStudent);
        payment.setFeeStructure(cbFeeCategory.getValue());
        payment.setTotalAmount(parse(tfTotalAmount.getText()));
        payment.setAmountPaid(paid);
        payment.setDiscount(parse(tfDiscount.getText()));
        payment.setFine(parse(tfFine.getText()));
        payment.setPaymentDate(LocalDate.now());
        payment.setDueDate(dpDueDate.getValue());
        payment.setPaymentMode(cbPayMode.getValue());
        payment.setTransactionId(tfTxnId.getText().trim());
        payment.setMonth(cbMonth.getValue());
        payment.setRemarks(tfRemarks.getText().trim());
        payment.setCollectedBy("Admin");
        payment.setAcademicYear("2024-25");

        FeePayment saved = schoolService.saveFeePayment(payment);
        UIHelper.showSuccess("✅ Payment collected!\nReceipt No: " + saved.getReceiptNo() +
            "\nAmount: ₹" + paid + "\nBalance: ₹" + saved.getBalance());
        clearForm();
        loadPaymentHistory();
    }

    @FXML
    private void clearForm() {
        tfTotalAmount.clear(); tfDiscount.clear(); tfFine.clear();
        tfAmountPaid.clear(); tfBalance.clear(); tfTxnId.clear(); tfRemarks.clear();
        cbFeeCategory.setValue(null); cbPayMode.setValue("CASH"); cbMonth.setValue(null);
        lblNetAmount.setText("Net: ₹0");
    }

    private void setupPaymentTable() {
        colReceipt.setCellValueFactory(new PropertyValueFactory<>("receiptNo"));
        colStudent.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStudent().getFullName()));
        colFeeType.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getFeeStructure() != null ? c.getValue().getFeeStructure().getName() : "-"));
        colAmount.setCellValueFactory(c -> new SimpleStringProperty(
            "₹" + String.format("%,.0f", c.getValue().getAmountPaid())));
        colTotal.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getTotalAmount() != null ? "₹" + String.format("%,.0f", c.getValue().getTotalAmount()) : "-"));
        colBalance.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getBalance() != null ? "₹" + String.format("%,.2f", c.getValue().getBalance()) : "-"));
        colMode.setCellValueFactory(new PropertyValueFactory<>("paymentMode"));
        colPayDate.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getPaymentDate() != null ? c.getValue().getPaymentDate().format(FMT) : "-"));
        colPayStatus.setCellFactory(col -> new TableCell<FeePayment, Void>() {
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e);
                if (e || getTableRow().getItem() == null) { setGraphic(null); return; }
                setGraphic(UIHelper.statusBadge(getTableRow().getItem().getStatus().name()));
            }
        });
        colPrint.setCellFactory(col -> new TableCell<FeePayment, Void>() {
            private final Button btn = new Button("🖨️");
            { btn.setStyle("-fx-background-color:#546E7A;-fx-text-fill:white;-fx-background-radius:4;-fx-font-size:11px;-fx-padding:3 6;");
              btn.setOnAction(e -> UIHelper.showInfo("Printing receipt...")); }
            protected void updateItem(Void i, boolean e) {
                super.updateItem(i, e); setGraphic(e ? null : btn); }
        });
        UIHelper.styleTableView(paymentTable);
    }

    private void loadPaymentHistory() {
        List<FeePayment> all = schoolService.getAllPayments();
        paymentTable.setItems(FXCollections.observableArrayList(all));
        double total = all.stream().filter(p -> p.getStatus() == FeePayment.PaymentStatus.PAID)
            .mapToDouble(p -> p.getAmountPaid() != null ? p.getAmountPaid() : 0).sum();
        lblTotalCollected.setText("Total Collected: ₹" + String.format("%,.0f", total));
    }

    @FXML
    private void filterPayments() {
        List<FeePayment> all = schoolService.getAllPayments();
        String status = cbHistStatus.getValue();
        LocalDate from = dpFromDate.getValue();
        LocalDate to   = dpToDate.getValue();
        List<FeePayment> filtered = all.stream()
            .filter(p -> status == null || status.equals("All") || p.getStatus().name().equals(status))
            .filter(p -> from == null || (p.getPaymentDate() != null && !p.getPaymentDate().isBefore(from)))
            .filter(p -> to == null   || (p.getPaymentDate() != null && !p.getPaymentDate().isAfter(to)))
            .collect(Collectors.toList());
        paymentTable.setItems(FXCollections.observableArrayList(filtered));
        double total = filtered.stream().filter(p -> p.getStatus() == FeePayment.PaymentStatus.PAID)
            .mapToDouble(p -> p.getAmountPaid() != null ? p.getAmountPaid() : 0).sum();
        lblTotalCollected.setText("Total: ₹" + String.format("%,.0f", total) + " (" + filtered.size() + " records)");
    }

    @FXML private void resetFilter() { loadPaymentHistory(); }

    private void setupStructureTable() {
        csName.setCellValueFactory(new PropertyValueFactory<>("name"));
        csAmount.setCellValueFactory(c -> new SimpleStringProperty(
            "₹" + String.format("%,.0f", c.getValue().getAmount())));
        csClass.setCellValueFactory(c -> new SimpleStringProperty(
            c.getValue().getClassRoom() != null ? "Class " + c.getValue().getClassRoom().getName() : "All Classes"));
        csFrequency.setCellValueFactory(new PropertyValueFactory<>("frequency"));
        csYear.setCellValueFactory(new PropertyValueFactory<>("academicYear"));
        UIHelper.styleTableView(structureTable);
    }

    private void loadFeeStructures() {
        structureTable.setItems(FXCollections.observableArrayList(schoolService.getAllFeeStructures()));
    }

    @FXML private void addFeeCategory()    { openFeeStructureDialog(null); }
    @FXML private void editFeeCategory()   {
        FeeStructure fs = structureTable.getSelectionModel().getSelectedItem();
        if (fs != null) openFeeStructureDialog(fs); else UIHelper.showInfo("Select a fee category.");
    }
    @FXML private void deleteFeeCategory() {
        FeeStructure fs = structureTable.getSelectionModel().getSelectedItem();
        if (fs == null) { UIHelper.showInfo("Select a fee category."); return; }
        if (UIHelper.confirm("Delete", "Delete fee: " + fs.getName() + "?")) {
            schoolService.deleteFeeStructure(fs.getId()); loadFeeStructures();
        }
    }

    private void openFeeStructureDialog(FeeStructure existing) {
        Dialog<FeeStructure> d = new Dialog<>();
        d.setTitle(existing == null ? "Add Fee Category" : "Edit Fee Category");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField tfName = new TextField(existing != null ? existing.getName() : "");
        TextField tfAmt  = new TextField(existing != null ? String.valueOf(existing.getAmount()) : "");
        ComboBox<String> cbFreq = new ComboBox<>(FXCollections.observableArrayList("MONTHLY","QUARTERLY","ANNUALLY","ONE_TIME"));
        if (existing != null) cbFreq.setValue(existing.getFrequency());
        var g = new javafx.scene.layout.GridPane(); g.setHgap(12); g.setVgap(10); g.setPadding(new javafx.geometry.Insets(20));
        g.add(new Label("Name:"),0,0); g.add(tfName,1,0);
        g.add(new Label("Amount (₹):"),0,1); g.add(tfAmt,1,1);
        g.add(new Label("Frequency:"),0,2); g.add(cbFreq,1,2);
        d.getDialogPane().setContent(g);
        d.setResultConverter(btn -> {
            if (btn != ButtonType.OK) return null;
            FeeStructure fs = existing != null ? existing : new FeeStructure();
            fs.setName(tfName.getText().trim()); fs.setFrequency(cbFreq.getValue());
            try { fs.setAmount(Double.parseDouble(tfAmt.getText().trim())); } catch(Exception ignored){}
            fs.setAcademicYear("2024-25"); return fs;
        });
        d.showAndWait().ifPresent(fs -> { schoolService.saveFeeStructure(fs); loadFeeStructures(); setupDropdowns(); });
    }
}
