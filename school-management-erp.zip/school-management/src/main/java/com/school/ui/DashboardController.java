package com.school.ui;

import com.school.model.*;
import com.school.service.SchoolService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

@Component
@RequiredArgsConstructor
public class DashboardController implements Initializable {

    @FXML private Label lblTotalStudents, lblTotalTeachers, lblFeeCollected, lblTotalClasses;
    @FXML private Label lblTotalSections, lblTotalBooks, lblBooksIssued, lblPendingFees;
    @FXML private Label lblTotalStaff, lblActiveNotices, lblStudentChange, lblTodayFee;
    @FXML private Label lblWelcomeSub, lblAcademicYear, lblTodayDate;
    @FXML private BarChart<String, Number> chartStudents;
    @FXML private VBox noticePanel;

    private final SchoolService schoolService;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadStats();
        loadChart();
        loadNotices();
        setupWelcome();
    }

    private void setupWelcome() {
        lblWelcomeSub.setText("Here's what's happening in your school today.");
        lblAcademicYear.setText("🗓️  AY: 2024-25");
        lblTodayDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
    }

    private void loadStats() {
        try {
            long students = schoolService.getAllStudents().size();
            long teachers = schoolService.getAllTeachers().size();
            long classes  = schoolService.getAllClasses().size();
            long sections = schoolService.getAllSections().size();
            long books    = schoolService.getAllBooks().size();
            long staff    = schoolService.getAllStaff().size();
            long notices  = schoolService.getActiveNotices().size();
            double monthly = schoolService.getMonthlyCollection();
            double today   = schoolService.getTodayCollection();

            lblTotalStudents.setText(String.valueOf(students));
            lblTotalTeachers.setText(String.valueOf(teachers));
            lblTotalClasses.setText(String.valueOf(classes));
            lblTotalSections.setText(sections + " Sections");
            lblTotalBooks.setText(String.valueOf(books));
            lblTotalStaff.setText(String.valueOf(staff));
            lblActiveNotices.setText(String.valueOf(notices));
            lblFeeCollected.setText("₹" + String.format("%,.0f", monthly));
            lblTodayFee.setText("Today: ₹" + String.format("%,.0f", today));
            lblStudentChange.setText("Active: " + students);
            lblBooksIssued.setText(schoolService.getOverdueBooks().size() + " Overdue");
            lblPendingFees.setText("Action Needed");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadChart() {
        try {
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Students");
            List<ClassRoom> classes = schoolService.getAllClasses();
            for (ClassRoom c : classes) {
                long count = schoolService.getStudentsByClass(c).size();
                if (count > 0) {
                    series.getData().add(new XYChart.Data<>("Cls " + c.getName(), count));
                }
            }
            chartStudents.getData().clear();
            chartStudents.getData().add(series);
            chartStudents.setLegendVisible(false);
            chartStudents.setAnimated(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadNotices() {
        try {
            noticePanel.getChildren().clear();
            List<Notice> notices = schoolService.getActiveNotices();
            for (int i = 0; i < Math.min(notices.size(), 4); i++) {
                Notice n = notices.get(i);
                VBox card = new VBox(4);
                card.setStyle("-fx-background-color: #F5F5F5; -fx-background-radius: 8; -fx-padding: 10;");

                HBox header = new HBox(8);
                header.setAlignment(Pos.CENTER_LEFT);
                Label badge = new Label(getCategoryEmoji(n.getCategory()));
                badge.setStyle("-fx-font-size: 14px;");
                Label title = new Label(n.getTitle());
                title.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: #1A237E;");
                title.setWrapText(true);
                header.getChildren().addAll(badge, title);

                Label date = new Label(n.getPublishDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
                date.setStyle("-fx-font-size: 10px; -fx-text-fill: #9E9E9E;");

                card.getChildren().addAll(header, date);
                noticePanel.getChildren().add(card);
            }
            if (notices.isEmpty()) {
                Label empty = new Label("No active notices");
                empty.setStyle("-fx-text-fill: #9E9E9E; -fx-font-size: 12px;");
                noticePanel.getChildren().add(empty);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getCategoryEmoji(String cat) {
        if (cat == null) return "📋";
        return switch (cat) {
            case "EXAM"     -> "📝";
            case "HOLIDAY"  -> "🎉";
            case "SPORTS"   -> "🏆";
            case "URGENT"   -> "🚨";
            case "CIRCULAR" -> "📌";
            default         -> "📢";
        };
    }

    @FXML private void quickAddStudent()  { UIHelper.showInfo("Navigate to Students → Add Student"); }
    @FXML private void quickAddTeacher()  { UIHelper.showInfo("Navigate to Teachers → Add Teacher"); }
    @FXML private void quickAttendance()  { UIHelper.showInfo("Navigate to Attendance"); }
    @FXML private void quickFeePayment()  { UIHelper.showInfo("Navigate to Fee Management"); }
    @FXML private void quickIssueBook()   { UIHelper.showInfo("Navigate to Library → Issue Book"); }
    @FXML private void quickNewNotice()   { UIHelper.showInfo("Navigate to Notice Board → New Notice"); }
}
