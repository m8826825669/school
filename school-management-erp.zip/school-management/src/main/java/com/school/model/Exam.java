package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "exams")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Exam {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name; // Unit Test 1, Mid Term, Final Exam

    private String academicYear;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "class_id")
    private ClassRoom classRoom;

    private LocalDate startDate;
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ExamStatus status = ExamStatus.UPCOMING;

    private String description;
    private Integer totalMarks;
    private Integer passingMarks;

    public enum ExamStatus { UPCOMING, ONGOING, COMPLETED, RESULT_DECLARED }

    @Override
    public String toString() { return name; }
}
