package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "staff")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Staff {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String staffId;

    private String firstName;
    private String lastName;
    private String role; // Accountant, Peon, Security, Librarian, Driver, Cook...
    private String phone;
    private String email;
    private String address;
    private String gender;
    private LocalDate dateOfBirth;
    private LocalDate joiningDate;
    private Double salary;
    private String qualification;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private StaffStatus status = StaffStatus.ACTIVE;

    private String bankAccount;
    private String aadharNumber;
    private String panNumber;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDate createdAt = LocalDate.now();

    public String getFullName() { return firstName + " " + lastName; }

    public enum StaffStatus { ACTIVE, RESIGNED, TERMINATED }
}
