package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "students")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String admissionNo;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    private LocalDate dateOfBirth;
    private String gender; // MALE, FEMALE, OTHER

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "class_id")
    private ClassRoom classRoom;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "section_id")
    private Section section;

    private String phone;
    private String email;

    @Column(columnDefinition = "TEXT")
    private String address;

    // Parent / Guardian Details
    private String fatherName;
    private String motherName;
    private String guardianName;
    private String guardianPhone;
    private String guardianEmail;
    private String relation;

    // Academic
    private LocalDate admissionDate;
    private String previousSchool;
    private String previousClass;
    private Double previousPercentage;

    // Medical
    private String bloodGroup;
    private String medicalConditions;

    // Status
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private StudentStatus status = StudentStatus.ACTIVE;

    @Column(columnDefinition = "TEXT")
    private String photoPath;

    private String religion;
    private String category; // GEN, OBC, SC, ST

    @Column(name = "roll_number")
    private Integer rollNumber;

    // Transport
    private Boolean transportRequired;
    private String busRoute;

    // Hostel
    private Boolean hostelRequired;
    private String hostelRoom;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDate createdAt = LocalDate.now();

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getDisplayClass() {
        String cls = classRoom != null ? classRoom.getName() : "-";
        String sec = section != null ? section.getName() : "-";
        return "Class " + cls + " - " + sec;
    }

    public enum StudentStatus {
        ACTIVE, TRANSFERRED, PASSED_OUT, DROPPED
    }
}
