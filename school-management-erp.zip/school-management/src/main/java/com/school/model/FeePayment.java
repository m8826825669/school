package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "fee_payments")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class FeePayment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String receiptNo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "fee_structure_id")
    private FeeStructure feeStructure;

    private Double amountPaid;
    private Double totalAmount;
    private Double discount;
    private Double fine;
    private Double balance;

    private LocalDate paymentDate;
    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private PaymentStatus status = PaymentStatus.PENDING;

    private String paymentMode; // CASH, CHEQUE, ONLINE, DD
    private String transactionId;
    private String chequeNo;
    private String bankName;

    private String month; // For monthly fees
    private String academicYear;
    private String remarks;

    @Column(name = "collected_by")
    private String collectedBy;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDate createdAt = LocalDate.now();

    public enum PaymentStatus { PAID, PENDING, PARTIAL, WAIVED, OVERDUE }
}
