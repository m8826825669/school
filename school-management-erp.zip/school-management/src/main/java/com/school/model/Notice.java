package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "notices")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Notice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String content;

    private String category; // ACADEMIC, EXAM, HOLIDAY, SPORTS, CIRCULAR, URGENT

    @Enumerated(EnumType.STRING)
    private NoticeAudience audience;

    @Column(nullable = false)
    private LocalDate publishDate;

    private LocalDate expiryDate;
    private Boolean isActive;
    private String createdBy;
    private String attachmentPath;

    public enum NoticeAudience { ALL, STUDENTS, TEACHERS, PARENTS, STAFF }
}
