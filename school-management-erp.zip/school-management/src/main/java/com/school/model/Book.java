package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "books")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Book {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    private String author;
    private String publisher;
    private String isbn;
    private String category; // Science, Math, Literature, Reference...
    private Integer totalCopies;
    private Integer availableCopies;
    private Double price;
    private String edition;
    private Integer publishYear;
    private String language;
    private String shelfLocation;
    private String description;
    private String coverPath;

    @Column(name = "added_date")
    @Builder.Default
    private LocalDate addedDate = LocalDate.now();

    public boolean isAvailable() {
        return availableCopies != null && availableCopies > 0;
    }
}
