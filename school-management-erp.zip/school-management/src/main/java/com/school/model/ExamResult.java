package com.school.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "exam_results")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ExamResult {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "exam_id", nullable = false)
    private Exam exam;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    private Double marksObtained;
    private Double maxMarks;
    private String grade;
    private Boolean isPassed;
    private String remarks;

    public Double getPercentage() {
        if (maxMarks == null || maxMarks == 0) return 0.0;
        return (marksObtained / maxMarks) * 100;
    }

    public static String calculateGrade(double percentage) {
        if (percentage >= 90) return "A+";
        if (percentage >= 80) return "A";
        if (percentage >= 70) return "B+";
        if (percentage >= 60) return "B";
        if (percentage >= 50) return "C";
        if (percentage >= 40) return "D";
        return "F";
    }
}
