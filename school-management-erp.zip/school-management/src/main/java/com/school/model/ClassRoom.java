package com.school.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "classrooms")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ClassRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name; // 1, 2, 3 ... 12, Nursery, KG

    private String description;
    private Integer capacity;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "class_teacher_id")
    private Teacher classTeacher;

    private String roomNumber;
    private String stream; // Science, Commerce, Arts (for 11-12)

    @Override
    public String toString() { return name; }
}
