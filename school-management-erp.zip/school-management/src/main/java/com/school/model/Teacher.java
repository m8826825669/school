package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "teachers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Teacher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String employeeId;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    private LocalDate dateOfBirth;
    private String gender;

    @Column(nullable = false, unique = true)
    private String phone;

    private String email;
    private String address;

    // Professional
    private String qualification;
    private String specialization;
    private Integer experienceYears;
    private LocalDate joiningDate;
    private Double salary;

    // Role
    private String designation; // Teacher, HOD, Principal, Vice-Principal
    private String department;

    // Class Teacher
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "class_teacher_of")
    private ClassRoom classTeacherOf;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "section_teacher_of")
    private Section sectionTeacherOf;

    // Status
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private TeacherStatus status = TeacherStatus.ACTIVE;

    private String bloodGroup;
    private String religion;
    private String photoPath;

    // Bank Details
    private String bankAccount;
    private String bankName;
    private String ifscCode;
    private String panNumber;
    private String aadharNumber;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDate createdAt = LocalDate.now();

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public enum TeacherStatus {
        ACTIVE, ON_LEAVE, RESIGNED, RETIRED
    }
}
