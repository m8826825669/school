package com.school.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "fee_structures")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class FeeStructure {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name; // Tuition Fee, Lab Fee, Library Fee...

    private Double amount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "class_id")
    private ClassRoom classRoom; // null = applicable to all

    private String frequency; // MONTHLY, QUARTERLY, ANNUALLY, ONE_TIME
    private String academicYear;
    private String description;

    @Override
    public String toString() { return name; }
}
