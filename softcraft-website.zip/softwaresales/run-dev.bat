@echo off
REM ================================================================
REM  SoftCraft Website — Development Quick Start (Windows)
REM ================================================================

echo ==========================================
echo   SoftCraft Solutions — Dev Server
echo ==========================================
echo.

REM --- Backend ---
echo [1/4] Setting up Django backend...
cd backend

if not exist venv (
    python -m venv venv
    echo   Created virtual environment
)

call venv\Scripts\activate
pip install -r requirements.txt -q

if not exist .env (
    copy .env.example .env
    echo   WARNING: Created .env - add your Razorpay keys!
)

python manage.py migrate --run-syncdb
python manage.py seed_products
echo   Backend ready.

REM Start Django in new window
start "Django Backend" cmd /k "call venv\Scripts\activate && python manage.py runserver 0.0.0.0:8000"
echo   Django running on http://localhost:8000

cd ..

REM --- Frontend ---
echo.
echo [2/4] Setting up Next.js frontend...
cd frontend

if not exist .env.local (
    copy .env.local.example .env.local
    echo   Created .env.local
)

if not exist node_modules (
    npm install
)

echo.
echo ==========================================
echo   Frontend:  http://localhost:3000
echo   API:       http://localhost:8000/api/
echo   Admin:     http://localhost:8000/admin/
echo ==========================================
echo.

npm run dev
